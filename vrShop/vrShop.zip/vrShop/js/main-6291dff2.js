webpackJsonp([9],[
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function($) {__webpack_require__(12);
	__webpack_require__(14);
	__webpack_require__(13);
	__webpack_require__(16);
	var pageDatas = {
	    defaultRoute:"index"
	};

	//入口
	$(function() {
	     if(!sessionStorage.getItem('liveParam')){
	       var spaceNum = GetRequest()['spaceNum']
	       var redirectUri = location.href
	       sessionStorage.setItem('redirectUri', redirectUri)
	       location.href = "http://wap.hongdoujiao.tv/wap/s/homeIndex.do?s="+spaceNum
	     }
	    pageDatas.param = JSON.parse(sessionStorage.getItem("liveParam"));
	    addEvent();
	    window.onhashchange = function() {
	        var modName = getModeName();
	        modName = modName || pageDatas.defaultRoute;
	        loadHtml(modName);
	    }

	    var modName = getModeName();
	    modName = modName || pageDatas.defaultRoute;
	    loadHtml(modName);
	});

	//主页面导入
	function loadHtml(modName) {
	    var htmlPath = './html/'+modName+'.html';
	    var jsPath = './'+modName;
	    $.get(htmlPath, [], function (html) {
	        $("#container").html(html);
	        loadJs(jsPath);
	    });
	}
	function loadJs(jsPath) {
	    /// <summary>
	    /// load js mod
	    /// </summary>
	    /// <param name="jsPath" type="type">js path</param>

	    var currentMod;
	    pageDatas.param.modName = currentMod;
	    if (jsPath === './index') {
	        __webpack_require__.e/* nsure */(0, function (require) {
	            currentMod = __webpack_require__(22);
	            currentMod.init(pageDatas.param);
	        });
	    }
	    if (jsPath === './detail') {
	        __webpack_require__.e/* nsure */(1, function (require) {
	            currentMod = __webpack_require__(21);
	            currentMod.init(pageDatas.param);
	        });
	    }
	    if (jsPath === './confirmOrder') {
	        __webpack_require__.e/* nsure */(6, function (require) {
	            currentMod = __webpack_require__(20);
	            currentMod.init(pageDatas.param);
	        });
	    }
	    if (jsPath === './choosePayType') {
	        __webpack_require__.e/* nsure */(7, function (require) {
	            currentMod = __webpack_require__(19);
	            currentMod.init(pageDatas.param);
	        });
	    }
	    if (jsPath === './my') {
	        __webpack_require__.e/* nsure */(5, function (require) {
	            currentMod = __webpack_require__(24);
	            currentMod.init(pageDatas.param);
	        });
	    }
	    if (jsPath === './chooseAddress') {
	        __webpack_require__.e/* nsure */(8, function (require) {
	            currentMod = __webpack_require__(18);
	            currentMod.init(pageDatas.param);
	        });
	    }
	    if (jsPath === './shareCode') {
	        __webpack_require__.e/* nsure */(4, function (require) {
	            currentMod = __webpack_require__(25);
	            currentMod.init(pageDatas.param);
	        });
	    }
	    if (jsPath === './addAddress') {
	        __webpack_require__.e/* nsure */(3, function (require) {
	            currentMod = __webpack_require__(15);
	            currentMod.init(pageDatas.param);
	        });
	    }
	}
	//通用方法
	//获取模块名
	function getModeName() {
	    var modName = window.location.href.split('#')[1];
	    return modName;
	}

	function GetRequest() {
	  var params = location.href.split('?')[1]; //获取url中"?"符后的字串
	  let obj = {}
	  strs = params.split("#")[0];
	  strs = strs.split("&");
	  for(var i = 0; i < strs.length; i ++) {
	    obj[strs[i].split("=")[0]] = strs[i].split("=")[1];
	  }
	  return obj;
	}

	function addEvent(){
	    $("#footer li").click(function(){
	        $("#footer li.active").removeClass("active");
	        $(this).addClass("active");
	        switch($(this).index()){
	            case 0:location.href="http://wap.hongdoujiao.tv/wap/s/homeIndex.do?s="+pageDatas.param.spaceNum;break;
	            case 1:location.href="#index";break;
	            case 2:location.href="#my";break;
	        }
	    });
	}

	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },
/* 1 */,
/* 2 */,
/* 3 */,
/* 4 */,
/* 5 */,
/* 6 */,
/* 7 */,
/* 8 */,
/* 9 */,
/* 10 */,
/* 11 */,
/* 12 */
/***/ function(module, exports) {

	// removed by extract-text-webpack-plugin

/***/ },
/* 13 */
12,
/* 14 */
12,
/* 15 */,
/* 16 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(FastClick) { var docEl = document.documentElement;
	 //当设备的方向变化（设备横向持或纵向持）此事件被触发。绑定此事件时，
	 //注意现在当浏览器不支持orientationChange事件的时候我们绑定了resize 事件。
	 //总来的来就是监听当然窗口的变化，一旦有变化就需要重新设置根字体的值
	 resizeEvt = 'orientationchange' in window ? 'orientationchange' : 'resize';
	 recalc = function() {
	    FastClick.attach(document.body); 
	     //判断横屏,竖屏
	     var tagFont = 100 * (docEl.clientWidth / 750);
	     // if(docEl.clientWidth>docEl.clientHeight){
	     //    //此时为横屏
	     //    tagFont = 100 * (docEl.clientHeight / 750);
	     // }else{
	     //    tagFont = 100 * (docEl.clientWidth / 750);
	     // }
	     //设置根字体大小
	     if (tagFont > 160) {
	         docEl.style.fontSize = '160px';
	     } else {
	         docEl.style.fontSize = tagFont + 'px';
	     }
	 };
	 //绑定浏览器缩放与加载时间,重设rem
	 window.addEventListener(resizeEvt, recalc, false);
	 document.addEventListener('DOMContentLoaded', recalc, false);

	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(11)))

/***/ }
]);