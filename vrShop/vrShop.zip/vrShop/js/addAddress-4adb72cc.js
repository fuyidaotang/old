webpackJsonp([3],{

/***/ 15:
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function($) {var IosSelect = __webpack_require__(23);
	var areaObject = __webpack_require__(17);
	var addAddressPara;

	function initialize(param) {
	  addAddressPara = param;
	  if (sessionStorage.getItem("editAddress")) {
	    var address = JSON.parse(sessionStorage.getItem("editAddress"));
	    $('#addressId').val(address.addressId);
	    $('#realName').val(address.receiveName);
	    $('#telphone').val(address.receivePhone);
	    $('#show_contact').attr('data-province-code', address.addressProvinces);
	    $('#show_contact').attr('data-city-code', address.addressCity);
	    $('#show_contact').attr('data-district-code', address.addressDistrict);

	    $('#show_contact').val(address.addressProvincesInfo + " " + address.addressCityInfo + " " + address.addressDistrictInfo);
	    $('#inputAddress').val(address.addressStreet);
	  }
	  $("footer").hide();
	  saveAddressEvent();
	  initSelector();
	}

	//添加更新地址事件
	function saveAddressEvent() {
	  $('#show_contact').parents(".inputArea").siblings(".inputArea").click(function () {
	    $(this).children("input").focus();
	  });
	  //不弹出小键盘
	  $('#show_contact').click(function () {
	    $(this).blur();
	  });
	  $('#saveAddress').click(function () {
	    var realName = $('#realName').val().trim();
	    var telphone = $('#telphone').val().trim();
	    var area = $('#show_contact').val().trim();
	    var address = $('#inputAddress').val().trim();
	    var areaInfo = $('#show_contact').val().split(" ");

	    var telReg = new RegExp("^(13[0-9]|15[012356789]|17[678]|18[0-9]|14[57])[0-9]{8}$");
	    if (realName == "") {
	      $('#realName').siblings(".mistake").html("请输入真实姓名");
	      $('#realName').siblings(".mistake").show();
	      return;
	    }
	    if (!telReg.exec(telphone)) {
	      $('#telphone').siblings(".mistake").html("请输入正确的手机号码");
	      $('#telphone').siblings(".mistake").show();
	      return;
	    }
	    if (area == "") {
	      $('#show_contact').siblings(".mistake").html("请选择所在地区");
	      $('#show_contact').siblings(".mistake").show();
	      return;
	    }
	    if (address == "") {
	      $('#inputAddress').siblings(".mistake").html("请输入详细地址");
	      $('#inputAddress').siblings(".mistake").show();
	      return;
	    }
	    var para = {
	      userId: addAddressPara.userId,
	      addressProvinces: $('#show_contact').attr('data-province-code'),
	      addressCity: $('#show_contact').attr('data-city-code'),
	      addressDistrict: $('#show_contact').attr('data-district-code'),
	      addressStreet: address,
	      receiveName: realName,
	      receivePhone: telphone
	    }
	    if ($('#addressId').val()) {
	      var index = $('#addressId').attr('index');
	      para.addressId = $('#addressId').val();
	      para.addressProvincesInfo = areaInfo[0];
	      para.addressCityInfo = areaInfo[1];
	      para.addressDistrictInfo = areaInfo[2];
	      $.ajax({
	        type: "post",
	        url: "http://wap.hongdoujiao.tv/wap/address/update.do",
	        data: para,
	        success: function (data) {
	          var addLastPage = sessionStorage.getItem("addLastPage");
	          sessionStorage.setItem('addressInfo', JSON.stringify(para))
	          if (addLastPage == "chooseAddress") {
	            location.href = "#chooseAddress";
	          } else {
	            location.href = "#confirmOrder";
	          }
	        }
	      });
	    } else {
	      para.addressProvincesInfo = areaInfo[0];
	      para.addressCityInfo = areaInfo[1];
	      para.addressDistrictInfo = areaInfo[2];
	      $.ajax({
	        type: "post",
	        url: "http://wap.hongdoujiao.tv/wap/address/insert.do",
	        data: para,
	        success: function (data) {
	          var addLastPage = sessionStorage.getItem("addLastPage");
	          para.addressId = data.resp.addressId
	          sessionStorage.setItem('addressInfo', JSON.stringify(para))
	          if (addLastPage == "chooseAddress") {
	            location.href = "#chooseAddress";
	          } else {
	            location.href = "#confirmOrder";
	          }
	        }
	      });
	    }
	  });
	  $('.addAddress .inputArea input').click(function () {
	    $(this).siblings('.mistake').hide();
	  });
	}

	//地区选择
	function initSelector() {
	  var showContactDom = $('#show_contact');
	  showContactDom.bind('click', function () {
	    var sccode = showContactDom.attr('data-city-code');
	    var scname = showContactDom.attr('data-city-name');

	    var oneLevelId = showContactDom.attr('data-province-code');
	    var twoLevelId = showContactDom.attr('data-city-code');
	    var threeLevelId = showContactDom.attr('data-district-code');
	    var iosSelect = new IosSelect(3, [areaObject.p, areaObject.c, areaObject.d], {
	      title: '',
	      itemHeight: 35,
	      relation: [1, 1, 0, 0],
	      oneLevelId: oneLevelId,
	      twoLevelId: twoLevelId,
	      threeLevelId: threeLevelId,
	      callback: function (selectOneObj, selectTwoObj, selectThreeObj) {
	        showContactDom.attr('data-province-code', selectOneObj.id);
	        showContactDom.attr('data-city-code', selectTwoObj.id);
	        showContactDom.attr('data-district-code', selectThreeObj.id);
	        showContactDom.val(selectOneObj.value + ' ' + selectTwoObj.value + ' ' + selectThreeObj.value);
	        $('.addAddress').show();
	      },
	      closeCallback: function () {
	        $('.addAddress').show();
	      }
	    });
	  });
	}

	module.exports = {
	  init: initialize
	}

	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(1)))

/***/ },

/***/ 17:
/***/ function(module, exports) {

	var iosProvinces = [
	     { "id": 1, "value": "北京", "parentId": 0},
	     { "id": 2, "value": "天津", "parentId": 0},
	     { "id": 3, "value": "河北", "parentId": 0},
	     { "id": 4, "value": "山西", "parentId": 0},
	     { "id": 5, "value": "内蒙古", "parentId": 0},
	     { "id": 6, "value": "辽宁", "parentId": 0},
	     { "id": 7, "value": "吉林", "parentId": 0},
	     { "id": 8, "value": "黑龙江", "parentId": 0},
	     { "id": 9, "value": "上海", "parentId": 0},
	     { "id": 10, "value": "江苏", "parentId": 0},
	     { "id": 11, "value": "浙江", "parentId": 0},
	     { "id": 12, "value": "安徽", "parentId": 0},
	     { "id": 13, "value": "福建", "parentId": 0},
	     { "id": 14, "value": "江西", "parentId": 0},
	     { "id": 15, "value": "山东", "parentId": 0},
	     { "id": 16, "value": "河南", "parentId": 0},
	     { "id": 17, "value": "湖北", "parentId": 0},
	     { "id": 18, "value": "湖南", "parentId": 0},
	     { "id": 19, "value": "广东", "parentId": 0},
	     { "id": 20, "value": "广西", "parentId": 0},
	     { "id": 21, "value": "海南", "parentId": 0},
	     { "id": 22, "value": "重庆", "parentId": 0},
	     { "id": 23, "value": "四川", "parentId": 0},
	     { "id": 24, "value": "贵州", "parentId": 0},
	     { "id": 25, "value": "云南", "parentId": 0},
	     { "id": 26, "value": "西藏", "parentId": 0},
	     { "id": 27, "value": "陕西", "parentId": 0},
	     { "id": 28, "value": "甘肃", "parentId": 0},
	     { "id": 29, "value": "青海", "parentId": 0},
	     { "id": 30, "value": "宁夏", "parentId": 0},
	     { "id": 31, "value": "新疆", "parentId": 0},
	     { "id": 32, "value": "台湾", "parentId": 0},
	     { "id": 33, "value": "香港", "parentId": 0},
	     { "id": 34, "value": "澳门", "parentId": 0},
	     { "id": 35, "value": "海外", "parentId": 0}
	]

	var iosCitys = [
	    {"id":36,"value":"北京市","parentId":1},
	    {"id":39,"value":"上海市","parentId":9},
	    {"id":40,"value":"天津市","parentId":2},
	    {"id":62,"value":"重庆市","parentId":22},
	    {"id":73,"value":"石家庄市","parentId":3},
	    {"id":74,"value":"唐山市","parentId":3},
	    {"id":75,"value":"秦皇岛市","parentId":3},
	    {"id":76,"value":"邯郸市","parentId":3},
	    {"id":77,"value":"邢台市","parentId":3},
	    {"id":78,"value":"保定市","parentId":3},
	    {"id":79,"value":"张家口市","parentId":3},
	    {"id":80,"value":"承德市","parentId":3},
	    {"id":81,"value":"衡水市","parentId":3},
	    {"id":82,"value":"廊坊市","parentId":3},
	    {"id":83,"value":"沧州市","parentId":3},
	    {"id":84,"value":"太原市","parentId":4},
	    {"id":85,"value":"大同市","parentId":4},
	    {"id":86,"value":"阳泉市","parentId":4},
	    {"id":87,"value":"长治市","parentId":4},
	    {"id":88,"value":"晋城市","parentId":4},
	    {"id":89,"value":"朔州市","parentId":4},
	    {"id":90,"value":"晋中市","parentId":4},
	    {"id":91,"value":"运城市","parentId":4},
	    {"id":92,"value":"忻州市","parentId":4},
	    {"id":93,"value":"临汾市","parentId":4},
	    {"id":94,"value":"吕梁市","parentId":4},
	    {"id":95,"value":"呼和浩特市","parentId":5},
	    {"id":96,"value":"包头市","parentId":5},
	    {"id":97,"value":"乌海市","parentId":5},
	    {"id":98,"value":"赤峰市","parentId":5},
	    {"id":99,"value":"通辽市","parentId":5},
	    {"id":100,"value":"鄂尔多斯市","parentId":5},
	    {"id":101,"value":"呼伦贝尔市","parentId":5},
	    {"id":102,"value":"巴彦淖尔市","parentId":5},
	    {"id":103,"value":"乌兰察布市","parentId":5},
	    {"id":104,"value":"兴安盟","parentId":5},
	    {"id":105,"value":"锡林郭勒盟","parentId":5},
	    {"id":106,"value":"阿拉善盟","parentId":5},
	    {"id":107,"value":"沈阳市","parentId":6},
	    {"id":108,"value":"大连市","parentId":6},
	    {"id":109,"value":"鞍山市","parentId":6},
	    {"id":110,"value":"抚顺市","parentId":6},
	    {"id":111,"value":"本溪市","parentId":6},
	    {"id":112,"value":"丹东市","parentId":6},
	    {"id":113,"value":"锦州市","parentId":6},
	    {"id":114,"value":"营口市","parentId":6},
	    {"id":115,"value":"阜新市","parentId":6},
	    {"id":116,"value":"辽阳市","parentId":6},
	    {"id":117,"value":"盘锦市","parentId":6},
	    {"id":118,"value":"铁岭市","parentId":6},
	    {"id":119,"value":"朝阳市","parentId":6},
	    {"id":120,"value":"葫芦岛市","parentId":6},
	    {"id":121,"value":"长春市","parentId":7},
	    {"id":122,"value":"吉林市","parentId":7},
	    {"id":123,"value":"四平市","parentId":7},
	    {"id":124,"value":"辽源市","parentId":7},
	    {"id":125,"value":"通化市","parentId":7},
	    {"id":126,"value":"白山市","parentId":7},
	    {"id":127,"value":"松原市","parentId":7},
	    {"id":128,"value":"白城市","parentId":7},
	    {"id":129,"value":"延边朝鲜族自治州","parentId":7},
	    {"id":130,"value":"哈尔滨市","parentId":8},
	    {"id":131,"value":"齐齐哈尔市","parentId":8},
	    {"id":132,"value":"鸡西市","parentId":8},
	    {"id":133,"value":"鹤岗市","parentId":8},
	    {"id":134,"value":"双鸭山市","parentId":8},
	    {"id":135,"value":"大庆市","parentId":8},
	    {"id":136,"value":"伊春市","parentId":8},
	    {"id":137,"value":"佳木斯市","parentId":8},
	    {"id":138,"value":"七台河市","parentId":8},
	    {"id":139,"value":"牡丹江市","parentId":8},
	    {"id":140,"value":"黑河市","parentId":8},
	    {"id":141,"value":"绥化市","parentId":8},
	    {"id":142,"value":"大兴安岭地区","parentId":8},
	    {"id":162,"value":"南京市","parentId":10},
	    {"id":163,"value":"无锡市","parentId":10},
	    {"id":164,"value":"徐州市","parentId":10},
	    {"id":165,"value":"常州市","parentId":10},
	    {"id":166,"value":"苏州市","parentId":10},
	    {"id":167,"value":"南通市","parentId":10},
	    {"id":168,"value":"连云港市","parentId":10},
	    {"id":169,"value":"淮安市","parentId":10},
	    {"id":170,"value":"盐城市","parentId":10},
	    {"id":171,"value":"扬州市","parentId":10},
	    {"id":172,"value":"镇江市","parentId":10},
	    {"id":173,"value":"泰州市","parentId":10},
	    {"id":174,"value":"宿迁市","parentId":10},
	    {"id":175,"value":"杭州市","parentId":11},
	    {"id":176,"value":"宁波市","parentId":11},
	    {"id":177,"value":"温州市","parentId":11},
	    {"id":178,"value":"嘉兴市","parentId":11},
	    {"id":179,"value":"湖州市","parentId":11},
	    {"id":180,"value":"绍兴市","parentId":11},
	    {"id":181,"value":"舟山市","parentId":11},
	    {"id":182,"value":"衢州市","parentId":11},
	    {"id":183,"value":"金华市","parentId":11},
	    {"id":184,"value":"台州市","parentId":11},
	    {"id":185,"value":"丽水市","parentId":11},
	    {"id":186,"value":"合肥市","parentId":12},
	    {"id":187,"value":"芜湖市","parentId":12},
	    {"id":188,"value":"蚌埠市","parentId":12},
	    {"id":189,"value":"淮南市","parentId":12},
	    {"id":190,"value":"马鞍山市","parentId":12},
	    {"id":191,"value":"淮北市","parentId":12},
	    {"id":192,"value":"铜陵市","parentId":12},
	    {"id":193,"value":"安庆市","parentId":12},
	    {"id":194,"value":"黄山市","parentId":12},
	    {"id":195,"value":"滁州市","parentId":12},
	    {"id":196,"value":"阜阳市","parentId":12},
	    {"id":197,"value":"宿州市","parentId":12},
	    {"id":198,"value":"巢湖市","parentId":12},
	    {"id":199,"value":"六安市","parentId":12},
	    {"id":200,"value":"亳州市","parentId":12},
	    {"id":201,"value":"池州市","parentId":12},
	    {"id":202,"value":"宣城市","parentId":12},
	    {"id":203,"value":"福州市","parentId":13},
	    {"id":204,"value":"厦门市","parentId":13},
	    {"id":205,"value":"莆田市","parentId":13},
	    {"id":206,"value":"三明市","parentId":13},
	    {"id":207,"value":"泉州市","parentId":13},
	    {"id":208,"value":"漳州市","parentId":13},
	    {"id":209,"value":"南平市","parentId":13},
	    {"id":210,"value":"龙岩市","parentId":13},
	    {"id":211,"value":"宁德市","parentId":13},
	    {"id":212,"value":"南昌市","parentId":14},
	    {"id":213,"value":"景德镇市","parentId":14},
	    {"id":214,"value":"萍乡市","parentId":14},
	    {"id":215,"value":"九江市","parentId":14},
	    {"id":216,"value":"新余市","parentId":14},
	    {"id":217,"value":"鹰潭市","parentId":14},
	    {"id":218,"value":"赣州市","parentId":14},
	    {"id":219,"value":"吉安市","parentId":14},
	    {"id":220,"value":"宜春市","parentId":14},
	    {"id":221,"value":"抚州市","parentId":14},
	    {"id":222,"value":"上饶市","parentId":14},
	    {"id":223,"value":"济南市","parentId":15},
	    {"id":224,"value":"青岛市","parentId":15},
	    {"id":225,"value":"淄博市","parentId":15},
	    {"id":226,"value":"枣庄市","parentId":15},
	    {"id":227,"value":"东营市","parentId":15},
	    {"id":228,"value":"烟台市","parentId":15},
	    {"id":229,"value":"潍坊市","parentId":15},
	    {"id":230,"value":"济宁市","parentId":15},
	    {"id":231,"value":"泰安市","parentId":15},
	    {"id":232,"value":"威海市","parentId":15},
	    {"id":233,"value":"日照市","parentId":15},
	    {"id":234,"value":"莱芜市","parentId":15},
	    {"id":235,"value":"临沂市","parentId":15},
	    {"id":236,"value":"德州市","parentId":15},
	    {"id":237,"value":"聊城市","parentId":15},
	    {"id":238,"value":"滨州市","parentId":15},
	    {"id":239,"value":"菏泽市","parentId":15},
	    {"id":240,"value":"郑州市","parentId":16},
	    {"id":241,"value":"开封市","parentId":16},
	    {"id":242,"value":"洛阳市","parentId":16},
	    {"id":243,"value":"平顶山市","parentId":16},
	    {"id":244,"value":"安阳市","parentId":16},
	    {"id":245,"value":"鹤壁市","parentId":16},
	    {"id":246,"value":"新乡市","parentId":16},
	    {"id":247,"value":"焦作市","parentId":16},
	    {"id":248,"value":"濮阳市","parentId":16},
	    {"id":249,"value":"许昌市","parentId":16},
	    {"id":250,"value":"漯河市","parentId":16},
	    {"id":251,"value":"三门峡市","parentId":16},
	    {"id":252,"value":"南阳市","parentId":16},
	    {"id":253,"value":"商丘市","parentId":16},
	    {"id":254,"value":"信阳市","parentId":16},
	    {"id":255,"value":"周口市","parentId":16},
	    {"id":256,"value":"驻马店市","parentId":16},
	    {"id":257,"value":"济源市","parentId":16},
	    {"id":258,"value":"武汉市","parentId":17},
	    {"id":259,"value":"黄石市","parentId":17},
	    {"id":260,"value":"十堰市","parentId":17},
	    {"id":261,"value":"宜昌市","parentId":17},
	    {"id":262,"value":"襄樊市","parentId":17},
	    {"id":263,"value":"鄂州市","parentId":17},
	    {"id":264,"value":"荆门市","parentId":17},
	    {"id":265,"value":"孝感市","parentId":17},
	    {"id":266,"value":"荆州市","parentId":17},
	    {"id":267,"value":"黄冈市","parentId":17},
	    {"id":268,"value":"咸宁市","parentId":17},
	    {"id":269,"value":"随州市","parentId":17},
	    {"id":270,"value":"恩施土家族苗族自治州","parentId":17},
	    {"id":271,"value":"仙桃市","parentId":17},
	    {"id":272,"value":"潜江市","parentId":17},
	    {"id":273,"value":"天门市","parentId":17},
	    {"id":274,"value":"神农架林区","parentId":17},
	    {"id":275,"value":"长沙市","parentId":18},
	    {"id":276,"value":"株洲市","parentId":18},
	    {"id":277,"value":"湘潭市","parentId":18},
	    {"id":278,"value":"衡阳市","parentId":18},
	    {"id":279,"value":"邵阳市","parentId":18},
	    {"id":280,"value":"岳阳市","parentId":18},
	    {"id":281,"value":"常德市","parentId":18},
	    {"id":282,"value":"张家界市","parentId":18},
	    {"id":283,"value":"益阳市","parentId":18},
	    {"id":284,"value":"郴州市","parentId":18},
	    {"id":285,"value":"永州市","parentId":18},
	    {"id":286,"value":"怀化市","parentId":18},
	    {"id":287,"value":"娄底市","parentId":18},
	    {"id":288,"value":"湘西土家族苗族自治州","parentId":18},
	    {"id":289,"value":"广州市","parentId":19},
	    {"id":290,"value":"韶关市","parentId":19},
	    {"id":291,"value":"深圳市","parentId":19},
	    {"id":292,"value":"珠海市","parentId":19},
	    {"id":293,"value":"汕头市","parentId":19},
	    {"id":294,"value":"佛山市","parentId":19},
	    {"id":295,"value":"江门市","parentId":19},
	    {"id":296,"value":"湛江市","parentId":19},
	    {"id":297,"value":"茂名市","parentId":19},
	    {"id":298,"value":"肇庆市","parentId":19},
	    {"id":299,"value":"惠州市","parentId":19},
	    {"id":300,"value":"梅州市","parentId":19},
	    {"id":301,"value":"汕尾市","parentId":19},
	    {"id":302,"value":"河源市","parentId":19},
	    {"id":303,"value":"阳江市","parentId":19},
	    {"id":304,"value":"清远市","parentId":19},
	    {"id":305,"value":"东莞市","parentId":19},
	    {"id":306,"value":"中山市","parentId":19},
	    {"id":307,"value":"潮州市","parentId":19},
	    {"id":308,"value":"揭阳市","parentId":19},
	    {"id":309,"value":"云浮市","parentId":19},
	    {"id":310,"value":"南宁市","parentId":20},
	    {"id":311,"value":"柳州市","parentId":20},
	    {"id":312,"value":"桂林市","parentId":20},
	    {"id":313,"value":"梧州市","parentId":20},
	    {"id":314,"value":"北海市","parentId":20},
	    {"id":315,"value":"防城港市","parentId":20},
	    {"id":316,"value":"钦州市","parentId":20},
	    {"id":317,"value":"贵港市","parentId":20},
	    {"id":318,"value":"玉林市","parentId":20},
	    {"id":319,"value":"百色市","parentId":20},
	    {"id":320,"value":"贺州市","parentId":20},
	    {"id":321,"value":"河池市","parentId":20},
	    {"id":322,"value":"来宾市","parentId":20},
	    {"id":323,"value":"崇左市","parentId":20},
	    {"id":324,"value":"海口市","parentId":21},
	    {"id":325,"value":"三亚市","parentId":21},
	    {"id":326,"value":"五指山市","parentId":21},
	    {"id":327,"value":"琼海市","parentId":21},
	    {"id":328,"value":"儋州市","parentId":21},
	    {"id":329,"value":"文昌市","parentId":21},
	    {"id":330,"value":"万宁市","parentId":21},
	    {"id":331,"value":"东方市","parentId":21},
	    {"id":332,"value":"定安县","parentId":21},
	    {"id":333,"value":"屯昌县","parentId":21},
	    {"id":334,"value":"澄迈县","parentId":21},
	    {"id":335,"value":"临高县","parentId":21},
	    {"id":336,"value":"白沙黎族自治县","parentId":21},
	    {"id":337,"value":"昌江黎族自治县","parentId":21},
	    {"id":338,"value":"乐东黎族自治县","parentId":21},
	    {"id":339,"value":"陵水黎族自治县","parentId":21},
	    {"id":340,"value":"保亭黎族苗族自治县","parentId":21},
	    {"id":341,"value":"琼中黎族苗族自治县","parentId":21},
	    {"id":342,"value":"西沙群岛","parentId":21},
	    {"id":343,"value":"南沙群岛","parentId":21},
	    {"id":344,"value":"中沙群岛的岛礁及其海域","parentId":21},
	    {"id":385,"value":"成都市","parentId":23},
	    {"id":386,"value":"自贡市","parentId":23},
	    {"id":387,"value":"攀枝花市","parentId":23},
	    {"id":388,"value":"泸州市","parentId":23},
	    {"id":389,"value":"德阳市","parentId":23},
	    {"id":390,"value":"绵阳市","parentId":23},
	    {"id":391,"value":"广元市","parentId":23},
	    {"id":392,"value":"遂宁市","parentId":23},
	    {"id":393,"value":"内江市","parentId":23},
	    {"id":394,"value":"乐山市","parentId":23},
	    {"id":395,"value":"南充市","parentId":23},
	    {"id":396,"value":"眉山市","parentId":23},
	    {"id":397,"value":"宜宾市","parentId":23},
	    {"id":398,"value":"广安市","parentId":23},
	    {"id":399,"value":"达州市","parentId":23},
	    {"id":400,"value":"雅安市","parentId":23},
	    {"id":401,"value":"巴中市","parentId":23},
	    {"id":402,"value":"资阳市","parentId":23},
	    {"id":403,"value":"阿坝藏族羌族自治州","parentId":23},
	    {"id":404,"value":"甘孜藏族自治州","parentId":23},
	    {"id":405,"value":"凉山彝族自治州","parentId":23},
	    {"id":406,"value":"贵阳市","parentId":24},
	    {"id":407,"value":"六盘水市","parentId":24},
	    {"id":408,"value":"遵义市","parentId":24},
	    {"id":409,"value":"安顺市","parentId":24},
	    {"id":410,"value":"铜仁地区","parentId":24},
	    {"id":411,"value":"黔西南布依族苗族自治州","parentId":24},
	    {"id":412,"value":"毕节地区","parentId":24},
	    {"id":413,"value":"黔东南苗族侗族自治州","parentId":24},
	    {"id":414,"value":"黔南布依族苗族自治州","parentId":24},
	    {"id":415,"value":"昆明市","parentId":25},
	    {"id":416,"value":"曲靖市","parentId":25},
	    {"id":417,"value":"玉溪市","parentId":25},
	    {"id":418,"value":"保山市","parentId":25},
	    {"id":419,"value":"昭通市","parentId":25},
	    {"id":420,"value":"丽江市","parentId":25},
	    {"id":421,"value":"思茅市","parentId":25},
	    {"id":422,"value":"临沧市","parentId":25},
	    {"id":423,"value":"楚雄彝族自治州","parentId":25},
	    {"id":424,"value":"红河哈尼族彝族自治州","parentId":25},
	    {"id":425,"value":"文山壮族苗族自治州","parentId":25},
	    {"id":426,"value":"西双版纳傣族自治州","parentId":25},
	    {"id":427,"value":"大理白族自治州","parentId":25},
	    {"id":428,"value":"德宏傣族景颇族自治州","parentId":25},
	    {"id":429,"value":"怒江傈僳族自治州","parentId":25},
	    {"id":430,"value":"迪庆藏族自治州","parentId":25},
	    {"id":431,"value":"拉萨市","parentId":26},
	    {"id":432,"value":"昌都地区","parentId":26},
	    {"id":433,"value":"山南地区","parentId":26},
	    {"id":434,"value":"日喀则地区","parentId":26},
	    {"id":435,"value":"那曲地区","parentId":26},
	    {"id":436,"value":"阿里地区","parentId":26},
	    {"id":437,"value":"林芝地区","parentId":26},
	    {"id":438,"value":"西安市","parentId":27},
	    {"id":439,"value":"铜川市","parentId":27},
	    {"id":440,"value":"宝鸡市","parentId":27},
	    {"id":441,"value":"咸阳市","parentId":27},
	    {"id":442,"value":"渭南市","parentId":27},
	    {"id":443,"value":"延安市","parentId":27},
	    {"id":444,"value":"汉中市","parentId":27},
	    {"id":445,"value":"榆林市","parentId":27},
	    {"id":446,"value":"安康市","parentId":27},
	    {"id":447,"value":"商洛市","parentId":27},
	    {"id":448,"value":"兰州市","parentId":28},
	    {"id":449,"value":"嘉峪关市","parentId":28},
	    {"id":450,"value":"金昌市","parentId":28},
	    {"id":451,"value":"白银市","parentId":28},
	    {"id":452,"value":"天水市","parentId":28},
	    {"id":453,"value":"武威市","parentId":28},
	    {"id":454,"value":"张掖市","parentId":28},
	    {"id":455,"value":"平凉市","parentId":28},
	    {"id":456,"value":"酒泉市","parentId":28},
	    {"id":457,"value":"庆阳市","parentId":28},
	    {"id":458,"value":"定西市","parentId":28},
	    {"id":459,"value":"陇南市","parentId":28},
	    {"id":460,"value":"临夏回族自治州","parentId":28},
	    {"id":461,"value":"甘南藏族自治州","parentId":28},
	    {"id":462,"value":"西宁市","parentId":29},
	    {"id":463,"value":"海东地区","parentId":29},
	    {"id":464,"value":"海北藏族自治州","parentId":29},
	    {"id":465,"value":"黄南藏族自治州","parentId":29},
	    {"id":466,"value":"海南藏族自治州","parentId":29},
	    {"id":467,"value":"果洛藏族自治州","parentId":29},
	    {"id":468,"value":"玉树藏族自治州","parentId":29},
	    {"id":469,"value":"海西蒙古族藏族自治州","parentId":29},
	    {"id":470,"value":"银川市","parentId":30},
	    {"id":471,"value":"石嘴山市","parentId":30},
	    {"id":472,"value":"吴忠市","parentId":30},
	    {"id":473,"value":"固原市","parentId":30},
	    {"id":474,"value":"中卫市","parentId":30},
	    {"id":475,"value":"乌鲁木齐市","parentId":31},
	    {"id":476,"value":"克拉玛依市","parentId":31},
	    {"id":477,"value":"吐鲁番地区","parentId":31},
	    {"id":478,"value":"哈密地区","parentId":31},
	    {"id":479,"value":"昌吉回族自治州","parentId":31},
	    {"id":480,"value":"博尔塔拉蒙古自治州","parentId":31},
	    {"id":481,"value":"巴音郭楞蒙古自治州","parentId":31},
	    {"id":482,"value":"阿克苏地区","parentId":31},
	    {"id":483,"value":"克孜勒苏柯尔克孜自治州","parentId":31},
	    {"id":484,"value":"喀什地区","parentId":31},
	    {"id":485,"value":"和田地区","parentId":31},
	    {"id":486,"value":"伊犁哈萨克自治州","parentId":31},
	    {"id":487,"value":"塔城地区","parentId":31},
	    {"id":488,"value":"阿勒泰地区","parentId":31},
	    {"id":489,"value":"石河子市","parentId":31},
	    {"id":490,"value":"阿拉尔市","parentId":31},
	    {"id":491,"value":"图木舒克市","parentId":31},
	    {"id":492,"value":"五家渠市","parentId":31},
	    {"id":493,"value":"台北市","parentId":32},
	    {"id":494,"value":"高雄市","parentId":32},
	    {"id":495,"value":"基隆市","parentId":32},
	    {"id":496,"value":"台中市","parentId":32},
	    {"id":497,"value":"台南市","parentId":32},
	    {"id":498,"value":"新竹市","parentId":32},
	    {"id":499,"value":"嘉义市","parentId":32},
	    {"id":500,"value":"台北县","parentId":32},
	    {"id":501,"value":"宜兰县","parentId":32},
	    {"id":502,"value":"桃园县","parentId":32},
	    {"id":503,"value":"新竹县","parentId":32},
	    {"id":504,"value":"苗栗县","parentId":32},
	    {"id":505,"value":"台中县","parentId":32},
	    {"id":506,"value":"彰化县","parentId":32},
	    {"id":507,"value":"南投县","parentId":32},
	    {"id":508,"value":"云林县","parentId":32},
	    {"id":509,"value":"嘉义县","parentId":32},
	    {"id":510,"value":"台南县","parentId":32},
	    {"id":511,"value":"高雄县","parentId":32},
	    {"id":512,"value":"屏东县","parentId":32},
	    {"id":513,"value":"澎湖县","parentId":32},
	    {"id":514,"value":"台东县","parentId":32},
	    {"id":515,"value":"花莲县","parentId":32},
	    {"id":516,"value":"中西区","parentId":33},
	    {"id":517,"value":"东区","parentId":33},
	    {"id":518,"value":"九龙城区","parentId":33},
	    {"id":519,"value":"观塘区","parentId":33},
	    {"id":520,"value":"南区","parentId":33},
	    {"id":521,"value":"深水埗区","parentId":33},
	    {"id":522,"value":"黄大仙区","parentId":33},
	    {"id":523,"value":"湾仔区","parentId":33},
	    {"id":524,"value":"油尖旺区","parentId":33},
	    {"id":525,"value":"离岛区","parentId":33},
	    {"id":526,"value":"葵青区","parentId":33},
	    {"id":527,"value":"北区","parentId":33},
	    {"id":528,"value":"西贡区","parentId":33},
	    {"id":529,"value":"沙田区","parentId":33},
	    {"id":530,"value":"屯门区","parentId":33},
	    {"id":531,"value":"大埔区","parentId":33},
	    {"id":532,"value":"荃湾区","parentId":33},
	    {"id":533,"value":"元朗区","parentId":33},
	    {"id":534,"value":"澳门特别行政区","parentId":34},
	    {"id":45055,"value":"海外","parentId":35}
	]

	var iosCountys = [
	    {"id":37,"value":"东城区","parentId":36},
	    {"id":38,"value":"西城区","parentId":36},
	    {"id":41,"value":"朝阳区","parentId":36},
	    {"id":42,"value":"丰台区","parentId":36},
	    {"id":43,"value":"石景山区","parentId":36},
	    {"id":44,"value":"海淀区","parentId":36},
	    {"id":45,"value":"门头沟区","parentId":36},
	    {"id":46,"value":"房山区","parentId":36},
	    {"id":47,"value":"通州区","parentId":36},
	    {"id":48,"value":"顺义区","parentId":36},
	    {"id":49,"value":"昌平区","parentId":36},
	    {"id":50,"value":"大兴区","parentId":36},
	    {"id":51,"value":"怀柔区","parentId":36},
	    {"id":52,"value":"平谷区","parentId":36},
	    {"id":53,"value":"密云县","parentId":36},
	    {"id":54,"value":"延庆县","parentId":36},
	    {"id":55,"value":"和平区","parentId":40},
	    {"id":56,"value":"河东区","parentId":40},
	    {"id":57,"value":"河西区","parentId":40},
	    {"id":58,"value":"南开区","parentId":40},
	    {"id":59,"value":"河北区","parentId":40},
	    {"id":60,"value":"红桥区","parentId":40},
	    {"id":61,"value":"塘沽区","parentId":40},
	    {"id":64,"value":"东丽区","parentId":40},
	    {"id":65,"value":"西青区","parentId":40},
	    {"id":66,"value":"津南区","parentId":40},
	    {"id":67,"value":"北辰区","parentId":40},
	    {"id":68,"value":"武清区","parentId":40},
	    {"id":69,"value":"宝坻区","parentId":40},
	    {"id":70,"value":"宁河县","parentId":40},
	    {"id":71,"value":"静海县","parentId":40},
	    {"id":72,"value":"蓟县","parentId":40},
	    {"id":143,"value":"黄浦区","parentId":39},
	    {"id":144,"value":"卢湾区","parentId":39},
	    {"id":145,"value":"徐汇区","parentId":39},
	    {"id":146,"value":"长宁区","parentId":39},
	    {"id":147,"value":"静安区","parentId":39},
	    {"id":148,"value":"普陀区","parentId":39},
	    {"id":149,"value":"闸北区","parentId":39},
	    {"id":150,"value":"虹口区","parentId":39},
	    {"id":151,"value":"杨浦区","parentId":39},
	    {"id":152,"value":"闵行区","parentId":39},
	    {"id":153,"value":"宝山区","parentId":39},
	    {"id":154,"value":"嘉定区","parentId":39},
	    {"id":155,"value":"浦东新区","parentId":39},
	    {"id":156,"value":"金山区","parentId":39},
	    {"id":157,"value":"松江区","parentId":39},
	    {"id":158,"value":"青浦区","parentId":39},
	    {"id":159,"value":"南汇区","parentId":39},
	    {"id":160,"value":"奉贤区","parentId":39},
	    {"id":161,"value":"崇明县","parentId":39},
	    {"id":345,"value":"万州区","parentId":62},
	    {"id":346,"value":"涪陵区","parentId":62},
	    {"id":347,"value":"渝中区","parentId":62},
	    {"id":348,"value":"大渡口区","parentId":62},
	    {"id":349,"value":"江北区","parentId":62},
	    {"id":350,"value":"沙坪坝区","parentId":62},
	    {"id":351,"value":"九龙坡区","parentId":62},
	    {"id":352,"value":"南岸区","parentId":62},
	    {"id":353,"value":"北碚区","parentId":62},
	    {"id":354,"value":"双桥区","parentId":62},
	    {"id":355,"value":"万盛区","parentId":62},
	    {"id":356,"value":"渝北区","parentId":62},
	    {"id":357,"value":"巴南区","parentId":62},
	    {"id":358,"value":"黔江区","parentId":62},
	    {"id":359,"value":"长寿区","parentId":62},
	    {"id":360,"value":"綦江县","parentId":62},
	    {"id":361,"value":"潼南县","parentId":62},
	    {"id":362,"value":"铜梁县","parentId":62},
	    {"id":363,"value":"大足县","parentId":62},
	    {"id":364,"value":"荣昌县","parentId":62},
	    {"id":365,"value":"璧山县","parentId":62},
	    {"id":366,"value":"梁平县","parentId":62},
	    {"id":367,"value":"城口县","parentId":62},
	    {"id":368,"value":"丰都县","parentId":62},
	    {"id":369,"value":"垫江县","parentId":62},
	    {"id":370,"value":"武隆县","parentId":62},
	    {"id":371,"value":"忠县","parentId":62},
	    {"id":372,"value":"开县","parentId":62},
	    {"id":373,"value":"云阳县","parentId":62},
	    {"id":374,"value":"奉节县","parentId":62},
	    {"id":375,"value":"巫山县","parentId":62},
	    {"id":376,"value":"巫溪县","parentId":62},
	    {"id":377,"value":"石柱土家族自治县","parentId":62},
	    {"id":378,"value":"秀山土家族苗族自治县","parentId":62},
	    {"id":379,"value":"酉阳土家族苗族自治县","parentId":62},
	    {"id":380,"value":"彭水苗族土家族自治县","parentId":62},
	    {"id":381,"value":"江津市","parentId":62},
	    {"id":382,"value":"合川市","parentId":62},
	    {"id":383,"value":"永川市","parentId":62},
	    {"id":384,"value":"南川市","parentId":62},
	    {"id":535,"value":"美国","parentId":45055},
	    {"id":536,"value":"加拿大","parentId":45055},
	    {"id":537,"value":"澳大利亚","parentId":45055},
	    {"id":538,"value":"新西兰","parentId":45055},
	    {"id":539,"value":"英国","parentId":45055},
	    {"id":540,"value":"法国","parentId":45055},
	    {"id":541,"value":"德国","parentId":45055},
	    {"id":542,"value":"捷克","parentId":45055},
	    {"id":543,"value":"荷兰","parentId":45055},
	    {"id":544,"value":"瑞士","parentId":45055},
	    {"id":545,"value":"希腊","parentId":45055},
	    {"id":546,"value":"挪威","parentId":45055},
	    {"id":547,"value":"瑞典","parentId":45055},
	    {"id":548,"value":"丹麦","parentId":45055},
	    {"id":549,"value":"芬兰","parentId":45055},
	    {"id":550,"value":"爱尔兰","parentId":45055},
	    {"id":551,"value":"奥地利","parentId":45055},
	    {"id":552,"value":"意大利","parentId":45055},
	    {"id":553,"value":"乌克兰","parentId":45055},
	    {"id":554,"value":"俄罗斯","parentId":45055},
	    {"id":555,"value":"西班牙","parentId":45055},
	    {"id":556,"value":"韩国","parentId":45055},
	    {"id":557,"value":"新加坡","parentId":45055},
	    {"id":558,"value":"马来西亚","parentId":45055},
	    {"id":559,"value":"印度","parentId":45055},
	    {"id":560,"value":"泰国","parentId":45055},
	    {"id":561,"value":"日本","parentId":45055},
	    {"id":562,"value":"巴西","parentId":45055},
	    {"id":563,"value":"阿根廷","parentId":45055},
	    {"id":564,"value":"南非","parentId":45055},
	    {"id":565,"value":"埃及","parentId":45055},
	    {"id":566,"value":"其他","parentId":36},
	    {"id":1126,"value":"井陉县","parentId":73},
	    {"id":1127,"value":"井陉矿区","parentId":73},
	    {"id":1128,"value":"元氏县","parentId":73},
	    {"id":1129,"value":"平山县","parentId":73},
	    {"id":1130,"value":"新乐市","parentId":73},
	    {"id":1131,"value":"新华区","parentId":73},
	    {"id":1132,"value":"无极县","parentId":73},
	    {"id":1133,"value":"晋州市","parentId":73},
	    {"id":1134,"value":"栾城县","parentId":73},
	    {"id":1135,"value":"桥东区","parentId":73},
	    {"id":1136,"value":"桥西区","parentId":73},
	    {"id":1137,"value":"正定县","parentId":73},
	    {"id":1138,"value":"深泽县","parentId":73},
	    {"id":1139,"value":"灵寿县","parentId":73},
	    {"id":1140,"value":"藁城市","parentId":73},
	    {"id":1141,"value":"行唐县","parentId":73},
	    {"id":1142,"value":"裕华区","parentId":73},
	    {"id":1143,"value":"赞皇县","parentId":73},
	    {"id":1144,"value":"赵县","parentId":73},
	    {"id":1145,"value":"辛集市","parentId":73},
	    {"id":1146,"value":"长安区","parentId":73},
	    {"id":1147,"value":"高邑县","parentId":73},
	    {"id":1148,"value":"鹿泉市","parentId":73},
	    {"id":1149,"value":"丰南区","parentId":74},
	    {"id":1150,"value":"丰润区","parentId":74},
	    {"id":1151,"value":"乐亭县","parentId":74},
	    {"id":1152,"value":"古冶区","parentId":74},
	    {"id":1153,"value":"唐海县","parentId":74},
	    {"id":1154,"value":"开平区","parentId":74},
	    {"id":1155,"value":"滦南县","parentId":74},
	    {"id":1156,"value":"滦县","parentId":74},
	    {"id":1157,"value":"玉田县","parentId":74},
	    {"id":1158,"value":"路北区","parentId":74},
	    {"id":1159,"value":"路南区","parentId":74},
	    {"id":1160,"value":"迁安市","parentId":74},
	    {"id":1161,"value":"迁西县","parentId":74},
	    {"id":1162,"value":"遵化市","parentId":74},
	    {"id":1163,"value":"北戴河区","parentId":75},
	    {"id":1164,"value":"卢龙县","parentId":75},
	    {"id":1165,"value":"山海关区","parentId":75},
	    {"id":1166,"value":"抚宁县","parentId":75},
	    {"id":1167,"value":"昌黎县","parentId":75},
	    {"id":1168,"value":"海港区","parentId":75},
	    {"id":1169,"value":"青龙满族自治县","parentId":75},
	    {"id":1170,"value":"丛台区","parentId":76},
	    {"id":1171,"value":"临漳县","parentId":76},
	    {"id":1172,"value":"复兴区","parentId":76},
	    {"id":1173,"value":"大名县","parentId":76},
	    {"id":1174,"value":"峰峰矿区","parentId":76},
	    {"id":1175,"value":"广平县","parentId":76},
	    {"id":1176,"value":"成安县","parentId":76},
	    {"id":1177,"value":"曲周县","parentId":76},
	    {"id":1178,"value":"武安市","parentId":76},
	    {"id":1179,"value":"永年县","parentId":76},
	    {"id":1180,"value":"涉县","parentId":76},
	    {"id":1181,"value":"磁县","parentId":76},
	    {"id":1182,"value":"肥乡县","parentId":76},
	    {"id":1183,"value":"邯山区","parentId":76},
	    {"id":1184,"value":"邯郸县","parentId":76},
	    {"id":1185,"value":"邱县","parentId":76},
	    {"id":1186,"value":"馆陶县","parentId":76},
	    {"id":1187,"value":"魏县","parentId":76},
	    {"id":1188,"value":"鸡泽县","parentId":76},
	    {"id":1189,"value":"临城县","parentId":77},
	    {"id":1190,"value":"临西县","parentId":77},
	    {"id":1191,"value":"任县","parentId":77},
	    {"id":1192,"value":"内丘县","parentId":77},
	    {"id":1193,"value":"南和县","parentId":77},
	    {"id":1194,"value":"南宫市","parentId":77},
	    {"id":1195,"value":"威县","parentId":77},
	    {"id":1196,"value":"宁晋县","parentId":77},
	    {"id":1197,"value":"巨鹿县","parentId":77},
	    {"id":1198,"value":"平乡县","parentId":77},
	    {"id":1199,"value":"广宗县","parentId":77},
	    {"id":1200,"value":"新河县","parentId":77},
	    {"id":1201,"value":"柏乡县","parentId":77},
	    {"id":1202,"value":"桥东区","parentId":77},
	    {"id":1203,"value":"桥西区","parentId":77},
	    {"id":1204,"value":"沙河市","parentId":77},
	    {"id":1205,"value":"清河县","parentId":77},
	    {"id":1206,"value":"邢台县","parentId":77},
	    {"id":1207,"value":"隆尧县","parentId":77},
	    {"id":1208,"value":"北市区","parentId":78},
	    {"id":1209,"value":"南市区","parentId":78},
	    {"id":1210,"value":"博野县","parentId":78},
	    {"id":1211,"value":"唐县","parentId":78},
	    {"id":1212,"value":"安国市","parentId":78},
	    {"id":1213,"value":"安新县","parentId":78},
	    {"id":1214,"value":"定兴县","parentId":78},
	    {"id":1215,"value":"定州市","parentId":78},
	    {"id":1216,"value":"容城县","parentId":78},
	    {"id":1217,"value":"徐水县","parentId":78},
	    {"id":1218,"value":"新市区","parentId":78},
	    {"id":1219,"value":"易县","parentId":78},
	    {"id":1220,"value":"曲阳县","parentId":78},
	    {"id":1221,"value":"望都县","parentId":78},
	    {"id":1222,"value":"涞水县","parentId":78},
	    {"id":1223,"value":"涞源县","parentId":78},
	    {"id":1224,"value":"涿州市","parentId":78},
	    {"id":1225,"value":"清苑县","parentId":78},
	    {"id":1226,"value":"满城县","parentId":78},
	    {"id":1227,"value":"蠡县","parentId":78},
	    {"id":1228,"value":"阜平县","parentId":78},
	    {"id":1229,"value":"雄县","parentId":78},
	    {"id":1230,"value":"顺平县","parentId":78},
	    {"id":1231,"value":"高碑店市","parentId":78},
	    {"id":1232,"value":"高阳县","parentId":78},
	    {"id":1233,"value":"万全县","parentId":79},
	    {"id":1234,"value":"下花园区","parentId":79},
	    {"id":1235,"value":"宣化区","parentId":79},
	    {"id":1236,"value":"宣化县","parentId":79},
	    {"id":1237,"value":"尚义县","parentId":79},
	    {"id":1238,"value":"崇礼县","parentId":79},
	    {"id":1239,"value":"康保县","parentId":79},
	    {"id":1240,"value":"张北县","parentId":79},
	    {"id":1241,"value":"怀安县","parentId":79},
	    {"id":1242,"value":"怀来县","parentId":79},
	    {"id":1243,"value":"桥东区","parentId":79},
	    {"id":1244,"value":"桥西区","parentId":79},
	    {"id":1245,"value":"沽源县","parentId":79},
	    {"id":1246,"value":"涿鹿县","parentId":79},
	    {"id":1247,"value":"蔚县","parentId":79},
	    {"id":1248,"value":"赤城县","parentId":79},
	    {"id":1249,"value":"阳原县","parentId":79},
	    {"id":1250,"value":"丰宁满族自治县","parentId":80},
	    {"id":1251,"value":"兴隆县","parentId":80},
	    {"id":1252,"value":"双桥区","parentId":80},
	    {"id":1253,"value":"双滦区","parentId":80},
	    {"id":1254,"value":"围场满族蒙古族自治县","parentId":80},
	    {"id":1255,"value":"宽城满族自治县","parentId":80},
	    {"id":1256,"value":"平泉县","parentId":80},
	    {"id":1257,"value":"承德县","parentId":80},
	    {"id":1258,"value":"滦平县","parentId":80},
	    {"id":1259,"value":"隆化县","parentId":80},
	    {"id":1260,"value":"鹰手营子矿区","parentId":80},
	    {"id":1261,"value":"冀州市","parentId":81},
	    {"id":1262,"value":"安平县","parentId":81},
	    {"id":1263,"value":"故城县","parentId":81},
	    {"id":1264,"value":"景县","parentId":81},
	    {"id":1265,"value":"枣强县","parentId":81},
	    {"id":1266,"value":"桃城区","parentId":81},
	    {"id":1267,"value":"武强县","parentId":81},
	    {"id":1268,"value":"武邑县","parentId":81},
	    {"id":1269,"value":"深州市","parentId":81},
	    {"id":1270,"value":"阜城县","parentId":81},
	    {"id":1271,"value":"饶阳县","parentId":81},
	    {"id":1272,"value":"三河市","parentId":82},
	    {"id":1273,"value":"固安县","parentId":82},
	    {"id":1274,"value":"大厂回族自治县","parentId":82},
	    {"id":1275,"value":"大城县","parentId":82},
	    {"id":1276,"value":"安次区","parentId":82},
	    {"id":1277,"value":"广阳区","parentId":82},
	    {"id":1278,"value":"文安县","parentId":82},
	    {"id":1279,"value":"永清县","parentId":82},
	    {"id":1280,"value":"霸州市","parentId":82},
	    {"id":1281,"value":"香河县","parentId":82},
	    {"id":1282,"value":"东光县","parentId":83},
	    {"id":1283,"value":"任丘市","parentId":83},
	    {"id":1284,"value":"南皮县","parentId":83},
	    {"id":1285,"value":"吴桥县","parentId":83},
	    {"id":1286,"value":"孟村回族自治县","parentId":83},
	    {"id":1287,"value":"新华区","parentId":83},
	    {"id":1288,"value":"沧县","parentId":83},
	    {"id":1289,"value":"河间市","parentId":83},
	    {"id":1290,"value":"泊头市","parentId":83},
	    {"id":1291,"value":"海兴县","parentId":83},
	    {"id":1292,"value":"献县","parentId":83},
	    {"id":1293,"value":"盐山县","parentId":83},
	    {"id":1294,"value":"肃宁县","parentId":83},
	    {"id":1295,"value":"运河区","parentId":83},
	    {"id":1296,"value":"青县","parentId":83},
	    {"id":1297,"value":"黄骅市","parentId":83},
	    {"id":1298,"value":"万柏林区","parentId":84},
	    {"id":1299,"value":"古交市","parentId":84},
	    {"id":1300,"value":"娄烦县","parentId":84},
	    {"id":1301,"value":"小店区","parentId":84},
	    {"id":1302,"value":"尖草坪区","parentId":84},
	    {"id":1303,"value":"晋源区","parentId":84},
	    {"id":1304,"value":"杏花岭区","parentId":84},
	    {"id":1305,"value":"清徐县","parentId":84},
	    {"id":1306,"value":"迎泽区","parentId":84},
	    {"id":1307,"value":"阳曲县","parentId":84},
	    {"id":1308,"value":"南郊区","parentId":85},
	    {"id":1309,"value":"城区","parentId":85},
	    {"id":1310,"value":"大同县","parentId":85},
	    {"id":1311,"value":"天镇县","parentId":85},
	    {"id":1312,"value":"左云县","parentId":85},
	    {"id":1313,"value":"广灵县","parentId":85},
	    {"id":1314,"value":"新荣区","parentId":85},
	    {"id":1315,"value":"浑源县","parentId":85},
	    {"id":1316,"value":"灵丘县","parentId":85},
	    {"id":1317,"value":"矿区","parentId":85},
	    {"id":1318,"value":"阳高县","parentId":85},
	    {"id":1319,"value":"城区","parentId":86},
	    {"id":1320,"value":"平定县","parentId":86},
	    {"id":1321,"value":"盂县","parentId":86},
	    {"id":1322,"value":"矿区","parentId":86},
	    {"id":1323,"value":"郊区","parentId":86},
	    {"id":1324,"value":"城区","parentId":87},
	    {"id":1325,"value":"壶关县","parentId":87},
	    {"id":1326,"value":"屯留县","parentId":87},
	    {"id":1327,"value":"平顺县","parentId":87},
	    {"id":1328,"value":"武乡县","parentId":87},
	    {"id":1329,"value":"沁县","parentId":87},
	    {"id":1330,"value":"沁源县","parentId":87},
	    {"id":1331,"value":"潞城市","parentId":87},
	    {"id":1332,"value":"襄垣县","parentId":87},
	    {"id":1333,"value":"郊区","parentId":87},
	    {"id":1334,"value":"长子县","parentId":87},
	    {"id":1335,"value":"长治县","parentId":87},
	    {"id":1336,"value":"黎城县","parentId":87},
	    {"id":1337,"value":"城区","parentId":88},
	    {"id":1338,"value":"沁水县","parentId":88},
	    {"id":1339,"value":"泽州县","parentId":88},
	    {"id":1340,"value":"阳城县","parentId":88},
	    {"id":1341,"value":"陵川县","parentId":88},
	    {"id":1342,"value":"高平市","parentId":88},
	    {"id":1343,"value":"右玉县","parentId":89},
	    {"id":1344,"value":"山阴县","parentId":89},
	    {"id":1345,"value":"平鲁区","parentId":89},
	    {"id":1346,"value":"应县","parentId":89},
	    {"id":1347,"value":"怀仁县","parentId":89},
	    {"id":1348,"value":"朔城区","parentId":89},
	    {"id":1349,"value":"介休市","parentId":90},
	    {"id":1350,"value":"和顺县","parentId":90},
	    {"id":1351,"value":"太谷县","parentId":90},
	    {"id":1352,"value":"寿阳县","parentId":90},
	    {"id":1353,"value":"左权县","parentId":90},
	    {"id":1354,"value":"平遥县","parentId":90},
	    {"id":1355,"value":"昔阳县","parentId":90},
	    {"id":1356,"value":"榆次区","parentId":90},
	    {"id":1357,"value":"榆社县","parentId":90},
	    {"id":1358,"value":"灵石县","parentId":90},
	    {"id":1359,"value":"祁县","parentId":90},
	    {"id":1360,"value":"万荣县","parentId":91},
	    {"id":1361,"value":"临猗县","parentId":91},
	    {"id":1362,"value":"垣曲县","parentId":91},
	    {"id":1363,"value":"夏县","parentId":91},
	    {"id":1364,"value":"平陆县","parentId":91},
	    {"id":1365,"value":"新绛县","parentId":91},
	    {"id":1366,"value":"永济市","parentId":91},
	    {"id":1367,"value":"河津市","parentId":91},
	    {"id":1368,"value":"盐湖区","parentId":91},
	    {"id":1369,"value":"稷山县","parentId":91},
	    {"id":1370,"value":"绛县","parentId":91},
	    {"id":1371,"value":"芮城县","parentId":91},
	    {"id":1372,"value":"闻喜县","parentId":91},
	    {"id":1373,"value":"五台县","parentId":92},
	    {"id":1374,"value":"五寨县","parentId":92},
	    {"id":1375,"value":"代县","parentId":92},
	    {"id":1376,"value":"保德县","parentId":92},
	    {"id":1377,"value":"偏关县","parentId":92},
	    {"id":1378,"value":"原平市","parentId":92},
	    {"id":1379,"value":"宁武县","parentId":92},
	    {"id":1380,"value":"定襄县","parentId":92},
	    {"id":1381,"value":"岢岚县","parentId":92},
	    {"id":1382,"value":"忻府区","parentId":92},
	    {"id":1383,"value":"河曲县","parentId":92},
	    {"id":1384,"value":"神池县","parentId":92},
	    {"id":1385,"value":"繁峙县","parentId":92},
	    {"id":1386,"value":"静乐县","parentId":92},
	    {"id":1387,"value":"乡宁县","parentId":93},
	    {"id":1388,"value":"侯马市","parentId":93},
	    {"id":1389,"value":"古县","parentId":93},
	    {"id":1390,"value":"吉县","parentId":93},
	    {"id":1391,"value":"大宁县","parentId":93},
	    {"id":1392,"value":"安泽县","parentId":93},
	    {"id":1393,"value":"尧都区","parentId":93},
	    {"id":1394,"value":"曲沃县","parentId":93},
	    {"id":1395,"value":"永和县","parentId":93},
	    {"id":1396,"value":"汾西县","parentId":93},
	    {"id":1397,"value":"洪洞县","parentId":93},
	    {"id":1398,"value":"浮山县","parentId":93},
	    {"id":1399,"value":"翼城县","parentId":93},
	    {"id":1400,"value":"蒲县","parentId":93},
	    {"id":1401,"value":"襄汾县","parentId":93},
	    {"id":1402,"value":"隰县","parentId":93},
	    {"id":1403,"value":"霍州市","parentId":93},
	    {"id":1404,"value":"中阳县","parentId":94},
	    {"id":1405,"value":"临县","parentId":94},
	    {"id":1406,"value":"交口县","parentId":94},
	    {"id":1407,"value":"交城县","parentId":94},
	    {"id":1408,"value":"兴县","parentId":94},
	    {"id":1409,"value":"孝义市","parentId":94},
	    {"id":1410,"value":"岚县","parentId":94},
	    {"id":1411,"value":"文水县","parentId":94},
	    {"id":1412,"value":"方山县","parentId":94},
	    {"id":1413,"value":"柳林县","parentId":94},
	    {"id":1414,"value":"汾阳市","parentId":94},
	    {"id":1415,"value":"石楼县","parentId":94},
	    {"id":1416,"value":"离石区","parentId":94},
	    {"id":1417,"value":"和林格尔县","parentId":95},
	    {"id":1418,"value":"回民区","parentId":95},
	    {"id":1419,"value":"土默特左旗","parentId":95},
	    {"id":1420,"value":"托克托县","parentId":95},
	    {"id":1421,"value":"新城区","parentId":95},
	    {"id":1422,"value":"武川县","parentId":95},
	    {"id":1423,"value":"清水河县","parentId":95},
	    {"id":1424,"value":"玉泉区","parentId":95},
	    {"id":1425,"value":"赛罕区","parentId":95},
	    {"id":1426,"value":"东河区","parentId":96},
	    {"id":1427,"value":"九原区","parentId":96},
	    {"id":1428,"value":"固阳县","parentId":96},
	    {"id":1429,"value":"土默特右旗","parentId":96},
	    {"id":1430,"value":"昆都仑区","parentId":96},
	    {"id":1431,"value":"白云矿区","parentId":96},
	    {"id":1432,"value":"石拐区","parentId":96},
	    {"id":1433,"value":"达尔罕茂明安联合旗","parentId":96},
	    {"id":1434,"value":"青山区","parentId":96},
	    {"id":1435,"value":"乌达区","parentId":97},
	    {"id":1436,"value":"海勃湾区","parentId":97},
	    {"id":1437,"value":"海南区","parentId":97},
	    {"id":1438,"value":"元宝山区","parentId":98},
	    {"id":1439,"value":"克什克腾旗","parentId":98},
	    {"id":1440,"value":"喀喇沁旗","parentId":98},
	    {"id":1441,"value":"宁城县","parentId":98},
	    {"id":1442,"value":"巴林右旗","parentId":98},
	    {"id":1443,"value":"巴林左旗","parentId":98},
	    {"id":1444,"value":"敖汉旗","parentId":98},
	    {"id":1445,"value":"松山区","parentId":98},
	    {"id":1446,"value":"林西县","parentId":98},
	    {"id":1447,"value":"红山区","parentId":98},
	    {"id":1448,"value":"翁牛特旗","parentId":98},
	    {"id":1449,"value":"阿鲁科尔沁旗","parentId":98},
	    {"id":1450,"value":"奈曼旗","parentId":99},
	    {"id":1451,"value":"库伦旗","parentId":99},
	    {"id":1452,"value":"开鲁县","parentId":99},
	    {"id":1453,"value":"扎鲁特旗","parentId":99},
	    {"id":1454,"value":"科尔沁区","parentId":99},
	    {"id":1455,"value":"科尔沁左翼中旗","parentId":99},
	    {"id":1456,"value":"科尔沁左翼后旗","parentId":99},
	    {"id":1457,"value":"霍林郭勒市","parentId":99},
	    {"id":1458,"value":"东胜区","parentId":100},
	    {"id":1459,"value":"乌审旗","parentId":100},
	    {"id":1460,"value":"伊金霍洛旗","parentId":100},
	    {"id":1461,"value":"准格尔旗","parentId":100},
	    {"id":1462,"value":"杭锦旗","parentId":100},
	    {"id":1463,"value":"达拉特旗","parentId":100},
	    {"id":1464,"value":"鄂东胜区","parentId":100},
	    {"id":1465,"value":"鄂托克前旗","parentId":100},
	    {"id":1466,"value":"鄂托克旗","parentId":100},
	    {"id":1467,"value":"扎兰屯市","parentId":101},
	    {"id":1468,"value":"新巴尔虎右旗","parentId":101},
	    {"id":1469,"value":"新巴尔虎左旗","parentId":101},
	    {"id":1470,"value":"根河市","parentId":101},
	    {"id":1471,"value":"海拉尔区","parentId":101},
	    {"id":1472,"value":"满洲里市","parentId":101},
	    {"id":1473,"value":"牙克石市","parentId":101},
	    {"id":1474,"value":"莫力达瓦达斡尔族自治旗","parentId":101},
	    {"id":1475,"value":"鄂伦春自治旗","parentId":101},
	    {"id":1476,"value":"鄂温克族自治旗","parentId":101},
	    {"id":1477,"value":"阿荣旗","parentId":101},
	    {"id":1478,"value":"陈巴尔虎旗","parentId":101},
	    {"id":1479,"value":"额尔古纳市","parentId":101},
	    {"id":1480,"value":"临河区","parentId":102},
	    {"id":1481,"value":"乌拉特中旗","parentId":102},
	    {"id":1482,"value":"乌拉特前旗","parentId":102},
	    {"id":1483,"value":"乌拉特后旗","parentId":102},
	    {"id":1484,"value":"五原县","parentId":102},
	    {"id":1485,"value":"杭锦后旗","parentId":102},
	    {"id":1486,"value":"磴口县","parentId":102},
	    {"id":1487,"value":"丰镇市","parentId":103},
	    {"id":1488,"value":"兴和县","parentId":103},
	    {"id":1489,"value":"凉城县","parentId":103},
	    {"id":1490,"value":"化德县","parentId":103},
	    {"id":1491,"value":"卓资县","parentId":103},
	    {"id":1492,"value":"商都县","parentId":103},
	    {"id":1493,"value":"四子王旗","parentId":103},
	    {"id":1494,"value":"察哈尔右翼中旗","parentId":103},
	    {"id":1495,"value":"察哈尔右翼前旗","parentId":103},
	    {"id":1496,"value":"察哈尔右翼后旗","parentId":103},
	    {"id":1497,"value":"集宁区","parentId":103},
	    {"id":1498,"value":"乌兰浩特市","parentId":104},
	    {"id":1499,"value":"扎赉特旗","parentId":104},
	    {"id":1500,"value":"科尔沁右翼中旗","parentId":104},
	    {"id":1501,"value":"科尔沁右翼前旗","parentId":104},
	    {"id":1502,"value":"突泉县","parentId":104},
	    {"id":1503,"value":"阿尔山市","parentId":104},
	    {"id":1504,"value":"东乌珠穆沁旗","parentId":105},
	    {"id":1505,"value":"二连浩特市","parentId":105},
	    {"id":1506,"value":"多伦县","parentId":105},
	    {"id":1507,"value":"太仆寺旗","parentId":105},
	    {"id":1508,"value":"正蓝旗","parentId":105},
	    {"id":1509,"value":"正镶白旗","parentId":105},
	    {"id":1510,"value":"苏尼特右旗","parentId":105},
	    {"id":1511,"value":"苏尼特左旗","parentId":105},
	    {"id":1512,"value":"西乌珠穆沁旗","parentId":105},
	    {"id":1513,"value":"锡林浩特市","parentId":105},
	    {"id":1514,"value":"镶黄旗","parentId":105},
	    {"id":1515,"value":"阿巴嘎旗","parentId":105},
	    {"id":1516,"value":"阿拉善右旗","parentId":106},
	    {"id":1517,"value":"阿拉善左旗","parentId":106},
	    {"id":1518,"value":"额济纳旗","parentId":106},
	    {"id":1519,"value":"东陵区","parentId":107},
	    {"id":1520,"value":"于洪区","parentId":107},
	    {"id":1521,"value":"和平区","parentId":107},
	    {"id":1522,"value":"大东区","parentId":107},
	    {"id":1523,"value":"康平县","parentId":107},
	    {"id":1524,"value":"新民市","parentId":107},
	    {"id":1525,"value":"沈北新区","parentId":107},
	    {"id":1526,"value":"沈河区","parentId":107},
	    {"id":1527,"value":"法库县","parentId":107},
	    {"id":1528,"value":"皇姑区","parentId":107},
	    {"id":1529,"value":"苏家屯区","parentId":107},
	    {"id":1530,"value":"辽中县","parentId":107},
	    {"id":1531,"value":"铁西区","parentId":107},
	    {"id":1532,"value":"中山区","parentId":108},
	    {"id":1533,"value":"庄河市","parentId":108},
	    {"id":1534,"value":"旅顺口区","parentId":108},
	    {"id":1535,"value":"普兰店市","parentId":108},
	    {"id":1536,"value":"沙河口区","parentId":108},
	    {"id":1537,"value":"瓦房店市","parentId":108},
	    {"id":1538,"value":"甘井子区","parentId":108},
	    {"id":1539,"value":"西岗区","parentId":108},
	    {"id":1540,"value":"金州区","parentId":108},
	    {"id":1541,"value":"长海县","parentId":108},
	    {"id":1542,"value":"千山区","parentId":109},
	    {"id":1543,"value":"台安县","parentId":109},
	    {"id":1544,"value":"岫岩满族自治县","parentId":109},
	    {"id":1545,"value":"海城市","parentId":109},
	    {"id":1546,"value":"立山区","parentId":109},
	    {"id":1547,"value":"铁东区","parentId":109},
	    {"id":1548,"value":"铁西区","parentId":109},
	    {"id":1549,"value":"东洲区","parentId":110},
	    {"id":1550,"value":"抚顺县","parentId":110},
	    {"id":1551,"value":"新宾满族自治县","parentId":110},
	    {"id":1552,"value":"新抚区","parentId":110},
	    {"id":1553,"value":"望花区","parentId":110},
	    {"id":1554,"value":"清原满族自治县","parentId":110},
	    {"id":1555,"value":"顺城区","parentId":110},
	    {"id":1556,"value":"南芬区","parentId":111},
	    {"id":1557,"value":"平山区","parentId":111},
	    {"id":1558,"value":"明山区","parentId":111},
	    {"id":1559,"value":"本溪满族自治县","parentId":111},
	    {"id":1560,"value":"桓仁满族自治县","parentId":111},
	    {"id":1561,"value":"溪湖区","parentId":111},
	    {"id":1562,"value":"东港市","parentId":112},
	    {"id":1563,"value":"元宝区","parentId":112},
	    {"id":1564,"value":"凤城市","parentId":112},
	    {"id":1565,"value":"宽甸满族自治县","parentId":112},
	    {"id":1566,"value":"振兴区","parentId":112},
	    {"id":1567,"value":"振安区","parentId":112},
	    {"id":1568,"value":"义县","parentId":113},
	    {"id":1569,"value":"凌河区","parentId":113},
	    {"id":1570,"value":"凌海市","parentId":113},
	    {"id":1571,"value":"北镇市","parentId":113},
	    {"id":1572,"value":"古塔区","parentId":113},
	    {"id":1573,"value":"太和区","parentId":113},
	    {"id":1574,"value":"黑山县","parentId":113},
	    {"id":1575,"value":"大石桥市","parentId":114},
	    {"id":1576,"value":"盖州市","parentId":114},
	    {"id":1577,"value":"站前区","parentId":114},
	    {"id":1578,"value":"老边区","parentId":114},
	    {"id":1579,"value":"西市区","parentId":114},
	    {"id":1580,"value":"鲅鱼圈区","parentId":114},
	    {"id":1581,"value":"太平区","parentId":115},
	    {"id":1582,"value":"彰武县","parentId":115},
	    {"id":1583,"value":"新邱区","parentId":115},
	    {"id":1584,"value":"海州区","parentId":115},
	    {"id":1585,"value":"清河门区","parentId":115},
	    {"id":1586,"value":"细河区","parentId":115},
	    {"id":1587,"value":"蒙古族自治县","parentId":115},
	    {"id":1588,"value":"太子河区","parentId":116},
	    {"id":1589,"value":"宏伟区","parentId":116},
	    {"id":1590,"value":"弓长岭区","parentId":116},
	    {"id":1591,"value":"文圣区","parentId":116},
	    {"id":1592,"value":"灯塔市","parentId":116},
	    {"id":1593,"value":"白塔区","parentId":116},
	    {"id":1594,"value":"辽阳县","parentId":116},
	    {"id":1595,"value":"兴隆台区","parentId":117},
	    {"id":1596,"value":"双台子区","parentId":117},
	    {"id":1597,"value":"大洼县","parentId":117},
	    {"id":1598,"value":"盘山县","parentId":117},
	    {"id":1599,"value":"开原市","parentId":118},
	    {"id":1600,"value":"昌图县","parentId":118},
	    {"id":1601,"value":"清河区","parentId":118},
	    {"id":1602,"value":"西丰县","parentId":118},
	    {"id":1603,"value":"调兵山市","parentId":118},
	    {"id":1604,"value":"铁岭县","parentId":118},
	    {"id":1605,"value":"银州区","parentId":118},
	    {"id":1606,"value":"凌源市","parentId":119},
	    {"id":1607,"value":"北票市","parentId":119},
	    {"id":1608,"value":"双塔区","parentId":119},
	    {"id":1609,"value":"喀喇沁左翼蒙古族自治县","parentId":119},
	    {"id":1610,"value":"建平县","parentId":119},
	    {"id":1611,"value":"朝阳县","parentId":119},
	    {"id":1612,"value":"龙城区","parentId":119},
	    {"id":1613,"value":"兴城市","parentId":120},
	    {"id":1614,"value":"南票区","parentId":120},
	    {"id":1615,"value":"建昌县","parentId":120},
	    {"id":1616,"value":"绥中县","parentId":120},
	    {"id":1617,"value":"连山区","parentId":120},
	    {"id":1618,"value":"龙港区","parentId":120},
	    {"id":1619,"value":"九台市","parentId":121},
	    {"id":1620,"value":"二道区","parentId":121},
	    {"id":1621,"value":"农安县","parentId":121},
	    {"id":1622,"value":"南关区","parentId":121},
	    {"id":1623,"value":"双阳区","parentId":121},
	    {"id":1624,"value":"宽城区","parentId":121},
	    {"id":1625,"value":"德惠市","parentId":121},
	    {"id":1626,"value":"朝阳区","parentId":121},
	    {"id":1627,"value":"榆树市","parentId":121},
	    {"id":1628,"value":"绿园区","parentId":121},
	    {"id":1629,"value":"丰满区","parentId":122},
	    {"id":1630,"value":"昌邑区","parentId":122},
	    {"id":1631,"value":"桦甸市","parentId":122},
	    {"id":1632,"value":"永吉县","parentId":122},
	    {"id":1633,"value":"磐石市","parentId":122},
	    {"id":1634,"value":"舒兰市","parentId":122},
	    {"id":1635,"value":"船营区","parentId":122},
	    {"id":1636,"value":"蛟河市","parentId":122},
	    {"id":1637,"value":"龙潭区","parentId":122},
	    {"id":1638,"value":"伊通满族自治县","parentId":123},
	    {"id":1639,"value":"公主岭市","parentId":123},
	    {"id":1640,"value":"双辽市","parentId":123},
	    {"id":1641,"value":"梨树县","parentId":123},
	    {"id":1642,"value":"铁东区","parentId":123},
	    {"id":1643,"value":"铁西区","parentId":123},
	    {"id":1644,"value":"东丰县","parentId":124},
	    {"id":1645,"value":"东辽县","parentId":124},
	    {"id":1646,"value":"西安区","parentId":124},
	    {"id":1647,"value":"龙山区","parentId":124},
	    {"id":1648,"value":"东昌区","parentId":125},
	    {"id":1649,"value":"二道江区","parentId":125},
	    {"id":1650,"value":"柳河县","parentId":125},
	    {"id":1651,"value":"梅河口市","parentId":125},
	    {"id":1652,"value":"辉南县","parentId":125},
	    {"id":1653,"value":"通化县","parentId":125},
	    {"id":1654,"value":"集安市","parentId":125},
	    {"id":1655,"value":"临江市","parentId":126},
	    {"id":1656,"value":"八道江区","parentId":126},
	    {"id":1657,"value":"抚松县","parentId":126},
	    {"id":1658,"value":"江源区","parentId":126},
	    {"id":1659,"value":"长白朝鲜族自治县","parentId":126},
	    {"id":1660,"value":"靖宇县","parentId":126},
	    {"id":1661,"value":"干安县","parentId":127},
	    {"id":1662,"value":"前郭尔罗斯蒙古族自治县","parentId":127},
	    {"id":1663,"value":"宁江区","parentId":127},
	    {"id":1664,"value":"扶余县","parentId":127},
	    {"id":1665,"value":"长岭县","parentId":127},
	    {"id":1666,"value":"大安市","parentId":128},
	    {"id":1667,"value":"洮北区","parentId":128},
	    {"id":1668,"value":"洮南市","parentId":128},
	    {"id":1669,"value":"通榆县","parentId":128},
	    {"id":1670,"value":"镇赉县","parentId":128},
	    {"id":1671,"value":"和龙市","parentId":129},
	    {"id":1672,"value":"图们市","parentId":129},
	    {"id":1673,"value":"安图县","parentId":129},
	    {"id":1674,"value":"延吉市","parentId":129},
	    {"id":1675,"value":"敦化市","parentId":129},
	    {"id":1676,"value":"汪清县","parentId":129},
	    {"id":1677,"value":"珲春市","parentId":129},
	    {"id":1678,"value":"龙井市","parentId":129},
	    {"id":1679,"value":"五常市","parentId":130},
	    {"id":1680,"value":"依兰县","parentId":130},
	    {"id":1681,"value":"南岗区","parentId":130},
	    {"id":1682,"value":"双城市","parentId":130},
	    {"id":1683,"value":"呼兰区","parentId":130},
	    {"id":1684,"value":"哈尔滨市道里区","parentId":130},
	    {"id":1685,"value":"宾县","parentId":130},
	    {"id":1686,"value":"尚志市","parentId":130},
	    {"id":1687,"value":"巴彦县","parentId":130},
	    {"id":1688,"value":"平房区","parentId":130},
	    {"id":1689,"value":"延寿县","parentId":130},
	    {"id":1690,"value":"方正县","parentId":130},
	    {"id":1691,"value":"木兰县","parentId":130},
	    {"id":1692,"value":"松北区","parentId":130},
	    {"id":1693,"value":"通河县","parentId":130},
	    {"id":1694,"value":"道外区","parentId":130},
	    {"id":1695,"value":"阿城区","parentId":130},
	    {"id":1696,"value":"香坊区","parentId":130},
	    {"id":1697,"value":"依安县","parentId":131},
	    {"id":1698,"value":"克东县","parentId":131},
	    {"id":1699,"value":"克山县","parentId":131},
	    {"id":1700,"value":"富拉尔基区","parentId":131},
	    {"id":1701,"value":"富裕县","parentId":131},
	    {"id":1702,"value":"建华区","parentId":131},
	    {"id":1703,"value":"拜泉县","parentId":131},
	    {"id":1704,"value":"昂昂溪区","parentId":131},
	    {"id":1705,"value":"梅里斯达斡尔族区","parentId":131},
	    {"id":1706,"value":"泰来县","parentId":131},
	    {"id":1707,"value":"甘南县","parentId":131},
	    {"id":1708,"value":"碾子山区","parentId":131},
	    {"id":1709,"value":"讷河市","parentId":131},
	    {"id":1710,"value":"铁锋区","parentId":131},
	    {"id":1711,"value":"龙江县","parentId":131},
	    {"id":1712,"value":"龙沙区","parentId":131},
	    {"id":1713,"value":"城子河区","parentId":132},
	    {"id":1714,"value":"密山市","parentId":132},
	    {"id":1715,"value":"恒山区","parentId":132},
	    {"id":1716,"value":"梨树区","parentId":132},
	    {"id":1717,"value":"滴道区","parentId":132},
	    {"id":1718,"value":"虎林市","parentId":132},
	    {"id":1719,"value":"鸡东县","parentId":132},
	    {"id":1720,"value":"鸡冠区","parentId":132},
	    {"id":1721,"value":"麻山区","parentId":132},
	    {"id":1722,"value":"东山区","parentId":133},
	    {"id":1723,"value":"兴安区","parentId":133},
	    {"id":1724,"value":"兴山区","parentId":133},
	    {"id":1725,"value":"南山区","parentId":133},
	    {"id":1726,"value":"向阳区","parentId":133},
	    {"id":1727,"value":"工农区","parentId":133},
	    {"id":1728,"value":"绥滨县","parentId":133},
	    {"id":1729,"value":"萝北县","parentId":133},
	    {"id":1730,"value":"友谊县","parentId":134},
	    {"id":1731,"value":"四方台区","parentId":134},
	    {"id":1732,"value":"宝山区","parentId":134},
	    {"id":1733,"value":"宝清县","parentId":134},
	    {"id":1734,"value":"尖山区","parentId":134},
	    {"id":1735,"value":"岭东区","parentId":134},
	    {"id":1736,"value":"集贤县","parentId":134},
	    {"id":1737,"value":"饶河县","parentId":134},
	    {"id":1738,"value":"大同区","parentId":135},
	    {"id":1739,"value":"杜尔伯特蒙古族自治县","parentId":135},
	    {"id":1740,"value":"林甸县","parentId":135},
	    {"id":1741,"value":"红岗区","parentId":135},
	    {"id":1742,"value":"肇州县","parentId":135},
	    {"id":1743,"value":"肇源县","parentId":135},
	    {"id":1744,"value":"胡路区","parentId":135},
	    {"id":1745,"value":"萨尔图区","parentId":135},
	    {"id":1746,"value":"龙凤区","parentId":135},
	    {"id":1747,"value":"上甘岭区","parentId":136},
	    {"id":1748,"value":"乌伊岭区","parentId":136},
	    {"id":1749,"value":"乌马河区","parentId":136},
	    {"id":1750,"value":"五营区","parentId":136},
	    {"id":1751,"value":"伊春区","parentId":136},
	    {"id":1752,"value":"南岔区","parentId":136},
	    {"id":1753,"value":"友好区","parentId":136},
	    {"id":1754,"value":"嘉荫县","parentId":136},
	    {"id":1755,"value":"带岭区","parentId":136},
	    {"id":1756,"value":"新青区","parentId":136},
	    {"id":1757,"value":"汤旺河区","parentId":136},
	    {"id":1758,"value":"红星区","parentId":136},
	    {"id":1759,"value":"美溪区","parentId":136},
	    {"id":1760,"value":"翠峦区","parentId":136},
	    {"id":1761,"value":"西林区","parentId":136},
	    {"id":1762,"value":"金山屯区","parentId":136},
	    {"id":1763,"value":"铁力市","parentId":136},
	    {"id":1764,"value":"东风区","parentId":137},
	    {"id":1765,"value":"前进区","parentId":137},
	    {"id":1766,"value":"同江市","parentId":137},
	    {"id":1767,"value":"向阳区","parentId":137},
	    {"id":1768,"value":"富锦市","parentId":137},
	    {"id":1769,"value":"抚远县","parentId":137},
	    {"id":1770,"value":"桦南县","parentId":137},
	    {"id":1771,"value":"桦川县","parentId":137},
	    {"id":1772,"value":"汤原县","parentId":137},
	    {"id":1773,"value":"郊区","parentId":137},
	    {"id":1774,"value":"勃利县","parentId":138},
	    {"id":1775,"value":"新兴区","parentId":138},
	    {"id":1776,"value":"桃山区","parentId":138},
	    {"id":1777,"value":"茄子河区","parentId":138},
	    {"id":1778,"value":"东宁县","parentId":139},
	    {"id":1779,"value":"东安区","parentId":139},
	    {"id":1780,"value":"宁安市","parentId":139},
	    {"id":1781,"value":"林口县","parentId":139},
	    {"id":1782,"value":"海林市","parentId":139},
	    {"id":1783,"value":"爱民区","parentId":139},
	    {"id":1784,"value":"穆棱市","parentId":139},
	    {"id":1785,"value":"绥芬河市","parentId":139},
	    {"id":1786,"value":"西安区","parentId":139},
	    {"id":1787,"value":"阳明区","parentId":139},
	    {"id":1788,"value":"五大连池市","parentId":140},
	    {"id":1789,"value":"北安市","parentId":140},
	    {"id":1790,"value":"嫩江县","parentId":140},
	    {"id":1791,"value":"孙吴县","parentId":140},
	    {"id":1792,"value":"爱辉区","parentId":140},
	    {"id":1793,"value":"车逊克县","parentId":140},
	    {"id":1794,"value":"逊克县","parentId":140},
	    {"id":1795,"value":"兰西县","parentId":141},
	    {"id":1796,"value":"安达市","parentId":141},
	    {"id":1797,"value":"庆安县","parentId":141},
	    {"id":1798,"value":"明水县","parentId":141},
	    {"id":1799,"value":"望奎县","parentId":141},
	    {"id":1800,"value":"海伦市","parentId":141},
	    {"id":1801,"value":"绥化市北林区","parentId":141},
	    {"id":1802,"value":"绥棱县","parentId":141},
	    {"id":1803,"value":"肇东市","parentId":141},
	    {"id":1804,"value":"青冈县","parentId":141},
	    {"id":1805,"value":"呼玛县","parentId":142},
	    {"id":1806,"value":"塔河县","parentId":142},
	    {"id":1807,"value":"大兴安岭地区加格达奇区","parentId":142},
	    {"id":1808,"value":"大兴安岭地区呼中区","parentId":142},
	    {"id":1809,"value":"大兴安岭地区新林区","parentId":142},
	    {"id":1810,"value":"大兴安岭地区松岭区","parentId":142},
	    {"id":1811,"value":"漠河县","parentId":142},
	    {"id":2027,"value":"下关区","parentId":162},
	    {"id":2028,"value":"六合区","parentId":162},
	    {"id":2029,"value":"建邺区","parentId":162},
	    {"id":2030,"value":"栖霞区","parentId":162},
	    {"id":2031,"value":"江宁区","parentId":162},
	    {"id":2032,"value":"浦口区","parentId":162},
	    {"id":2033,"value":"溧水县","parentId":162},
	    {"id":2034,"value":"玄武区","parentId":162},
	    {"id":2035,"value":"白下区","parentId":162},
	    {"id":2036,"value":"秦淮区","parentId":162},
	    {"id":2037,"value":"雨花台区","parentId":162},
	    {"id":2038,"value":"高淳县","parentId":162},
	    {"id":2039,"value":"鼓楼区","parentId":162},
	    {"id":2040,"value":"北塘区","parentId":163},
	    {"id":2041,"value":"南长区","parentId":163},
	    {"id":2042,"value":"宜兴市","parentId":163},
	    {"id":2043,"value":"崇安区","parentId":163},
	    {"id":2044,"value":"惠山区","parentId":163},
	    {"id":2045,"value":"江阴市","parentId":163},
	    {"id":2046,"value":"滨湖区","parentId":163},
	    {"id":2047,"value":"锡山区","parentId":163},
	    {"id":2048,"value":"丰县","parentId":164},
	    {"id":2049,"value":"九里区","parentId":164},
	    {"id":2050,"value":"云龙区","parentId":164},
	    {"id":2051,"value":"新沂市","parentId":164},
	    {"id":2052,"value":"沛县","parentId":164},
	    {"id":2053,"value":"泉山区","parentId":164},
	    {"id":2054,"value":"睢宁县","parentId":164},
	    {"id":2055,"value":"贾汪区","parentId":164},
	    {"id":2056,"value":"邳州市","parentId":164},
	    {"id":2057,"value":"铜山县","parentId":164},
	    {"id":2058,"value":"鼓楼区","parentId":164},
	    {"id":2059,"value":"天宁区","parentId":165},
	    {"id":2060,"value":"戚墅堰区","parentId":165},
	    {"id":2061,"value":"新北区","parentId":165},
	    {"id":2062,"value":"武进区","parentId":165},
	    {"id":2063,"value":"溧阳市","parentId":165},
	    {"id":2064,"value":"金坛市","parentId":165},
	    {"id":2065,"value":"钟楼区","parentId":165},
	    {"id":2066,"value":"吴中区","parentId":166},
	    {"id":2067,"value":"吴江市","parentId":166},
	    {"id":2068,"value":"太仓市","parentId":166},
	    {"id":2069,"value":"常熟市","parentId":166},
	    {"id":2070,"value":"平江区","parentId":166},
	    {"id":2071,"value":"张家港市","parentId":166},
	    {"id":2072,"value":"昆山市","parentId":166},
	    {"id":2073,"value":"沧浪区","parentId":166},
	    {"id":2074,"value":"相城区","parentId":166},
	    {"id":2075,"value":"苏州工业园区","parentId":166},
	    {"id":2076,"value":"虎丘区","parentId":166},
	    {"id":2077,"value":"金阊区","parentId":166},
	    {"id":2078,"value":"启东市","parentId":167},
	    {"id":2079,"value":"如东县","parentId":167},
	    {"id":2080,"value":"如皋市","parentId":167},
	    {"id":2081,"value":"崇川区","parentId":167},
	    {"id":2082,"value":"海安县","parentId":167},
	    {"id":2083,"value":"海门市","parentId":167},
	    {"id":2084,"value":"港闸区","parentId":167},
	    {"id":2085,"value":"通州市","parentId":167},
	    {"id":2086,"value":"东海县","parentId":168},
	    {"id":2087,"value":"新浦区","parentId":168},
	    {"id":2088,"value":"海州区","parentId":168},
	    {"id":2089,"value":"灌云县","parentId":168},
	    {"id":2090,"value":"灌南县","parentId":168},
	    {"id":2091,"value":"赣榆县","parentId":168},
	    {"id":2092,"value":"连云区","parentId":168},
	    {"id":2093,"value":"楚州区","parentId":169},
	    {"id":2094,"value":"洪泽县","parentId":169},
	    {"id":2095,"value":"涟水县","parentId":169},
	    {"id":2096,"value":"淮阴区","parentId":169},
	    {"id":2097,"value":"清河区","parentId":169},
	    {"id":2098,"value":"清浦区","parentId":169},
	    {"id":2099,"value":"盱眙县","parentId":169},
	    {"id":2100,"value":"金湖县","parentId":169},
	    {"id":2101,"value":"东台市","parentId":170},
	    {"id":2102,"value":"亭湖区","parentId":170},
	    {"id":2103,"value":"响水县","parentId":170},
	    {"id":2104,"value":"大丰市","parentId":170},
	    {"id":2105,"value":"射阳县","parentId":170},
	    {"id":2106,"value":"建湖县","parentId":170},
	    {"id":2107,"value":"滨海县","parentId":170},
	    {"id":2108,"value":"盐都区","parentId":170},
	    {"id":2109,"value":"阜宁县","parentId":170},
	    {"id":2110,"value":"仪征市","parentId":171},
	    {"id":2111,"value":"宝应县","parentId":171},
	    {"id":2112,"value":"广陵区","parentId":171},
	    {"id":2113,"value":"江都市","parentId":171},
	    {"id":2114,"value":"维扬区","parentId":171},
	    {"id":2115,"value":"邗江区","parentId":171},
	    {"id":2116,"value":"高邮市","parentId":171},
	    {"id":2117,"value":"丹徒区","parentId":172},
	    {"id":2118,"value":"丹阳市","parentId":172},
	    {"id":2119,"value":"京口区","parentId":172},
	    {"id":2120,"value":"句容市","parentId":172},
	    {"id":2121,"value":"扬中市","parentId":172},
	    {"id":2122,"value":"润州区","parentId":172},
	    {"id":2123,"value":"兴化市","parentId":173},
	    {"id":2124,"value":"姜堰市","parentId":173},
	    {"id":2125,"value":"泰兴市","parentId":173},
	    {"id":2126,"value":"海陵区","parentId":173},
	    {"id":2127,"value":"靖江市","parentId":173},
	    {"id":2128,"value":"高港区","parentId":173},
	    {"id":2129,"value":"宿城区","parentId":174},
	    {"id":2130,"value":"宿豫区","parentId":174},
	    {"id":2131,"value":"沭阳县","parentId":174},
	    {"id":2132,"value":"泗洪县","parentId":174},
	    {"id":2133,"value":"泗阳县","parentId":174},
	    {"id":2134,"value":"上城区","parentId":175},
	    {"id":2135,"value":"下城区","parentId":175},
	    {"id":2136,"value":"临安市","parentId":175},
	    {"id":2137,"value":"余杭区","parentId":175},
	    {"id":2138,"value":"富阳市","parentId":175},
	    {"id":2139,"value":"建德市","parentId":175},
	    {"id":2140,"value":"拱墅区","parentId":175},
	    {"id":2141,"value":"桐庐县","parentId":175},
	    {"id":2142,"value":"江干区","parentId":175},
	    {"id":2143,"value":"淳安县","parentId":175},
	    {"id":2144,"value":"滨江区","parentId":175},
	    {"id":2145,"value":"萧山区","parentId":175},
	    {"id":2146,"value":"西湖区","parentId":175},
	    {"id":2147,"value":"余姚市","parentId":176},
	    {"id":2148,"value":"北仑区","parentId":176},
	    {"id":2149,"value":"奉化市","parentId":176},
	    {"id":2150,"value":"宁海县","parentId":176},
	    {"id":2151,"value":"慈溪市","parentId":176},
	    {"id":2152,"value":"江东区","parentId":176},
	    {"id":2153,"value":"江北区","parentId":176},
	    {"id":2154,"value":"海曙区","parentId":176},
	    {"id":2155,"value":"象山县","parentId":176},
	    {"id":2156,"value":"鄞州区","parentId":176},
	    {"id":2157,"value":"镇海区","parentId":176},
	    {"id":2158,"value":"乐清市","parentId":177},
	    {"id":2159,"value":"平阳县","parentId":177},
	    {"id":2160,"value":"文成县","parentId":177},
	    {"id":2161,"value":"永嘉县","parentId":177},
	    {"id":2162,"value":"泰顺县","parentId":177},
	    {"id":2163,"value":"洞头县","parentId":177},
	    {"id":2164,"value":"瑞安市","parentId":177},
	    {"id":2165,"value":"瓯海区","parentId":177},
	    {"id":2166,"value":"苍南县","parentId":177},
	    {"id":2167,"value":"鹿城区","parentId":177},
	    {"id":2168,"value":"龙湾区","parentId":177},
	    {"id":2169,"value":"南湖区","parentId":178},
	    {"id":2170,"value":"嘉善县","parentId":178},
	    {"id":2171,"value":"平湖市","parentId":178},
	    {"id":2172,"value":"桐乡市","parentId":178},
	    {"id":2173,"value":"海宁市","parentId":178},
	    {"id":2174,"value":"海盐县","parentId":178},
	    {"id":2175,"value":"秀洲区","parentId":178},
	    {"id":2176,"value":"南浔区","parentId":179},
	    {"id":2177,"value":"吴兴区","parentId":179},
	    {"id":2178,"value":"安吉县","parentId":179},
	    {"id":2179,"value":"德清县","parentId":179},
	    {"id":2180,"value":"长兴县","parentId":179},
	    {"id":2181,"value":"上虞市","parentId":180},
	    {"id":2182,"value":"嵊州市","parentId":180},
	    {"id":2183,"value":"新昌县","parentId":180},
	    {"id":2184,"value":"绍兴县","parentId":180},
	    {"id":2185,"value":"诸暨市","parentId":180},
	    {"id":2186,"value":"越城区","parentId":180},
	    {"id":2187,"value":"定海区","parentId":181},
	    {"id":2188,"value":"岱山县","parentId":181},
	    {"id":2189,"value":"嵊泗县","parentId":181},
	    {"id":2190,"value":"普陀区","parentId":181},
	    {"id":2191,"value":"常山县","parentId":182},
	    {"id":2192,"value":"开化县","parentId":182},
	    {"id":2193,"value":"柯城区","parentId":182},
	    {"id":2194,"value":"江山市","parentId":182},
	    {"id":2195,"value":"衢江区","parentId":182},
	    {"id":2196,"value":"龙游县","parentId":182},
	    {"id":2197,"value":"东阳市","parentId":183},
	    {"id":2198,"value":"义乌市","parentId":183},
	    {"id":2199,"value":"兰溪市","parentId":183},
	    {"id":2200,"value":"婺城区","parentId":183},
	    {"id":2201,"value":"武义县","parentId":183},
	    {"id":2202,"value":"永康市","parentId":183},
	    {"id":2203,"value":"浦江县","parentId":183},
	    {"id":2204,"value":"磐安县","parentId":183},
	    {"id":2205,"value":"金东区","parentId":183},
	    {"id":2206,"value":"三门县","parentId":184},
	    {"id":2207,"value":"临海市","parentId":184},
	    {"id":2208,"value":"仙居县","parentId":184},
	    {"id":2209,"value":"天台县","parentId":184},
	    {"id":2210,"value":"椒江区","parentId":184},
	    {"id":2211,"value":"温岭市","parentId":184},
	    {"id":2212,"value":"玉环县","parentId":184},
	    {"id":2213,"value":"路桥区","parentId":184},
	    {"id":2214,"value":"黄岩区","parentId":184},
	    {"id":2215,"value":"云和县","parentId":185},
	    {"id":2216,"value":"庆元县","parentId":185},
	    {"id":2217,"value":"景宁畲族自治县","parentId":185},
	    {"id":2218,"value":"松阳县","parentId":185},
	    {"id":2219,"value":"缙云县","parentId":185},
	    {"id":2220,"value":"莲都区","parentId":185},
	    {"id":2221,"value":"遂昌县","parentId":185},
	    {"id":2222,"value":"青田县","parentId":185},
	    {"id":2223,"value":"龙泉市","parentId":185},
	    {"id":2224,"value":"包河区","parentId":186},
	    {"id":2225,"value":"庐阳区","parentId":186},
	    {"id":2226,"value":"瑶海区","parentId":186},
	    {"id":2227,"value":"肥东县","parentId":186},
	    {"id":2228,"value":"肥西县","parentId":186},
	    {"id":2229,"value":"蜀山区","parentId":186},
	    {"id":2230,"value":"长丰县","parentId":186},
	    {"id":2231,"value":"三山区","parentId":187},
	    {"id":2232,"value":"南陵县","parentId":187},
	    {"id":2233,"value":"弋江区","parentId":187},
	    {"id":2234,"value":"繁昌县","parentId":187},
	    {"id":2235,"value":"芜湖县","parentId":187},
	    {"id":2236,"value":"镜湖区","parentId":187},
	    {"id":2237,"value":"鸠江区","parentId":187},
	    {"id":2238,"value":"五河县","parentId":188},
	    {"id":2239,"value":"固镇县","parentId":188},
	    {"id":2240,"value":"怀远县","parentId":188},
	    {"id":2241,"value":"淮上区","parentId":188},
	    {"id":2242,"value":"禹会区","parentId":188},
	    {"id":2243,"value":"蚌山区","parentId":188},
	    {"id":2244,"value":"龙子湖区","parentId":188},
	    {"id":2245,"value":"八公山区","parentId":189},
	    {"id":2246,"value":"凤台县","parentId":189},
	    {"id":2247,"value":"大通区","parentId":189},
	    {"id":2248,"value":"潘集区","parentId":189},
	    {"id":2249,"value":"田家庵区","parentId":189},
	    {"id":2250,"value":"谢家集区","parentId":189},
	    {"id":2251,"value":"当涂县","parentId":190},
	    {"id":2252,"value":"花山区","parentId":190},
	    {"id":2253,"value":"金家庄区","parentId":190},
	    {"id":2254,"value":"雨山区","parentId":190},
	    {"id":2255,"value":"杜集区","parentId":191},
	    {"id":2256,"value":"濉溪县","parentId":191},
	    {"id":2257,"value":"烈山区","parentId":191},
	    {"id":2258,"value":"相山区","parentId":191},
	    {"id":2259,"value":"狮子山区","parentId":192},
	    {"id":2260,"value":"郊区","parentId":192},
	    {"id":2261,"value":"铜官山区","parentId":192},
	    {"id":2262,"value":"铜陵县","parentId":192},
	    {"id":2263,"value":"大观区","parentId":193},
	    {"id":2264,"value":"太湖县","parentId":193},
	    {"id":2265,"value":"宜秀区","parentId":193},
	    {"id":2266,"value":"宿松县","parentId":193},
	    {"id":2267,"value":"岳西县","parentId":193},
	    {"id":2268,"value":"怀宁县","parentId":193},
	    {"id":2269,"value":"望江县","parentId":193},
	    {"id":2270,"value":"枞阳县","parentId":193},
	    {"id":2271,"value":"桐城市","parentId":193},
	    {"id":2272,"value":"潜山县","parentId":193},
	    {"id":2273,"value":"迎江区","parentId":193},
	    {"id":2274,"value":"休宁县","parentId":194},
	    {"id":2275,"value":"屯溪区","parentId":194},
	    {"id":2276,"value":"徽州区","parentId":194},
	    {"id":2277,"value":"歙县","parentId":194},
	    {"id":2278,"value":"祁门县","parentId":194},
	    {"id":2279,"value":"黄山区","parentId":194},
	    {"id":2280,"value":"黟县","parentId":194},
	    {"id":2281,"value":"全椒县","parentId":195},
	    {"id":2282,"value":"凤阳县","parentId":195},
	    {"id":2283,"value":"南谯区","parentId":195},
	    {"id":2284,"value":"天长市","parentId":195},
	    {"id":2285,"value":"定远县","parentId":195},
	    {"id":2286,"value":"明光市","parentId":195},
	    {"id":2287,"value":"来安县","parentId":195},
	    {"id":2288,"value":"琅玡区","parentId":195},
	    {"id":2289,"value":"临泉县","parentId":196},
	    {"id":2290,"value":"太和县","parentId":196},
	    {"id":2291,"value":"界首市","parentId":196},
	    {"id":2292,"value":"阜南县","parentId":196},
	    {"id":2293,"value":"颍东区","parentId":196},
	    {"id":2294,"value":"颍州区","parentId":196},
	    {"id":2295,"value":"颍泉区","parentId":196},
	    {"id":2296,"value":"颖上县","parentId":196},
	    {"id":2297,"value":"埇桥区","parentId":197},
	    {"id":2298,"value":"泗县辖","parentId":197},
	    {"id":2299,"value":"灵璧县","parentId":197},
	    {"id":2300,"value":"砀山县","parentId":197},
	    {"id":2301,"value":"萧县","parentId":197},
	    {"id":2302,"value":"含山县","parentId":198},
	    {"id":2303,"value":"和县","parentId":198},
	    {"id":2304,"value":"居巢区","parentId":198},
	    {"id":2305,"value":"庐江县","parentId":198},
	    {"id":2306,"value":"无为县","parentId":198},
	    {"id":2307,"value":"寿县","parentId":199},
	    {"id":2308,"value":"舒城县","parentId":199},
	    {"id":2309,"value":"裕安区","parentId":199},
	    {"id":2310,"value":"金安区","parentId":199},
	    {"id":2311,"value":"金寨县","parentId":199},
	    {"id":2312,"value":"霍山县","parentId":199},
	    {"id":2313,"value":"霍邱县","parentId":199},
	    {"id":2314,"value":"利辛县","parentId":200},
	    {"id":2315,"value":"涡阳县","parentId":200},
	    {"id":2316,"value":"蒙城县","parentId":200},
	    {"id":2317,"value":"谯城区","parentId":200},
	    {"id":2318,"value":"东至县","parentId":201},
	    {"id":2319,"value":"石台县","parentId":201},
	    {"id":2320,"value":"贵池区","parentId":201},
	    {"id":2321,"value":"青阳县","parentId":201},
	    {"id":2322,"value":"宁国市","parentId":202},
	    {"id":2323,"value":"宣州区","parentId":202},
	    {"id":2324,"value":"广德县","parentId":202},
	    {"id":2325,"value":"旌德县","parentId":202},
	    {"id":2326,"value":"泾县","parentId":202},
	    {"id":2327,"value":"绩溪县","parentId":202},
	    {"id":2328,"value":"郎溪县","parentId":202},
	    {"id":2329,"value":"仓山区","parentId":203},
	    {"id":2330,"value":"台江区","parentId":203},
	    {"id":2331,"value":"平潭县","parentId":203},
	    {"id":2332,"value":"晋安区","parentId":203},
	    {"id":2333,"value":"永泰县","parentId":203},
	    {"id":2334,"value":"福清市","parentId":203},
	    {"id":2335,"value":"罗源县","parentId":203},
	    {"id":2336,"value":"连江县","parentId":203},
	    {"id":2337,"value":"长乐市","parentId":203},
	    {"id":2338,"value":"闽侯县","parentId":203},
	    {"id":2339,"value":"闽清县","parentId":203},
	    {"id":2340,"value":"马尾区","parentId":203},
	    {"id":2341,"value":"鼓楼区","parentId":203},
	    {"id":2342,"value":"同安区","parentId":204},
	    {"id":2343,"value":"思明区","parentId":204},
	    {"id":2344,"value":"海沧区","parentId":204},
	    {"id":2345,"value":"湖里区","parentId":204},
	    {"id":2346,"value":"翔安区","parentId":204},
	    {"id":2347,"value":"集美区","parentId":204},
	    {"id":2348,"value":"仙游县","parentId":205},
	    {"id":2349,"value":"城厢区","parentId":205},
	    {"id":2350,"value":"涵江区","parentId":205},
	    {"id":2351,"value":"秀屿区","parentId":205},
	    {"id":2352,"value":"荔城区","parentId":205},
	    {"id":2353,"value":"三元区","parentId":206},
	    {"id":2354,"value":"大田县","parentId":206},
	    {"id":2355,"value":"宁化县","parentId":206},
	    {"id":2356,"value":"将乐县","parentId":206},
	    {"id":2357,"value":"尤溪县","parentId":206},
	    {"id":2358,"value":"建宁县","parentId":206},
	    {"id":2359,"value":"明溪县","parentId":206},
	    {"id":2360,"value":"梅列区","parentId":206},
	    {"id":2361,"value":"永安市","parentId":206},
	    {"id":2362,"value":"沙县","parentId":206},
	    {"id":2363,"value":"泰宁县","parentId":206},
	    {"id":2364,"value":"清流县","parentId":206},
	    {"id":2365,"value":"丰泽区","parentId":207},
	    {"id":2366,"value":"南安市","parentId":207},
	    {"id":2367,"value":"安溪县","parentId":207},
	    {"id":2368,"value":"德化县","parentId":207},
	    {"id":2369,"value":"惠安县","parentId":207},
	    {"id":2370,"value":"晋江市","parentId":207},
	    {"id":2371,"value":"永春县","parentId":207},
	    {"id":2372,"value":"泉港区","parentId":207},
	    {"id":2373,"value":"洛江区","parentId":207},
	    {"id":2374,"value":"石狮市","parentId":207},
	    {"id":2375,"value":"金门县","parentId":207},
	    {"id":2376,"value":"鲤城区","parentId":207},
	    {"id":2377,"value":"东山县","parentId":208},
	    {"id":2378,"value":"云霄县","parentId":208},
	    {"id":2379,"value":"华安县","parentId":208},
	    {"id":2380,"value":"南靖县","parentId":208},
	    {"id":2381,"value":"平和县","parentId":208},
	    {"id":2382,"value":"漳浦县","parentId":208},
	    {"id":2383,"value":"芗城区","parentId":208},
	    {"id":2384,"value":"诏安县","parentId":208},
	    {"id":2385,"value":"长泰县","parentId":208},
	    {"id":2386,"value":"龙文区","parentId":208},
	    {"id":2387,"value":"龙海市","parentId":208},
	    {"id":2388,"value":"光泽县","parentId":209},
	    {"id":2389,"value":"延平区","parentId":209},
	    {"id":2390,"value":"建瓯市","parentId":209},
	    {"id":2391,"value":"建阳市","parentId":209},
	    {"id":2392,"value":"政和县","parentId":209},
	    {"id":2393,"value":"松溪县","parentId":209},
	    {"id":2394,"value":"武夷山市","parentId":209},
	    {"id":2395,"value":"浦城县","parentId":209},
	    {"id":2396,"value":"邵武市","parentId":209},
	    {"id":2397,"value":"顺昌县","parentId":209},
	    {"id":2398,"value":"上杭县","parentId":210},
	    {"id":2399,"value":"新罗区","parentId":210},
	    {"id":2400,"value":"武平县","parentId":210},
	    {"id":2401,"value":"永定县","parentId":210},
	    {"id":2402,"value":"漳平市","parentId":210},
	    {"id":2403,"value":"连城县","parentId":210},
	    {"id":2404,"value":"长汀县","parentId":210},
	    {"id":2405,"value":"古田县","parentId":211},
	    {"id":2406,"value":"周宁县","parentId":211},
	    {"id":2407,"value":"寿宁县","parentId":211},
	    {"id":2408,"value":"屏南县","parentId":211},
	    {"id":2409,"value":"柘荣县","parentId":211},
	    {"id":2410,"value":"福安市","parentId":211},
	    {"id":2411,"value":"福鼎市","parentId":211},
	    {"id":2412,"value":"蕉城区","parentId":211},
	    {"id":2413,"value":"霞浦县","parentId":211},
	    {"id":2414,"value":"东湖区","parentId":212},
	    {"id":2415,"value":"南昌县","parentId":212},
	    {"id":2416,"value":"安义县","parentId":212},
	    {"id":2417,"value":"新建县","parentId":212},
	    {"id":2418,"value":"湾里区","parentId":212},
	    {"id":2419,"value":"西湖区","parentId":212},
	    {"id":2420,"value":"进贤县","parentId":212},
	    {"id":2421,"value":"青云谱区","parentId":212},
	    {"id":2422,"value":"青山湖区","parentId":212},
	    {"id":2423,"value":"乐平市","parentId":213},
	    {"id":2424,"value":"昌江区","parentId":213},
	    {"id":2425,"value":"浮梁县","parentId":213},
	    {"id":2426,"value":"珠山区","parentId":213},
	    {"id":2427,"value":"上栗县","parentId":214},
	    {"id":2428,"value":"安源区","parentId":214},
	    {"id":2429,"value":"湘东区","parentId":214},
	    {"id":2430,"value":"芦溪县","parentId":214},
	    {"id":2431,"value":"莲花县","parentId":214},
	    {"id":2432,"value":"九江县","parentId":215},
	    {"id":2433,"value":"修水县","parentId":215},
	    {"id":2434,"value":"庐山区","parentId":215},
	    {"id":2435,"value":"彭泽县","parentId":215},
	    {"id":2436,"value":"德安县","parentId":215},
	    {"id":2437,"value":"星子县","parentId":215},
	    {"id":2438,"value":"武宁县","parentId":215},
	    {"id":2439,"value":"永修县","parentId":215},
	    {"id":2440,"value":"浔阳区","parentId":215},
	    {"id":2441,"value":"湖口县","parentId":215},
	    {"id":2442,"value":"瑞昌市","parentId":215},
	    {"id":2443,"value":"都昌县","parentId":215},
	    {"id":2444,"value":"分宜县","parentId":216},
	    {"id":2445,"value":"渝水区","parentId":216},
	    {"id":2446,"value":"余江县","parentId":217},
	    {"id":2447,"value":"月湖区","parentId":217},
	    {"id":2448,"value":"贵溪市","parentId":217},
	    {"id":2449,"value":"上犹县","parentId":218},
	    {"id":2450,"value":"于都县","parentId":218},
	    {"id":2451,"value":"会昌县","parentId":218},
	    {"id":2452,"value":"信丰县","parentId":218},
	    {"id":2453,"value":"全南县","parentId":218},
	    {"id":2454,"value":"兴国县","parentId":218},
	    {"id":2455,"value":"南康市","parentId":218},
	    {"id":2456,"value":"大余县","parentId":218},
	    {"id":2457,"value":"宁都县","parentId":218},
	    {"id":2458,"value":"安远县","parentId":218},
	    {"id":2459,"value":"定南县","parentId":218},
	    {"id":2460,"value":"寻乌县","parentId":218},
	    {"id":2461,"value":"崇义县","parentId":218},
	    {"id":2462,"value":"瑞金市","parentId":218},
	    {"id":2463,"value":"石城县","parentId":218},
	    {"id":2464,"value":"章贡区","parentId":218},
	    {"id":2465,"value":"赣县","parentId":218},
	    {"id":2466,"value":"龙南县","parentId":218},
	    {"id":2467,"value":"万安县","parentId":219},
	    {"id":2468,"value":"井冈山市","parentId":219},
	    {"id":2469,"value":"吉安县","parentId":219},
	    {"id":2470,"value":"吉州区","parentId":219},
	    {"id":2471,"value":"吉水县","parentId":219},
	    {"id":2472,"value":"安福县","parentId":219},
	    {"id":2473,"value":"峡江县","parentId":219},
	    {"id":2474,"value":"新干县","parentId":219},
	    {"id":2475,"value":"永丰县","parentId":219},
	    {"id":2476,"value":"永新县","parentId":219},
	    {"id":2477,"value":"泰和县","parentId":219},
	    {"id":2478,"value":"遂川县","parentId":219},
	    {"id":2479,"value":"青原区","parentId":219},
	    {"id":2480,"value":"万载县","parentId":220},
	    {"id":2481,"value":"上高县","parentId":220},
	    {"id":2482,"value":"丰城市","parentId":220},
	    {"id":2483,"value":"奉新县","parentId":220},
	    {"id":2484,"value":"宜丰县","parentId":220},
	    {"id":2485,"value":"樟树市","parentId":220},
	    {"id":2486,"value":"袁州区","parentId":220},
	    {"id":2487,"value":"铜鼓县","parentId":220},
	    {"id":2488,"value":"靖安县","parentId":220},
	    {"id":2489,"value":"高安市","parentId":220},
	    {"id":2490,"value":"东乡县","parentId":221},
	    {"id":2491,"value":"临川区","parentId":221},
	    {"id":2492,"value":"乐安县","parentId":221},
	    {"id":2493,"value":"南丰县","parentId":221},
	    {"id":2494,"value":"南城县","parentId":221},
	    {"id":2495,"value":"宜黄县","parentId":221},
	    {"id":2496,"value":"崇仁县","parentId":221},
	    {"id":2497,"value":"广昌县","parentId":221},
	    {"id":2498,"value":"资溪县","parentId":221},
	    {"id":2499,"value":"金溪县","parentId":221},
	    {"id":2500,"value":"黎川县","parentId":221},
	    {"id":2501,"value":"万年县","parentId":222},
	    {"id":2502,"value":"上饶县","parentId":222},
	    {"id":2503,"value":"余干县","parentId":222},
	    {"id":2504,"value":"信州区","parentId":222},
	    {"id":2505,"value":"婺源县","parentId":222},
	    {"id":2506,"value":"广丰县","parentId":222},
	    {"id":2507,"value":"弋阳县","parentId":222},
	    {"id":2508,"value":"德兴市","parentId":222},
	    {"id":2509,"value":"横峰县","parentId":222},
	    {"id":2510,"value":"玉山县","parentId":222},
	    {"id":2511,"value":"鄱阳县","parentId":222},
	    {"id":2512,"value":"铅山县","parentId":222},
	    {"id":2513,"value":"历下区","parentId":223},
	    {"id":2514,"value":"历城区","parentId":223},
	    {"id":2515,"value":"商河县","parentId":223},
	    {"id":2516,"value":"天桥区","parentId":223},
	    {"id":2517,"value":"市中区","parentId":223},
	    {"id":2518,"value":"平阴县","parentId":223},
	    {"id":2519,"value":"槐荫区","parentId":223},
	    {"id":2520,"value":"济阳县","parentId":223},
	    {"id":2521,"value":"章丘市","parentId":223},
	    {"id":2522,"value":"长清区","parentId":223},
	    {"id":2523,"value":"即墨市","parentId":224},
	    {"id":2524,"value":"四方区","parentId":224},
	    {"id":2525,"value":"城阳区","parentId":224},
	    {"id":2526,"value":"崂山区","parentId":224},
	    {"id":2527,"value":"市北区","parentId":224},
	    {"id":2528,"value":"市南区","parentId":224},
	    {"id":2529,"value":"平度市","parentId":224},
	    {"id":2530,"value":"李沧区","parentId":224},
	    {"id":2531,"value":"胶南市","parentId":224},
	    {"id":2532,"value":"胶州市","parentId":224},
	    {"id":2533,"value":"莱西市","parentId":224},
	    {"id":2534,"value":"黄岛区","parentId":224},
	    {"id":2535,"value":"临淄区","parentId":225},
	    {"id":2536,"value":"博山区","parentId":225},
	    {"id":2537,"value":"周村区","parentId":225},
	    {"id":2538,"value":"张店区","parentId":225},
	    {"id":2539,"value":"桓台县","parentId":225},
	    {"id":2540,"value":"沂源县","parentId":225},
	    {"id":2541,"value":"淄川区","parentId":225},
	    {"id":2542,"value":"高青县","parentId":225},
	    {"id":2543,"value":"台儿庄区","parentId":226},
	    {"id":2544,"value":"山亭区","parentId":226},
	    {"id":2545,"value":"峄城区","parentId":226},
	    {"id":2546,"value":"市中区","parentId":226},
	    {"id":2547,"value":"滕州市","parentId":226},
	    {"id":2548,"value":"薛城区","parentId":226},
	    {"id":2549,"value":"东营区","parentId":227},
	    {"id":2550,"value":"利津县","parentId":227},
	    {"id":2551,"value":"垦利县","parentId":227},
	    {"id":2552,"value":"广饶县","parentId":227},
	    {"id":2553,"value":"河口区","parentId":227},
	    {"id":2554,"value":"招远市","parentId":228},
	    {"id":2555,"value":"栖霞市","parentId":228},
	    {"id":2556,"value":"海阳市","parentId":228},
	    {"id":2557,"value":"牟平区","parentId":228},
	    {"id":2558,"value":"福山区","parentId":228},
	    {"id":2559,"value":"芝罘区","parentId":228},
	    {"id":2560,"value":"莱山区","parentId":228},
	    {"id":2561,"value":"莱州市","parentId":228},
	    {"id":2562,"value":"莱阳市","parentId":228},
	    {"id":2563,"value":"蓬莱市","parentId":228},
	    {"id":2564,"value":"长岛县","parentId":228},
	    {"id":2565,"value":"龙口市","parentId":228},
	    {"id":2566,"value":"临朐县","parentId":229},
	    {"id":2567,"value":"坊子区","parentId":229},
	    {"id":2568,"value":"奎文区","parentId":229},
	    {"id":2569,"value":"安丘市","parentId":229},
	    {"id":2570,"value":"寒亭区","parentId":229},
	    {"id":2571,"value":"寿光市","parentId":229},
	    {"id":2572,"value":"昌乐县","parentId":229},
	    {"id":2573,"value":"昌邑市","parentId":229},
	    {"id":2574,"value":"潍城区","parentId":229},
	    {"id":2575,"value":"诸城市","parentId":229},
	    {"id":2576,"value":"青州市","parentId":229},
	    {"id":2577,"value":"高密市","parentId":229},
	    {"id":2578,"value":"任城区","parentId":230},
	    {"id":2579,"value":"兖州市","parentId":230},
	    {"id":2580,"value":"嘉祥县","parentId":230},
	    {"id":2581,"value":"市中区","parentId":230},
	    {"id":2582,"value":"微山县","parentId":230},
	    {"id":2583,"value":"曲阜市","parentId":230},
	    {"id":2584,"value":"梁山县","parentId":230},
	    {"id":2585,"value":"汶上县","parentId":230},
	    {"id":2586,"value":"泗水县","parentId":230},
	    {"id":2587,"value":"邹城市","parentId":230},
	    {"id":2588,"value":"金乡县","parentId":230},
	    {"id":2589,"value":"鱼台县","parentId":230},
	    {"id":2590,"value":"东平县","parentId":231},
	    {"id":2591,"value":"宁阳县","parentId":231},
	    {"id":2592,"value":"岱岳区","parentId":231},
	    {"id":2593,"value":"新泰市","parentId":231},
	    {"id":2594,"value":"泰山区","parentId":231},
	    {"id":2595,"value":"肥城市","parentId":231},
	    {"id":2596,"value":"乳山市","parentId":232},
	    {"id":2597,"value":"文登市","parentId":232},
	    {"id":2598,"value":"环翠区","parentId":232},
	    {"id":2599,"value":"荣成市","parentId":232},
	    {"id":2600,"value":"东港区","parentId":233},
	    {"id":2601,"value":"五莲县","parentId":233},
	    {"id":2602,"value":"岚山区","parentId":233},
	    {"id":2603,"value":"莒县","parentId":233},
	    {"id":2604,"value":"莱城区","parentId":234},
	    {"id":2605,"value":"钢城区","parentId":234},
	    {"id":2606,"value":"临沭县","parentId":235},
	    {"id":2607,"value":"兰山区","parentId":235},
	    {"id":2608,"value":"平邑县","parentId":235},
	    {"id":2609,"value":"沂南县","parentId":235},
	    {"id":2610,"value":"沂水县","parentId":235},
	    {"id":2611,"value":"河东区","parentId":235},
	    {"id":2612,"value":"罗庄区","parentId":235},
	    {"id":2613,"value":"苍山县","parentId":235},
	    {"id":2614,"value":"莒南县","parentId":235},
	    {"id":2615,"value":"蒙阴县","parentId":235},
	    {"id":2616,"value":"费县","parentId":235},
	    {"id":2617,"value":"郯城县","parentId":235},
	    {"id":2618,"value":"临邑县","parentId":236},
	    {"id":2619,"value":"乐陵市","parentId":236},
	    {"id":2620,"value":"夏津县","parentId":236},
	    {"id":2621,"value":"宁津县","parentId":236},
	    {"id":2622,"value":"平原县","parentId":236},
	    {"id":2623,"value":"庆云县","parentId":236},
	    {"id":2624,"value":"德城区","parentId":236},
	    {"id":2625,"value":"武城县","parentId":236},
	    {"id":2626,"value":"禹城市","parentId":236},
	    {"id":2627,"value":"陵县","parentId":236},
	    {"id":2628,"value":"齐河县","parentId":236},
	    {"id":2629,"value":"东昌府区","parentId":237},
	    {"id":2630,"value":"东阿县","parentId":237},
	    {"id":2631,"value":"临清市","parentId":237},
	    {"id":2632,"value":"冠县","parentId":237},
	    {"id":2633,"value":"茌平县","parentId":237},
	    {"id":2634,"value":"莘县","parentId":237},
	    {"id":2635,"value":"阳谷县","parentId":237},
	    {"id":2636,"value":"高唐县","parentId":237},
	    {"id":2637,"value":"博兴县","parentId":238},
	    {"id":2638,"value":"惠民县","parentId":238},
	    {"id":2639,"value":"无棣县","parentId":238},
	    {"id":2640,"value":"沾化县","parentId":238},
	    {"id":2641,"value":"滨城区","parentId":238},
	    {"id":2642,"value":"邹平县","parentId":238},
	    {"id":2643,"value":"阳信县","parentId":238},
	    {"id":2644,"value":"东明县","parentId":239},
	    {"id":2645,"value":"单县","parentId":239},
	    {"id":2646,"value":"定陶县","parentId":239},
	    {"id":2647,"value":"巨野县","parentId":239},
	    {"id":2648,"value":"成武县","parentId":239},
	    {"id":2649,"value":"曹县","parentId":239},
	    {"id":2650,"value":"牡丹区","parentId":239},
	    {"id":2651,"value":"郓城县","parentId":239},
	    {"id":2652,"value":"鄄城县","parentId":239},
	    {"id":2653,"value":"上街区","parentId":240},
	    {"id":2654,"value":"中原区","parentId":240},
	    {"id":2655,"value":"中牟县","parentId":240},
	    {"id":2656,"value":"二七区","parentId":240},
	    {"id":2657,"value":"巩义市","parentId":240},
	    {"id":2658,"value":"惠济区","parentId":240},
	    {"id":2659,"value":"新密市","parentId":240},
	    {"id":2660,"value":"新郑市","parentId":240},
	    {"id":2661,"value":"登封市","parentId":240},
	    {"id":2662,"value":"管城回族区","parentId":240},
	    {"id":2663,"value":"荥阳市","parentId":240},
	    {"id":2664,"value":"金水区","parentId":240},
	    {"id":2665,"value":"兰考县","parentId":241},
	    {"id":2666,"value":"尉氏县","parentId":241},
	    {"id":2667,"value":"开封县","parentId":241},
	    {"id":2668,"value":"杞县","parentId":241},
	    {"id":2669,"value":"禹王台区","parentId":241},
	    {"id":2670,"value":"通许县","parentId":241},
	    {"id":2671,"value":"金明区","parentId":241},
	    {"id":2672,"value":"顺河回族区","parentId":241},
	    {"id":2673,"value":"鼓楼区","parentId":241},
	    {"id":2674,"value":"龙亭区","parentId":241},
	    {"id":2675,"value":"伊川县","parentId":242},
	    {"id":2676,"value":"偃师市","parentId":242},
	    {"id":2677,"value":"吉利区","parentId":242},
	    {"id":2678,"value":"孟津县","parentId":242},
	    {"id":2679,"value":"宜阳县","parentId":242},
	    {"id":2680,"value":"嵩县","parentId":242},
	    {"id":2681,"value":"新安县","parentId":242},
	    {"id":2682,"value":"栾川县","parentId":242},
	    {"id":2683,"value":"汝阳县","parentId":242},
	    {"id":2684,"value":"洛宁县","parentId":242},
	    {"id":2685,"value":"洛龙区","parentId":242},
	    {"id":2686,"value":"涧西区","parentId":242},
	    {"id":2687,"value":"瀍河回族区","parentId":242},
	    {"id":2688,"value":"老城区","parentId":242},
	    {"id":2689,"value":"西工区","parentId":242},
	    {"id":2690,"value":"卫东区","parentId":243},
	    {"id":2691,"value":"叶县","parentId":243},
	    {"id":2692,"value":"宝丰县","parentId":243},
	    {"id":2693,"value":"新华区","parentId":243},
	    {"id":2694,"value":"汝州市","parentId":243},
	    {"id":2695,"value":"湛河区","parentId":243},
	    {"id":2696,"value":"石龙区","parentId":243},
	    {"id":2697,"value":"舞钢市","parentId":243},
	    {"id":2698,"value":"郏县","parentId":243},
	    {"id":2699,"value":"鲁山县","parentId":243},
	    {"id":2700,"value":"内黄县","parentId":244},
	    {"id":2701,"value":"北关区","parentId":244},
	    {"id":2702,"value":"安阳县","parentId":244},
	    {"id":2703,"value":"文峰区","parentId":244},
	    {"id":2704,"value":"林州市","parentId":244},
	    {"id":2705,"value":"殷都区","parentId":244},
	    {"id":2706,"value":"汤阴县","parentId":244},
	    {"id":2707,"value":"滑县","parentId":244},
	    {"id":2708,"value":"龙安区","parentId":244},
	    {"id":2709,"value":"山城区","parentId":245},
	    {"id":2710,"value":"浚县","parentId":245},
	    {"id":2711,"value":"淇县","parentId":245},
	    {"id":2712,"value":"淇滨区","parentId":245},
	    {"id":2713,"value":"鹤山区","parentId":245},
	    {"id":2714,"value":"凤泉区","parentId":246},
	    {"id":2715,"value":"卫滨区","parentId":246},
	    {"id":2716,"value":"卫辉市","parentId":246},
	    {"id":2717,"value":"原阳县","parentId":246},
	    {"id":2718,"value":"封丘县","parentId":246},
	    {"id":2719,"value":"延津县","parentId":246},
	    {"id":2720,"value":"新乡县","parentId":246},
	    {"id":2721,"value":"牧野区","parentId":246},
	    {"id":2722,"value":"红旗区","parentId":246},
	    {"id":2723,"value":"获嘉县","parentId":246},
	    {"id":2724,"value":"辉县市","parentId":246},
	    {"id":2725,"value":"长垣县","parentId":246},
	    {"id":2726,"value":"中站区","parentId":247},
	    {"id":2727,"value":"修武县","parentId":247},
	    {"id":2728,"value":"博爱县","parentId":247},
	    {"id":2729,"value":"孟州市","parentId":247},
	    {"id":2730,"value":"山阳区","parentId":247},
	    {"id":2731,"value":"武陟县","parentId":247},
	    {"id":2732,"value":"沁阳市","parentId":247},
	    {"id":2733,"value":"温县","parentId":247},
	    {"id":2734,"value":"解放区","parentId":247},
	    {"id":2735,"value":"马村区","parentId":247},
	    {"id":2736,"value":"华龙区","parentId":248},
	    {"id":2737,"value":"南乐县","parentId":248},
	    {"id":2738,"value":"台前县","parentId":248},
	    {"id":2739,"value":"清丰县","parentId":248},
	    {"id":2740,"value":"濮阳县","parentId":248},
	    {"id":2741,"value":"范县","parentId":248},
	    {"id":2742,"value":"禹州市","parentId":249},
	    {"id":2743,"value":"襄城县","parentId":249},
	    {"id":2744,"value":"许昌县","parentId":249},
	    {"id":2745,"value":"鄢陵县","parentId":249},
	    {"id":2746,"value":"长葛市","parentId":249},
	    {"id":2747,"value":"魏都区","parentId":249},
	    {"id":2748,"value":"临颍县","parentId":250},
	    {"id":2749,"value":"召陵区","parentId":250},
	    {"id":2750,"value":"源汇区","parentId":250},
	    {"id":2751,"value":"舞阳县","parentId":250},
	    {"id":2752,"value":"郾城区","parentId":250},
	    {"id":2753,"value":"义马市","parentId":251},
	    {"id":2754,"value":"卢氏县","parentId":251},
	    {"id":2755,"value":"渑池县","parentId":251},
	    {"id":2756,"value":"湖滨区","parentId":251},
	    {"id":2757,"value":"灵宝市","parentId":251},
	    {"id":2758,"value":"陕县","parentId":251},
	    {"id":2759,"value":"内乡县","parentId":252},
	    {"id":2760,"value":"南召县","parentId":252},
	    {"id":2761,"value":"卧龙区","parentId":252},
	    {"id":2762,"value":"唐河县","parentId":252},
	    {"id":2763,"value":"宛城区","parentId":252},
	    {"id":2764,"value":"新野县","parentId":252},
	    {"id":2765,"value":"方城县","parentId":252},
	    {"id":2766,"value":"桐柏县","parentId":252},
	    {"id":2767,"value":"淅川县","parentId":252},
	    {"id":2768,"value":"社旗县","parentId":252},
	    {"id":2769,"value":"西峡县","parentId":252},
	    {"id":2770,"value":"邓州市","parentId":252},
	    {"id":2771,"value":"镇平县","parentId":252},
	    {"id":2772,"value":"夏邑县","parentId":253},
	    {"id":2773,"value":"宁陵县","parentId":253},
	    {"id":2774,"value":"柘城县","parentId":253},
	    {"id":2775,"value":"民权县","parentId":253},
	    {"id":2776,"value":"永城市","parentId":253},
	    {"id":2777,"value":"睢县","parentId":253},
	    {"id":2778,"value":"睢阳区","parentId":253},
	    {"id":2779,"value":"粱园区","parentId":253},
	    {"id":2780,"value":"虞城县","parentId":253},
	    {"id":2781,"value":"光山县","parentId":254},
	    {"id":2782,"value":"商城县","parentId":254},
	    {"id":2783,"value":"固始县","parentId":254},
	    {"id":2784,"value":"平桥区","parentId":254},
	    {"id":2785,"value":"息县","parentId":254},
	    {"id":2786,"value":"新县","parentId":254},
	    {"id":2787,"value":"浉河区","parentId":254},
	    {"id":2788,"value":"淮滨县","parentId":254},
	    {"id":2789,"value":"潢川县","parentId":254},
	    {"id":2790,"value":"罗山县","parentId":254},
	    {"id":2791,"value":"商水县","parentId":255},
	    {"id":2792,"value":"太康县","parentId":255},
	    {"id":2793,"value":"川汇区","parentId":255},
	    {"id":2794,"value":"扶沟县","parentId":255},
	    {"id":2795,"value":"沈丘县","parentId":255},
	    {"id":2796,"value":"淮阳县","parentId":255},
	    {"id":2797,"value":"西华县","parentId":255},
	    {"id":2798,"value":"郸城县","parentId":255},
	    {"id":2799,"value":"项城市","parentId":255},
	    {"id":2800,"value":"鹿邑县","parentId":255},
	    {"id":2801,"value":"上蔡县","parentId":256},
	    {"id":2802,"value":"平舆县","parentId":256},
	    {"id":2803,"value":"新蔡县","parentId":256},
	    {"id":2804,"value":"正阳县","parentId":256},
	    {"id":2805,"value":"汝南县","parentId":256},
	    {"id":2806,"value":"泌阳县","parentId":256},
	    {"id":2807,"value":"确山县","parentId":256},
	    {"id":2808,"value":"西平县","parentId":256},
	    {"id":2809,"value":"遂平县","parentId":256},
	    {"id":2810,"value":"驿城区","parentId":256},
	    {"id":2811,"value":"济源市","parentId":257},
	    {"id":2812,"value":"东西湖区","parentId":258},
	    {"id":2813,"value":"新洲区","parentId":258},
	    {"id":2814,"value":"武昌区","parentId":258},
	    {"id":2815,"value":"汉南区","parentId":258},
	    {"id":2816,"value":"汉阳区","parentId":258},
	    {"id":2817,"value":"江夏区","parentId":258},
	    {"id":2818,"value":"江岸区","parentId":258},
	    {"id":2819,"value":"江汉区","parentId":258},
	    {"id":2820,"value":"洪山区","parentId":258},
	    {"id":2821,"value":"硚口区","parentId":258},
	    {"id":2822,"value":"蔡甸区","parentId":258},
	    {"id":2823,"value":"青山区","parentId":258},
	    {"id":2824,"value":"黄陂区","parentId":258},
	    {"id":2825,"value":"下陆区","parentId":259},
	    {"id":2826,"value":"大冶市","parentId":259},
	    {"id":2827,"value":"西塞山区","parentId":259},
	    {"id":2828,"value":"铁山区","parentId":259},
	    {"id":2829,"value":"阳新县","parentId":259},
	    {"id":2830,"value":"黄石港区","parentId":259},
	    {"id":2831,"value":"丹江口市","parentId":260},
	    {"id":2832,"value":"张湾区","parentId":260},
	    {"id":2833,"value":"房县","parentId":260},
	    {"id":2834,"value":"竹山县","parentId":260},
	    {"id":2835,"value":"竹溪县","parentId":260},
	    {"id":2836,"value":"茅箭区","parentId":260},
	    {"id":2837,"value":"郧县","parentId":260},
	    {"id":2838,"value":"郧西县","parentId":260},
	    {"id":2839,"value":"五峰土家族自治县","parentId":261},
	    {"id":2840,"value":"伍家岗区","parentId":261},
	    {"id":2841,"value":"兴山县","parentId":261},
	    {"id":2842,"value":"夷陵区","parentId":261},
	    {"id":2843,"value":"宜都市","parentId":261},
	    {"id":2844,"value":"当阳市","parentId":261},
	    {"id":2845,"value":"枝江市","parentId":261},
	    {"id":2846,"value":"点军区","parentId":261},
	    {"id":2847,"value":"秭归县","parentId":261},
	    {"id":2848,"value":"虢亭区","parentId":261},
	    {"id":2849,"value":"西陵区","parentId":261},
	    {"id":2850,"value":"远安县","parentId":261},
	    {"id":2851,"value":"长阳土家族自治县","parentId":261},
	    {"id":2852,"value":"保康县","parentId":262},
	    {"id":2853,"value":"南漳县","parentId":262},
	    {"id":2854,"value":"宜城市","parentId":262},
	    {"id":2855,"value":"枣阳市","parentId":262},
	    {"id":2856,"value":"樊城区","parentId":262},
	    {"id":2857,"value":"老河口市","parentId":262},
	    {"id":2858,"value":"襄城区","parentId":262},
	    {"id":2859,"value":"襄阳区","parentId":262},
	    {"id":2860,"value":"谷城县","parentId":262},
	    {"id":2861,"value":"华容区","parentId":263},
	    {"id":2862,"value":"粱子湖","parentId":263},
	    {"id":2863,"value":"鄂城区","parentId":263},
	    {"id":2864,"value":"东宝区","parentId":264},
	    {"id":2865,"value":"京山县","parentId":264},
	    {"id":2866,"value":"掇刀区","parentId":264},
	    {"id":2867,"value":"沙洋县","parentId":264},
	    {"id":2868,"value":"钟祥市","parentId":264},
	    {"id":2869,"value":"云梦县","parentId":265},
	    {"id":2870,"value":"大悟县","parentId":265},
	    {"id":2871,"value":"孝南区","parentId":265},
	    {"id":2872,"value":"孝昌县","parentId":265},
	    {"id":2873,"value":"安陆市","parentId":265},
	    {"id":2874,"value":"应城市","parentId":265},
	    {"id":2875,"value":"汉川市","parentId":265},
	    {"id":2876,"value":"公安县","parentId":266},
	    {"id":2877,"value":"松滋市","parentId":266},
	    {"id":2878,"value":"江陵县","parentId":266},
	    {"id":2879,"value":"沙市区","parentId":266},
	    {"id":2880,"value":"洪湖市","parentId":266},
	    {"id":2881,"value":"监利县","parentId":266},
	    {"id":2882,"value":"石首市","parentId":266},
	    {"id":2883,"value":"荆州区","parentId":266},
	    {"id":2884,"value":"团风县","parentId":267},
	    {"id":2885,"value":"武穴市","parentId":267},
	    {"id":2886,"value":"浠水县","parentId":267},
	    {"id":2887,"value":"红安县","parentId":267},
	    {"id":2888,"value":"罗田县","parentId":267},
	    {"id":2889,"value":"英山县","parentId":267},
	    {"id":2890,"value":"蕲春县","parentId":267},
	    {"id":2891,"value":"麻城市","parentId":267},
	    {"id":2892,"value":"黄州区","parentId":267},
	    {"id":2893,"value":"黄梅县","parentId":267},
	    {"id":2894,"value":"咸安区","parentId":268},
	    {"id":2895,"value":"嘉鱼县","parentId":268},
	    {"id":2896,"value":"崇阳县","parentId":268},
	    {"id":2897,"value":"赤壁市","parentId":268},
	    {"id":2898,"value":"通城县","parentId":268},
	    {"id":2899,"value":"通山县","parentId":268},
	    {"id":2900,"value":"广水市","parentId":269},
	    {"id":2901,"value":"曾都区","parentId":269},
	    {"id":2902,"value":"利川市","parentId":270},
	    {"id":2903,"value":"咸丰县","parentId":270},
	    {"id":2904,"value":"宣恩县","parentId":270},
	    {"id":2905,"value":"巴东县","parentId":270},
	    {"id":2906,"value":"建始县","parentId":270},
	    {"id":2907,"value":"恩施市","parentId":270},
	    {"id":2908,"value":"来凤县","parentId":270},
	    {"id":2909,"value":"鹤峰县","parentId":270},
	    {"id":2910,"value":"仙桃市","parentId":271},
	    {"id":2911,"value":"潜江市","parentId":272},
	    {"id":2912,"value":"天门市","parentId":273},
	    {"id":2913,"value":"神农架林区","parentId":274},
	    {"id":2914,"value":"天心区","parentId":275},
	    {"id":2915,"value":"宁乡县","parentId":275},
	    {"id":2916,"value":"岳麓区","parentId":275},
	    {"id":2917,"value":"开福区","parentId":275},
	    {"id":2918,"value":"望城县","parentId":275},
	    {"id":2919,"value":"浏阳市","parentId":275},
	    {"id":2920,"value":"芙蓉区","parentId":275},
	    {"id":2921,"value":"长沙县","parentId":275},
	    {"id":2922,"value":"雨花区","parentId":275},
	    {"id":2923,"value":"天元区","parentId":276},
	    {"id":2924,"value":"攸县","parentId":276},
	    {"id":2925,"value":"株洲县","parentId":276},
	    {"id":2926,"value":"炎陵县","parentId":276},
	    {"id":2927,"value":"石峰区","parentId":276},
	    {"id":2928,"value":"芦淞区","parentId":276},
	    {"id":2929,"value":"茶陵县","parentId":276},
	    {"id":2930,"value":"荷塘区","parentId":276},
	    {"id":2931,"value":"醴陵市","parentId":276},
	    {"id":2932,"value":"岳塘区","parentId":277},
	    {"id":2933,"value":"湘乡市","parentId":277},
	    {"id":2934,"value":"湘潭县","parentId":277},
	    {"id":2935,"value":"雨湖区","parentId":277},
	    {"id":2936,"value":"韶山市","parentId":277},
	    {"id":2937,"value":"南岳区","parentId":278},
	    {"id":2938,"value":"常宁市","parentId":278},
	    {"id":2939,"value":"珠晖区","parentId":278},
	    {"id":2940,"value":"石鼓区","parentId":278},
	    {"id":2941,"value":"祁东县","parentId":278},
	    {"id":2942,"value":"耒阳市","parentId":278},
	    {"id":2943,"value":"蒸湘区","parentId":278},
	    {"id":2944,"value":"衡东县","parentId":278},
	    {"id":2945,"value":"衡南县","parentId":278},
	    {"id":2946,"value":"衡山县","parentId":278},
	    {"id":2947,"value":"衡阳县","parentId":278},
	    {"id":2948,"value":"雁峰区","parentId":278},
	    {"id":2949,"value":"北塔区","parentId":279},
	    {"id":2950,"value":"双清区","parentId":279},
	    {"id":2951,"value":"城步苗族自治县","parentId":279},
	    {"id":2952,"value":"大祥区","parentId":279},
	    {"id":2953,"value":"新宁县","parentId":279},
	    {"id":2954,"value":"新邵县","parentId":279},
	    {"id":2955,"value":"武冈市","parentId":279},
	    {"id":2956,"value":"洞口县","parentId":279},
	    {"id":2957,"value":"绥宁县","parentId":279},
	    {"id":2958,"value":"邵东县","parentId":279},
	    {"id":2959,"value":"邵阳县","parentId":279},
	    {"id":2960,"value":"隆回县","parentId":279},
	    {"id":2961,"value":"临湘市","parentId":280},
	    {"id":2962,"value":"云溪区","parentId":280},
	    {"id":2963,"value":"华容县","parentId":280},
	    {"id":2964,"value":"君山区","parentId":280},
	    {"id":2965,"value":"岳阳县","parentId":280},
	    {"id":2966,"value":"岳阳楼区","parentId":280},
	    {"id":2967,"value":"平江县","parentId":280},
	    {"id":2968,"value":"汨罗市","parentId":280},
	    {"id":2969,"value":"湘阴县","parentId":280},
	    {"id":2970,"value":"临澧县","parentId":281},
	    {"id":2971,"value":"安乡县","parentId":281},
	    {"id":2972,"value":"桃源县","parentId":281},
	    {"id":2973,"value":"武陵区","parentId":281},
	    {"id":2974,"value":"汉寿县","parentId":281},
	    {"id":2975,"value":"津市市","parentId":281},
	    {"id":2976,"value":"澧县","parentId":281},
	    {"id":2977,"value":"石门县","parentId":281},
	    {"id":2978,"value":"鼎城区","parentId":281},
	    {"id":2979,"value":"慈利县","parentId":282},
	    {"id":2980,"value":"桑植县","parentId":282},
	    {"id":2981,"value":"武陵源区","parentId":282},
	    {"id":2982,"value":"永定区","parentId":282},
	    {"id":2983,"value":"南县","parentId":283},
	    {"id":2984,"value":"安化县","parentId":283},
	    {"id":2985,"value":"桃江县","parentId":283},
	    {"id":2986,"value":"沅江市","parentId":283},
	    {"id":2987,"value":"资阳区","parentId":283},
	    {"id":2988,"value":"赫山区","parentId":283},
	    {"id":2989,"value":"临武县","parentId":284},
	    {"id":2990,"value":"北湖区","parentId":284},
	    {"id":2991,"value":"嘉禾县","parentId":284},
	    {"id":2992,"value":"安仁县","parentId":284},
	    {"id":2993,"value":"宜章县","parentId":284},
	    {"id":2994,"value":"桂东县","parentId":284},
	    {"id":2995,"value":"桂阳县","parentId":284},
	    {"id":2996,"value":"永兴县","parentId":284},
	    {"id":2997,"value":"汝城县","parentId":284},
	    {"id":2998,"value":"苏仙区","parentId":284},
	    {"id":2999,"value":"资兴市","parentId":284},
	    {"id":3000,"value":"东安县","parentId":285},
	    {"id":3001,"value":"冷水滩区","parentId":285},
	    {"id":3002,"value":"双牌县","parentId":285},
	    {"id":3003,"value":"宁远县","parentId":285},
	    {"id":3004,"value":"新田县","parentId":285},
	    {"id":3005,"value":"江华瑶族自治县","parentId":285},
	    {"id":3006,"value":"江永县","parentId":285},
	    {"id":3007,"value":"祁阳县","parentId":285},
	    {"id":3008,"value":"蓝山县","parentId":285},
	    {"id":3009,"value":"道县","parentId":285},
	    {"id":3010,"value":"零陵区","parentId":285},
	    {"id":3011,"value":"中方县","parentId":286},
	    {"id":3012,"value":"会同县","parentId":286},
	    {"id":3013,"value":"新晃侗族自治县","parentId":286},
	    {"id":3014,"value":"沅陵县","parentId":286},
	    {"id":3015,"value":"洪江市/洪江区","parentId":286},
	    {"id":3016,"value":"溆浦县","parentId":286},
	    {"id":3017,"value":"芷江侗族自治县","parentId":286},
	    {"id":3018,"value":"辰溪县","parentId":286},
	    {"id":3019,"value":"通道侗族自治县","parentId":286},
	    {"id":3020,"value":"靖州苗族侗族自治县","parentId":286},
	    {"id":3021,"value":"鹤城区","parentId":286},
	    {"id":3022,"value":"麻阳苗族自治县","parentId":286},
	    {"id":3023,"value":"冷水江市","parentId":287},
	    {"id":3024,"value":"双峰县","parentId":287},
	    {"id":3025,"value":"娄星区","parentId":287},
	    {"id":3026,"value":"新化县","parentId":287},
	    {"id":3027,"value":"涟源市","parentId":287},
	    {"id":3028,"value":"保靖县","parentId":288},
	    {"id":3029,"value":"凤凰县","parentId":288},
	    {"id":3030,"value":"古丈县","parentId":288},
	    {"id":3031,"value":"吉首市","parentId":288},
	    {"id":3032,"value":"永顺县","parentId":288},
	    {"id":3033,"value":"泸溪县","parentId":288},
	    {"id":3034,"value":"花垣县","parentId":288},
	    {"id":3035,"value":"龙山县","parentId":288},
	    {"id":3036,"value":"萝岗区","parentId":289},
	    {"id":3037,"value":"南沙区","parentId":289},
	    {"id":3038,"value":"从化市","parentId":289},
	    {"id":3039,"value":"增城市","parentId":289},
	    {"id":3040,"value":"天河区","parentId":289},
	    {"id":3041,"value":"海珠区","parentId":289},
	    {"id":3042,"value":"番禺区","parentId":289},
	    {"id":3043,"value":"白云区","parentId":289},
	    {"id":3044,"value":"花都区","parentId":289},
	    {"id":3045,"value":"荔湾区","parentId":289},
	    {"id":3046,"value":"越秀区","parentId":289},
	    {"id":3047,"value":"黄埔区","parentId":289},
	    {"id":3048,"value":"乐昌市","parentId":290},
	    {"id":3049,"value":"乳源瑶族自治县","parentId":290},
	    {"id":3050,"value":"仁化县","parentId":290},
	    {"id":3051,"value":"南雄市","parentId":290},
	    {"id":3052,"value":"始兴县","parentId":290},
	    {"id":3053,"value":"新丰县","parentId":290},
	    {"id":3054,"value":"曲江区","parentId":290},
	    {"id":3055,"value":"武江区","parentId":290},
	    {"id":3056,"value":"浈江区","parentId":290},
	    {"id":3057,"value":"翁源县","parentId":290},
	    {"id":3058,"value":"南山区","parentId":291},
	    {"id":3059,"value":"宝安区","parentId":291},
	    {"id":3060,"value":"盐田区","parentId":291},
	    {"id":3061,"value":"福田区","parentId":291},
	    {"id":3062,"value":"罗湖区","parentId":291},
	    {"id":3063,"value":"龙岗区","parentId":291},
	    {"id":3064,"value":"斗门区","parentId":292},
	    {"id":3065,"value":"金湾区","parentId":292},
	    {"id":3066,"value":"香洲区","parentId":292},
	    {"id":3067,"value":"南澳县","parentId":293},
	    {"id":3068,"value":"潮南区","parentId":293},
	    {"id":3069,"value":"潮阳区","parentId":293},
	    {"id":3070,"value":"澄海区","parentId":293},
	    {"id":3071,"value":"濠江区","parentId":293},
	    {"id":3072,"value":"金平区","parentId":293},
	    {"id":3073,"value":"龙湖区","parentId":293},
	    {"id":3074,"value":"三水区","parentId":294},
	    {"id":3075,"value":"南海区","parentId":294},
	    {"id":3076,"value":"禅城区","parentId":294},
	    {"id":3077,"value":"顺德区","parentId":294},
	    {"id":3078,"value":"高明区","parentId":294},
	    {"id":3079,"value":"台山市","parentId":295},
	    {"id":3080,"value":"开平市","parentId":295},
	    {"id":3081,"value":"恩平市","parentId":295},
	    {"id":3082,"value":"新会区","parentId":295},
	    {"id":3083,"value":"江海区","parentId":295},
	    {"id":3084,"value":"蓬江区","parentId":295},
	    {"id":3085,"value":"鹤山市","parentId":295},
	    {"id":3086,"value":"吴川市","parentId":296},
	    {"id":3087,"value":"坡头区","parentId":296},
	    {"id":3088,"value":"廉江市","parentId":296},
	    {"id":3089,"value":"徐闻县","parentId":296},
	    {"id":3090,"value":"赤坎区","parentId":296},
	    {"id":3091,"value":"遂溪县","parentId":296},
	    {"id":3092,"value":"雷州市","parentId":296},
	    {"id":3093,"value":"霞山区","parentId":296},
	    {"id":3094,"value":"麻章区","parentId":296},
	    {"id":3095,"value":"信宜市","parentId":297},
	    {"id":3096,"value":"化州市","parentId":297},
	    {"id":3097,"value":"电白县","parentId":297},
	    {"id":3098,"value":"茂南区","parentId":297},
	    {"id":3099,"value":"茂港区","parentId":297},
	    {"id":3100,"value":"高州市","parentId":297},
	    {"id":3101,"value":"四会市","parentId":298},
	    {"id":3102,"value":"封开县","parentId":298},
	    {"id":3103,"value":"广宁县","parentId":298},
	    {"id":3104,"value":"德庆县","parentId":298},
	    {"id":3105,"value":"怀集县","parentId":298},
	    {"id":3106,"value":"端州区","parentId":298},
	    {"id":3107,"value":"高要市","parentId":298},
	    {"id":3108,"value":"鼎湖区","parentId":298},
	    {"id":3109,"value":"博罗县","parentId":299},
	    {"id":3110,"value":"惠东县","parentId":299},
	    {"id":3111,"value":"惠城区","parentId":299},
	    {"id":3112,"value":"惠阳区","parentId":299},
	    {"id":3113,"value":"龙门县","parentId":299},
	    {"id":3114,"value":"丰顺县","parentId":300},
	    {"id":3115,"value":"五华县","parentId":300},
	    {"id":3116,"value":"兴宁市","parentId":300},
	    {"id":3117,"value":"大埔县","parentId":300},
	    {"id":3118,"value":"平远县","parentId":300},
	    {"id":3119,"value":"梅县","parentId":300},
	    {"id":3120,"value":"梅江区","parentId":300},
	    {"id":3121,"value":"蕉岭县","parentId":300},
	    {"id":3122,"value":"城区","parentId":301},
	    {"id":3123,"value":"海丰县","parentId":301},
	    {"id":3124,"value":"陆丰市","parentId":301},
	    {"id":3125,"value":"陆河县","parentId":301},
	    {"id":3126,"value":"东源县","parentId":302},
	    {"id":3127,"value":"和平县","parentId":302},
	    {"id":3128,"value":"源城区","parentId":302},
	    {"id":3129,"value":"紫金县","parentId":302},
	    {"id":3130,"value":"连平县","parentId":302},
	    {"id":3131,"value":"龙川县","parentId":302},
	    {"id":3132,"value":"江城区","parentId":303},
	    {"id":3133,"value":"阳东县","parentId":303},
	    {"id":3134,"value":"阳春市","parentId":303},
	    {"id":3135,"value":"阳西县","parentId":303},
	    {"id":3136,"value":"佛冈县","parentId":304},
	    {"id":3137,"value":"清城区","parentId":304},
	    {"id":3138,"value":"清新县","parentId":304},
	    {"id":3139,"value":"英德市","parentId":304},
	    {"id":3140,"value":"连南瑶族自治县","parentId":304},
	    {"id":3141,"value":"连山壮族瑶族自治县","parentId":304},
	    {"id":3142,"value":"连州市","parentId":304},
	    {"id":3143,"value":"阳山县","parentId":304},
	    {"id":3144,"value":"东莞市","parentId":305},
	    {"id":3145,"value":"中山市","parentId":306},
	    {"id":3146,"value":"湘桥区","parentId":307},
	    {"id":3147,"value":"潮安县","parentId":307},
	    {"id":3148,"value":"饶平县","parentId":307},
	    {"id":3149,"value":"惠来县","parentId":308},
	    {"id":3150,"value":"揭东县","parentId":308},
	    {"id":3151,"value":"揭西县","parentId":308},
	    {"id":3152,"value":"普宁市","parentId":308},
	    {"id":3153,"value":"榕城区","parentId":308},
	    {"id":3154,"value":"云城区","parentId":309},
	    {"id":3155,"value":"云安县","parentId":309},
	    {"id":3156,"value":"新兴县","parentId":309},
	    {"id":3157,"value":"罗定市","parentId":309},
	    {"id":3158,"value":"郁南县","parentId":309},
	    {"id":3159,"value":"上林县","parentId":310},
	    {"id":3160,"value":"兴宁区","parentId":310},
	    {"id":3161,"value":"宾阳县","parentId":310},
	    {"id":3162,"value":"横县","parentId":310},
	    {"id":3163,"value":"武鸣县","parentId":310},
	    {"id":3164,"value":"江南区","parentId":310},
	    {"id":3165,"value":"良庆区","parentId":310},
	    {"id":3166,"value":"西乡塘区","parentId":310},
	    {"id":3167,"value":"邕宁区","parentId":310},
	    {"id":3168,"value":"隆安县","parentId":310},
	    {"id":3169,"value":"青秀区","parentId":310},
	    {"id":3170,"value":"马山县","parentId":310},
	    {"id":3171,"value":"三江侗族自治县","parentId":311},
	    {"id":3172,"value":"城中区","parentId":311},
	    {"id":3173,"value":"柳北区","parentId":311},
	    {"id":3174,"value":"柳南区","parentId":311},
	    {"id":3175,"value":"柳城县","parentId":311},
	    {"id":3176,"value":"柳江县","parentId":311},
	    {"id":3177,"value":"融安县","parentId":311},
	    {"id":3178,"value":"融水苗族自治县","parentId":311},
	    {"id":3179,"value":"鱼峰区","parentId":311},
	    {"id":3180,"value":"鹿寨县","parentId":311},
	    {"id":3181,"value":"七星区","parentId":312},
	    {"id":3182,"value":"临桂县","parentId":312},
	    {"id":3183,"value":"全州县","parentId":312},
	    {"id":3184,"value":"兴安县","parentId":312},
	    {"id":3185,"value":"叠彩区","parentId":312},
	    {"id":3186,"value":"平乐县","parentId":312},
	    {"id":3187,"value":"恭城瑶族自治县","parentId":312},
	    {"id":3188,"value":"永福县","parentId":312},
	    {"id":3189,"value":"灌阳县","parentId":312},
	    {"id":3190,"value":"灵川县","parentId":312},
	    {"id":3191,"value":"秀峰区","parentId":312},
	    {"id":3192,"value":"荔浦县","parentId":312},
	    {"id":3193,"value":"象山区","parentId":312},
	    {"id":3194,"value":"资源县","parentId":312},
	    {"id":3195,"value":"阳朔县","parentId":312},
	    {"id":3196,"value":"雁山区","parentId":312},
	    {"id":3197,"value":"龙胜各族自治县","parentId":312},
	    {"id":3198,"value":"万秀区","parentId":313},
	    {"id":3199,"value":"岑溪市","parentId":313},
	    {"id":3200,"value":"苍梧县","parentId":313},
	    {"id":3201,"value":"蒙山县","parentId":313},
	    {"id":3202,"value":"藤县","parentId":313},
	    {"id":3203,"value":"蝶山区","parentId":313},
	    {"id":3204,"value":"长洲区","parentId":313},
	    {"id":3205,"value":"合浦县","parentId":314},
	    {"id":3206,"value":"海城区","parentId":314},
	    {"id":3207,"value":"铁山港区","parentId":314},
	    {"id":3208,"value":"银海区","parentId":314},
	    {"id":3209,"value":"上思县","parentId":315},
	    {"id":3210,"value":"东兴市","parentId":315},
	    {"id":3211,"value":"港口区","parentId":315},
	    {"id":3212,"value":"防城区","parentId":315},
	    {"id":3213,"value":"浦北县","parentId":316},
	    {"id":3214,"value":"灵山县","parentId":316},
	    {"id":3215,"value":"钦北区","parentId":316},
	    {"id":3216,"value":"钦南区","parentId":316},
	    {"id":3217,"value":"平南县","parentId":317},
	    {"id":3218,"value":"桂平市","parentId":317},
	    {"id":3219,"value":"港北区","parentId":317},
	    {"id":3220,"value":"港南区","parentId":317},
	    {"id":3221,"value":"覃塘区","parentId":317},
	    {"id":3222,"value":"兴业县","parentId":318},
	    {"id":3223,"value":"北流市","parentId":318},
	    {"id":3224,"value":"博白县","parentId":318},
	    {"id":3225,"value":"容县","parentId":318},
	    {"id":3226,"value":"玉州区","parentId":318},
	    {"id":3227,"value":"陆川县","parentId":318},
	    {"id":3228,"value":"乐业县","parentId":319},
	    {"id":3229,"value":"凌云县","parentId":319},
	    {"id":3230,"value":"右江区","parentId":319},
	    {"id":3231,"value":"平果县","parentId":319},
	    {"id":3232,"value":"德保县","parentId":319},
	    {"id":3233,"value":"田东县","parentId":319},
	    {"id":3234,"value":"田林县","parentId":319},
	    {"id":3235,"value":"田阳县","parentId":319},
	    {"id":3236,"value":"西林县","parentId":319},
	    {"id":3237,"value":"那坡县","parentId":319},
	    {"id":3238,"value":"隆林各族自治县","parentId":319},
	    {"id":3239,"value":"靖西县","parentId":319},
	    {"id":3240,"value":"八步区","parentId":320},
	    {"id":3241,"value":"富川瑶族自治县","parentId":320},
	    {"id":3242,"value":"昭平县","parentId":320},
	    {"id":3243,"value":"钟山县","parentId":320},
	    {"id":3244,"value":"东兰县","parentId":321},
	    {"id":3245,"value":"凤山县","parentId":321},
	    {"id":3246,"value":"南丹县","parentId":321},
	    {"id":3247,"value":"大化瑶族自治县","parentId":321},
	    {"id":3248,"value":"天峨县","parentId":321},
	    {"id":3249,"value":"宜州市","parentId":321},
	    {"id":3250,"value":"巴马瑶族自治县","parentId":321},
	    {"id":3251,"value":"环江毛南族自治县","parentId":321},
	    {"id":3252,"value":"罗城仫佬族自治县","parentId":321},
	    {"id":3253,"value":"都安瑶族自治县","parentId":321},
	    {"id":3254,"value":"金城江区","parentId":321},
	    {"id":3255,"value":"兴宾区","parentId":322},
	    {"id":3256,"value":"合山市","parentId":322},
	    {"id":3257,"value":"忻城县","parentId":322},
	    {"id":3258,"value":"武宣县","parentId":322},
	    {"id":3259,"value":"象州县","parentId":322},
	    {"id":3260,"value":"金秀瑶族自治县","parentId":322},
	    {"id":3261,"value":"凭祥市","parentId":323},
	    {"id":3262,"value":"大新县","parentId":323},
	    {"id":3263,"value":"天等县","parentId":323},
	    {"id":3264,"value":"宁明县","parentId":323},
	    {"id":3265,"value":"扶绥县","parentId":323},
	    {"id":3266,"value":"江州区","parentId":323},
	    {"id":3267,"value":"龙州县","parentId":323},
	    {"id":3268,"value":"琼山区","parentId":324},
	    {"id":3269,"value":"秀英区","parentId":324},
	    {"id":3270,"value":"美兰区","parentId":324},
	    {"id":3271,"value":"龙华区","parentId":324},
	    {"id":3272,"value":"三亚市","parentId":325},
	    {"id":3273,"value":"五指山市","parentId":326},
	    {"id":3274,"value":"琼海市","parentId":327},
	    {"id":3275,"value":"儋州市","parentId":328},
	    {"id":3276,"value":"文昌市","parentId":329},
	    {"id":3277,"value":"万宁市","parentId":330},
	    {"id":3278,"value":"东方市","parentId":331},
	    {"id":3279,"value":"定安县","parentId":332},
	    {"id":3280,"value":"屯昌县","parentId":333},
	    {"id":3281,"value":"澄迈县","parentId":334},
	    {"id":3282,"value":"临高县","parentId":335},
	    {"id":3283,"value":"白沙黎族自治县","parentId":336},
	    {"id":3284,"value":"昌江黎族自治县","parentId":337},
	    {"id":3285,"value":"乐东黎族自治县","parentId":338},
	    {"id":3286,"value":"陵水黎族自治县","parentId":339},
	    {"id":3287,"value":"保亭黎族苗族自治县","parentId":340},
	    {"id":3288,"value":"琼中黎族苗族自治县","parentId":341},
	    {"id":4209,"value":"双流县","parentId":385},
	    {"id":4210,"value":"大邑县","parentId":385},
	    {"id":4211,"value":"崇州市","parentId":385},
	    {"id":4212,"value":"彭州市","parentId":385},
	    {"id":4213,"value":"成华区","parentId":385},
	    {"id":4214,"value":"新津县","parentId":385},
	    {"id":4215,"value":"新都区","parentId":385},
	    {"id":4216,"value":"武侯区","parentId":385},
	    {"id":4217,"value":"温江区","parentId":385},
	    {"id":4218,"value":"蒲江县","parentId":385},
	    {"id":4219,"value":"邛崃市","parentId":385},
	    {"id":4220,"value":"郫县","parentId":385},
	    {"id":4221,"value":"都江堰市","parentId":385},
	    {"id":4222,"value":"金堂县","parentId":385},
	    {"id":4223,"value":"金牛区","parentId":385},
	    {"id":4224,"value":"锦江区","parentId":385},
	    {"id":4225,"value":"青白江区","parentId":385},
	    {"id":4226,"value":"青羊区","parentId":385},
	    {"id":4227,"value":"龙泉驿区","parentId":385},
	    {"id":4228,"value":"大安区","parentId":386},
	    {"id":4229,"value":"富顺县","parentId":386},
	    {"id":4230,"value":"沿滩区","parentId":386},
	    {"id":4231,"value":"自流井区","parentId":386},
	    {"id":4232,"value":"荣县","parentId":386},
	    {"id":4233,"value":"贡井区","parentId":386},
	    {"id":4234,"value":"东区","parentId":387},
	    {"id":4235,"value":"仁和区","parentId":387},
	    {"id":4236,"value":"盐边县","parentId":387},
	    {"id":4237,"value":"米易县","parentId":387},
	    {"id":4238,"value":"西区","parentId":387},
	    {"id":4239,"value":"叙永县","parentId":388},
	    {"id":4240,"value":"古蔺县","parentId":388},
	    {"id":4241,"value":"合江县","parentId":388},
	    {"id":4242,"value":"江阳区","parentId":388},
	    {"id":4243,"value":"泸县","parentId":388},
	    {"id":4244,"value":"纳溪区","parentId":388},
	    {"id":4245,"value":"龙马潭区","parentId":388},
	    {"id":4246,"value":"中江县","parentId":389},
	    {"id":4247,"value":"什邡市","parentId":389},
	    {"id":4248,"value":"广汉市","parentId":389},
	    {"id":4249,"value":"旌阳区","parentId":389},
	    {"id":4250,"value":"绵竹市","parentId":389},
	    {"id":4251,"value":"罗江县","parentId":389},
	    {"id":4252,"value":"三台县","parentId":390},
	    {"id":4253,"value":"北川羌族自治县","parentId":390},
	    {"id":4254,"value":"安县","parentId":390},
	    {"id":4255,"value":"平武县","parentId":390},
	    {"id":4256,"value":"梓潼县","parentId":390},
	    {"id":4257,"value":"江油市","parentId":390},
	    {"id":4258,"value":"涪城区","parentId":390},
	    {"id":4259,"value":"游仙区","parentId":390},
	    {"id":4260,"value":"盐亭县","parentId":390},
	    {"id":4261,"value":"元坝区","parentId":391},
	    {"id":4262,"value":"利州区","parentId":391},
	    {"id":4263,"value":"剑阁县","parentId":391},
	    {"id":4264,"value":"旺苍县","parentId":391},
	    {"id":4265,"value":"朝天区","parentId":391},
	    {"id":4266,"value":"苍溪县","parentId":391},
	    {"id":4267,"value":"青川县","parentId":391},
	    {"id":4268,"value":"大英县","parentId":392},
	    {"id":4269,"value":"安居区","parentId":392},
	    {"id":4270,"value":"射洪县","parentId":392},
	    {"id":4271,"value":"船山区","parentId":392},
	    {"id":4272,"value":"蓬溪县","parentId":392},
	    {"id":4273,"value":"东兴区","parentId":393},
	    {"id":4274,"value":"威远县","parentId":393},
	    {"id":4275,"value":"市中区","parentId":393},
	    {"id":4276,"value":"资中县","parentId":393},
	    {"id":4277,"value":"隆昌县","parentId":393},
	    {"id":4278,"value":"五通桥区","parentId":394},
	    {"id":4279,"value":"井研县","parentId":394},
	    {"id":4280,"value":"夹江县","parentId":394},
	    {"id":4281,"value":"峨眉山市","parentId":394},
	    {"id":4282,"value":"峨边彝族自治县","parentId":394},
	    {"id":4283,"value":"市中区","parentId":394},
	    {"id":4284,"value":"沐川县","parentId":394},
	    {"id":4285,"value":"沙湾区","parentId":394},
	    {"id":4286,"value":"犍为县","parentId":394},
	    {"id":4287,"value":"金口河区","parentId":394},
	    {"id":4288,"value":"马边彝族自治县","parentId":394},
	    {"id":4289,"value":"仪陇县","parentId":395},
	    {"id":4290,"value":"南充市嘉陵区","parentId":395},
	    {"id":4291,"value":"南部县","parentId":395},
	    {"id":4292,"value":"嘉陵区","parentId":395},
	    {"id":4293,"value":"营山县","parentId":395},
	    {"id":4294,"value":"蓬安县","parentId":395},
	    {"id":4295,"value":"西充县","parentId":395},
	    {"id":4296,"value":"阆中市","parentId":395},
	    {"id":4297,"value":"顺庆区","parentId":395},
	    {"id":4298,"value":"高坪区","parentId":395},
	    {"id":4299,"value":"东坡区","parentId":396},
	    {"id":4300,"value":"丹棱县","parentId":396},
	    {"id":4301,"value":"仁寿县","parentId":396},
	    {"id":4302,"value":"彭山县","parentId":396},
	    {"id":4303,"value":"洪雅县","parentId":396},
	    {"id":4304,"value":"青神县","parentId":396},
	    {"id":4305,"value":"兴文县","parentId":397},
	    {"id":4306,"value":"南溪县","parentId":397},
	    {"id":4307,"value":"宜宾县","parentId":397},
	    {"id":4308,"value":"屏山县","parentId":397},
	    {"id":4309,"value":"江安县","parentId":397},
	    {"id":4310,"value":"珙县","parentId":397},
	    {"id":4311,"value":"筠连县","parentId":397},
	    {"id":4312,"value":"翠屏区","parentId":397},
	    {"id":4313,"value":"长宁县","parentId":397},
	    {"id":4314,"value":"高县","parentId":397},
	    {"id":4315,"value":"华蓥市","parentId":398},
	    {"id":4316,"value":"岳池县","parentId":398},
	    {"id":4317,"value":"广安区","parentId":398},
	    {"id":4318,"value":"武胜县","parentId":398},
	    {"id":4319,"value":"邻水县","parentId":398},
	    {"id":4320,"value":"万源市","parentId":399},
	    {"id":4321,"value":"大竹县","parentId":399},
	    {"id":4322,"value":"宣汉县","parentId":399},
	    {"id":4323,"value":"开江县","parentId":399},
	    {"id":4324,"value":"渠县","parentId":399},
	    {"id":4325,"value":"达县","parentId":399},
	    {"id":4326,"value":"通川区","parentId":399},
	    {"id":4327,"value":"名山县","parentId":400},
	    {"id":4328,"value":"天全县","parentId":400},
	    {"id":4329,"value":"宝兴县","parentId":400},
	    {"id":4330,"value":"汉源县","parentId":400},
	    {"id":4331,"value":"石棉县","parentId":400},
	    {"id":4332,"value":"芦山县","parentId":400},
	    {"id":4333,"value":"荥经县","parentId":400},
	    {"id":4334,"value":"雨城区","parentId":400},
	    {"id":4335,"value":"南江县","parentId":401},
	    {"id":4336,"value":"巴州区","parentId":401},
	    {"id":4337,"value":"平昌县","parentId":401},
	    {"id":4338,"value":"通江县","parentId":401},
	    {"id":4339,"value":"乐至县","parentId":402},
	    {"id":4340,"value":"安岳县","parentId":402},
	    {"id":4341,"value":"简阳市","parentId":402},
	    {"id":4342,"value":"雁江区","parentId":402},
	    {"id":4343,"value":"九寨沟县","parentId":403},
	    {"id":4344,"value":"壤塘县","parentId":403},
	    {"id":4345,"value":"小金县","parentId":403},
	    {"id":4346,"value":"松潘县","parentId":403},
	    {"id":4347,"value":"汶川县","parentId":403},
	    {"id":4348,"value":"理县","parentId":403},
	    {"id":4349,"value":"红原县","parentId":403},
	    {"id":4350,"value":"若尔盖县","parentId":403},
	    {"id":4351,"value":"茂县","parentId":403},
	    {"id":4352,"value":"金川县","parentId":403},
	    {"id":4353,"value":"阿坝县","parentId":403},
	    {"id":4354,"value":"马尔康县","parentId":403},
	    {"id":4355,"value":"黑水县","parentId":403},
	    {"id":4356,"value":"丹巴县","parentId":404},
	    {"id":4357,"value":"乡城县","parentId":404},
	    {"id":4358,"value":"巴塘县","parentId":404},
	    {"id":4359,"value":"康定县","parentId":404},
	    {"id":4360,"value":"得荣县","parentId":404},
	    {"id":4361,"value":"德格县","parentId":404},
	    {"id":4362,"value":"新龙县","parentId":404},
	    {"id":4363,"value":"泸定县","parentId":404},
	    {"id":4364,"value":"炉霍县","parentId":404},
	    {"id":4365,"value":"理塘县","parentId":404},
	    {"id":4366,"value":"甘孜县","parentId":404},
	    {"id":4367,"value":"白玉县","parentId":404},
	    {"id":4368,"value":"石渠县","parentId":404},
	    {"id":4369,"value":"稻城县","parentId":404},
	    {"id":4370,"value":"色达县","parentId":404},
	    {"id":4371,"value":"道孚县","parentId":404},
	    {"id":4372,"value":"雅江县","parentId":404},
	    {"id":4373,"value":"会东县","parentId":405},
	    {"id":4374,"value":"会理县","parentId":405},
	    {"id":4375,"value":"冕宁县","parentId":405},
	    {"id":4376,"value":"喜德县","parentId":405},
	    {"id":4377,"value":"宁南县","parentId":405},
	    {"id":4378,"value":"布拖县","parentId":405},
	    {"id":4379,"value":"德昌县","parentId":405},
	    {"id":4380,"value":"昭觉县","parentId":405},
	    {"id":4381,"value":"普格县","parentId":405},
	    {"id":4382,"value":"木里藏族自治县","parentId":405},
	    {"id":4383,"value":"甘洛县","parentId":405},
	    {"id":4384,"value":"盐源县","parentId":405},
	    {"id":4385,"value":"美姑县","parentId":405},
	    {"id":4386,"value":"西昌","parentId":405},
	    {"id":4387,"value":"越西县","parentId":405},
	    {"id":4388,"value":"金阳县","parentId":405},
	    {"id":4389,"value":"雷波县","parentId":405},
	    {"id":4390,"value":"乌当区","parentId":406},
	    {"id":4391,"value":"云岩区","parentId":406},
	    {"id":4392,"value":"修文县","parentId":406},
	    {"id":4393,"value":"南明区","parentId":406},
	    {"id":4394,"value":"小河区","parentId":406},
	    {"id":4395,"value":"开阳县","parentId":406},
	    {"id":4396,"value":"息烽县","parentId":406},
	    {"id":4397,"value":"清镇市","parentId":406},
	    {"id":4398,"value":"白云区","parentId":406},
	    {"id":4399,"value":"花溪区","parentId":406},
	    {"id":4400,"value":"六枝特区","parentId":407},
	    {"id":4401,"value":"水城县","parentId":407},
	    {"id":4402,"value":"盘县","parentId":407},
	    {"id":4403,"value":"钟山区","parentId":407},
	    {"id":4404,"value":"习水县","parentId":408},
	    {"id":4405,"value":"仁怀市","parentId":408},
	    {"id":4406,"value":"余庆县","parentId":408},
	    {"id":4407,"value":"凤冈县","parentId":408},
	    {"id":4408,"value":"务川仡佬族苗族自治县","parentId":408},
	    {"id":4409,"value":"桐梓县","parentId":408},
	    {"id":4410,"value":"正安县","parentId":408},
	    {"id":4411,"value":"汇川区","parentId":408},
	    {"id":4412,"value":"湄潭县","parentId":408},
	    {"id":4413,"value":"红花岗区","parentId":408},
	    {"id":4414,"value":"绥阳县","parentId":408},
	    {"id":4415,"value":"赤水市","parentId":408},
	    {"id":4416,"value":"道真仡佬族苗族自治县","parentId":408},
	    {"id":4417,"value":"遵义县","parentId":408},
	    {"id":4418,"value":"关岭布依族苗族自治县","parentId":409},
	    {"id":4419,"value":"平坝县","parentId":409},
	    {"id":4420,"value":"普定县","parentId":409},
	    {"id":4421,"value":"紫云苗族布依族自治县","parentId":409},
	    {"id":4422,"value":"西秀区","parentId":409},
	    {"id":4423,"value":"镇宁布依族苗族自治县","parentId":409},
	    {"id":4424,"value":"万山特区","parentId":410},
	    {"id":4425,"value":"印江土家族苗族自治县","parentId":410},
	    {"id":4426,"value":"德江县","parentId":410},
	    {"id":4427,"value":"思南县","parentId":410},
	    {"id":4428,"value":"松桃苗族自治县","parentId":410},
	    {"id":4429,"value":"江口县","parentId":410},
	    {"id":4430,"value":"沿河土家族自治县","parentId":410},
	    {"id":4431,"value":"玉屏侗族自治县","parentId":410},
	    {"id":4432,"value":"石阡县","parentId":410},
	    {"id":4433,"value":"铜仁市","parentId":410},
	    {"id":4434,"value":"兴义市","parentId":411},
	    {"id":4435,"value":"兴仁县","parentId":411},
	    {"id":4436,"value":"册亨县","parentId":411},
	    {"id":4437,"value":"安龙县","parentId":411},
	    {"id":4438,"value":"普安县","parentId":411},
	    {"id":4439,"value":"晴隆县","parentId":411},
	    {"id":4440,"value":"望谟县","parentId":411},
	    {"id":4441,"value":"贞丰县","parentId":411},
	    {"id":4442,"value":"大方县","parentId":412},
	    {"id":4443,"value":"威宁彝族回族苗族自治县","parentId":412},
	    {"id":4444,"value":"毕节市","parentId":412},
	    {"id":4445,"value":"纳雍县","parentId":412},
	    {"id":4446,"value":"织金县","parentId":412},
	    {"id":4447,"value":"赫章县","parentId":412},
	    {"id":4448,"value":"金沙县","parentId":412},
	    {"id":4449,"value":"黔西县","parentId":412},
	    {"id":4450,"value":"三穗县","parentId":413},
	    {"id":4451,"value":"丹寨县","parentId":413},
	    {"id":4452,"value":"从江县","parentId":413},
	    {"id":4453,"value":"凯里市","parentId":413},
	    {"id":4454,"value":"剑河县","parentId":413},
	    {"id":4455,"value":"台江县","parentId":413},
	    {"id":4456,"value":"天柱县","parentId":413},
	    {"id":4457,"value":"岑巩县","parentId":413},
	    {"id":4458,"value":"施秉县","parentId":413},
	    {"id":4459,"value":"榕江县","parentId":413},
	    {"id":4460,"value":"锦屏县","parentId":413},
	    {"id":4461,"value":"镇远县","parentId":413},
	    {"id":4462,"value":"雷山县","parentId":413},
	    {"id":4463,"value":"麻江县","parentId":413},
	    {"id":4464,"value":"黄平县","parentId":413},
	    {"id":4465,"value":"黎平县","parentId":413},
	    {"id":4466,"value":"三都水族自治县","parentId":414},
	    {"id":4467,"value":"平塘县","parentId":414},
	    {"id":4468,"value":"惠水县","parentId":414},
	    {"id":4469,"value":"独山县","parentId":414},
	    {"id":4470,"value":"瓮安县","parentId":414},
	    {"id":4471,"value":"福泉市","parentId":414},
	    {"id":4472,"value":"罗甸县","parentId":414},
	    {"id":4473,"value":"荔波县","parentId":414},
	    {"id":4474,"value":"贵定县","parentId":414},
	    {"id":4475,"value":"都匀市","parentId":414},
	    {"id":4476,"value":"长顺县","parentId":414},
	    {"id":4477,"value":"龙里县","parentId":414},
	    {"id":4478,"value":"东川区","parentId":415},
	    {"id":4479,"value":"五华区","parentId":415},
	    {"id":4480,"value":"呈贡县","parentId":415},
	    {"id":4481,"value":"安宁市","parentId":415},
	    {"id":4482,"value":"官渡区","parentId":415},
	    {"id":4483,"value":"宜良县","parentId":415},
	    {"id":4484,"value":"富民县","parentId":415},
	    {"id":4485,"value":"寻甸回族彝族自治县","parentId":415},
	    {"id":4486,"value":"嵩明县","parentId":415},
	    {"id":4487,"value":"晋宁县","parentId":415},
	    {"id":4488,"value":"盘龙区","parentId":415},
	    {"id":4489,"value":"石林彝族自治县","parentId":415},
	    {"id":4490,"value":"禄劝彝族苗族自治县","parentId":415},
	    {"id":4491,"value":"西山区","parentId":415},
	    {"id":4492,"value":"会泽县","parentId":416},
	    {"id":4493,"value":"宣威市","parentId":416},
	    {"id":4494,"value":"富源县","parentId":416},
	    {"id":4495,"value":"师宗县","parentId":416},
	    {"id":4496,"value":"沾益县","parentId":416},
	    {"id":4497,"value":"罗平县","parentId":416},
	    {"id":4498,"value":"陆良县","parentId":416},
	    {"id":4499,"value":"马龙县","parentId":416},
	    {"id":4500,"value":"麒麟区","parentId":416},
	    {"id":4501,"value":"元江哈尼族彝族傣族自治县","parentId":417},
	    {"id":4502,"value":"华宁县","parentId":417},
	    {"id":4503,"value":"峨山彝族自治县","parentId":417},
	    {"id":4504,"value":"新平彝族傣族自治县","parentId":417},
	    {"id":4505,"value":"易门县","parentId":417},
	    {"id":4506,"value":"江川县","parentId":417},
	    {"id":4507,"value":"澄江县","parentId":417},
	    {"id":4508,"value":"红塔区","parentId":417},
	    {"id":4509,"value":"通海县","parentId":417},
	    {"id":4510,"value":"施甸县","parentId":418},
	    {"id":4511,"value":"昌宁县","parentId":418},
	    {"id":4512,"value":"腾冲县","parentId":418},
	    {"id":4513,"value":"隆阳区","parentId":418},
	    {"id":4514,"value":"龙陵县","parentId":418},
	    {"id":4515,"value":"大关县","parentId":419},
	    {"id":4516,"value":"威信县","parentId":419},
	    {"id":4517,"value":"巧家县","parentId":419},
	    {"id":4518,"value":"彝良县","parentId":419},
	    {"id":4519,"value":"昭阳区","parentId":419},
	    {"id":4520,"value":"水富县","parentId":419},
	    {"id":4521,"value":"永善县","parentId":419},
	    {"id":4522,"value":"盐津县","parentId":419},
	    {"id":4523,"value":"绥江县","parentId":419},
	    {"id":4524,"value":"镇雄县","parentId":419},
	    {"id":4525,"value":"鲁甸县","parentId":419},
	    {"id":4526,"value":"华坪县","parentId":420},
	    {"id":4527,"value":"古城区","parentId":420},
	    {"id":4528,"value":"宁蒗彝族自治县","parentId":420},
	    {"id":4529,"value":"永胜县","parentId":420},
	    {"id":4530,"value":"玉龙纳西族自治县","parentId":420},
	    {"id":4531,"value":"临翔区","parentId":422},
	    {"id":4532,"value":"云县","parentId":422},
	    {"id":4533,"value":"凤庆县","parentId":422},
	    {"id":4534,"value":"双江拉祜族佤族布朗族傣族自治县","parentId":422},
	    {"id":4535,"value":"永德县","parentId":422},
	    {"id":4536,"value":"沧源佤族自治县","parentId":422},
	    {"id":4537,"value":"耿马傣族佤族自治县","parentId":422},
	    {"id":4538,"value":"镇康县","parentId":422},
	    {"id":4539,"value":"元谋县","parentId":423},
	    {"id":4540,"value":"南华县","parentId":423},
	    {"id":4541,"value":"双柏县","parentId":423},
	    {"id":4542,"value":"大姚县","parentId":423},
	    {"id":4543,"value":"姚安县","parentId":423},
	    {"id":4544,"value":"楚雄市","parentId":423},
	    {"id":4545,"value":"武定县","parentId":423},
	    {"id":4546,"value":"永仁县","parentId":423},
	    {"id":4547,"value":"牟定县","parentId":423},
	    {"id":4548,"value":"禄丰县","parentId":423},
	    {"id":4549,"value":"个旧市","parentId":424},
	    {"id":4550,"value":"元阳县","parentId":424},
	    {"id":4551,"value":"屏边苗族自治县","parentId":424},
	    {"id":4552,"value":"建水县","parentId":424},
	    {"id":4553,"value":"开远市","parentId":424},
	    {"id":4554,"value":"弥勒县","parentId":424},
	    {"id":4555,"value":"河口瑶族自治县","parentId":424},
	    {"id":4556,"value":"泸西县","parentId":424},
	    {"id":4557,"value":"石屏县","parentId":424},
	    {"id":4558,"value":"红河县","parentId":424},
	    {"id":4559,"value":"绿春县","parentId":424},
	    {"id":4560,"value":"蒙自县","parentId":424},
	    {"id":4561,"value":"金平苗族瑶族傣族自治县","parentId":424},
	    {"id":4562,"value":"丘北县","parentId":425},
	    {"id":4563,"value":"富宁县","parentId":425},
	    {"id":4564,"value":"广南县","parentId":425},
	    {"id":4565,"value":"文山县","parentId":425},
	    {"id":4566,"value":"砚山县","parentId":425},
	    {"id":4567,"value":"西畴县","parentId":425},
	    {"id":4568,"value":"马关县","parentId":425},
	    {"id":4569,"value":"麻栗坡县","parentId":425},
	    {"id":4570,"value":"勐海县","parentId":426},
	    {"id":4571,"value":"勐腊县","parentId":426},
	    {"id":4572,"value":"景洪市","parentId":426},
	    {"id":4573,"value":"云龙县","parentId":427},
	    {"id":4574,"value":"剑川县","parentId":427},
	    {"id":4575,"value":"南涧彝族自治县","parentId":427},
	    {"id":4576,"value":"大理市","parentId":427},
	    {"id":4577,"value":"宾川县","parentId":427},
	    {"id":4578,"value":"巍山彝族回族自治县","parentId":427},
	    {"id":4579,"value":"弥渡县","parentId":427},
	    {"id":4580,"value":"永平县","parentId":427},
	    {"id":4581,"value":"洱源县","parentId":427},
	    {"id":4582,"value":"漾濞彝族自治县","parentId":427},
	    {"id":4583,"value":"祥云县","parentId":427},
	    {"id":4584,"value":"鹤庆县","parentId":427},
	    {"id":4585,"value":"梁河县","parentId":428},
	    {"id":4586,"value":"潞西市","parentId":428},
	    {"id":4587,"value":"瑞丽市","parentId":428},
	    {"id":4588,"value":"盈江县","parentId":428},
	    {"id":4589,"value":"陇川县","parentId":428},
	    {"id":4590,"value":"德钦县","parentId":430},
	    {"id":4591,"value":"维西傈僳族自治县","parentId":430},
	    {"id":4592,"value":"香格里拉县","parentId":430},
	    {"id":4593,"value":"城关区","parentId":431},
	    {"id":4594,"value":"堆龙德庆县","parentId":431},
	    {"id":4595,"value":"墨竹工卡县","parentId":431},
	    {"id":4596,"value":"尼木县","parentId":431},
	    {"id":4597,"value":"当雄县","parentId":431},
	    {"id":4598,"value":"曲水县","parentId":431},
	    {"id":4599,"value":"林周县","parentId":431},
	    {"id":4600,"value":"达孜县","parentId":431},
	    {"id":4601,"value":"丁青县","parentId":432},
	    {"id":4602,"value":"八宿县","parentId":432},
	    {"id":4603,"value":"察雅县","parentId":432},
	    {"id":4604,"value":"左贡县","parentId":432},
	    {"id":4605,"value":"昌都县","parentId":432},
	    {"id":4606,"value":"江达县","parentId":432},
	    {"id":4607,"value":"洛隆县","parentId":432},
	    {"id":4608,"value":"类乌齐县","parentId":432},
	    {"id":4609,"value":"芒康县","parentId":432},
	    {"id":4610,"value":"贡觉县","parentId":432},
	    {"id":4611,"value":"边坝县","parentId":432},
	    {"id":4612,"value":"乃东县","parentId":433},
	    {"id":4613,"value":"加查县","parentId":433},
	    {"id":4614,"value":"扎囊县","parentId":433},
	    {"id":4615,"value":"措美县","parentId":433},
	    {"id":4616,"value":"曲松县","parentId":433},
	    {"id":4617,"value":"桑日县","parentId":433},
	    {"id":4618,"value":"洛扎县","parentId":433},
	    {"id":4619,"value":"浪卡子县","parentId":433},
	    {"id":4620,"value":"琼结县","parentId":433},
	    {"id":4621,"value":"贡嘎县","parentId":433},
	    {"id":4622,"value":"错那县","parentId":433},
	    {"id":4623,"value":"隆子县","parentId":433},
	    {"id":4624,"value":"亚东县","parentId":434},
	    {"id":4625,"value":"仁布县","parentId":434},
	    {"id":4626,"value":"仲巴县","parentId":434},
	    {"id":4627,"value":"南木林县","parentId":434},
	    {"id":4628,"value":"吉隆县","parentId":434},
	    {"id":4629,"value":"定日县","parentId":434},
	    {"id":4630,"value":"定结县","parentId":434},
	    {"id":4631,"value":"岗巴县","parentId":434},
	    {"id":4632,"value":"康马县","parentId":434},
	    {"id":4633,"value":"拉孜县","parentId":434},
	    {"id":4634,"value":"日喀则市","parentId":434},
	    {"id":4635,"value":"昂仁县","parentId":434},
	    {"id":4636,"value":"江孜县","parentId":434},
	    {"id":4637,"value":"白朗县","parentId":434},
	    {"id":4638,"value":"聂拉木县","parentId":434},
	    {"id":4639,"value":"萨嘎县","parentId":434},
	    {"id":4640,"value":"萨迦县","parentId":434},
	    {"id":4641,"value":"谢通门县","parentId":434},
	    {"id":4642,"value":"嘉黎县","parentId":435},
	    {"id":4643,"value":"安多县","parentId":435},
	    {"id":4644,"value":"尼玛县","parentId":435},
	    {"id":4645,"value":"巴青县","parentId":435},
	    {"id":4646,"value":"比如县","parentId":435},
	    {"id":4647,"value":"班戈县","parentId":435},
	    {"id":4648,"value":"申扎县","parentId":435},
	    {"id":4649,"value":"索县","parentId":435},
	    {"id":4650,"value":"聂荣县","parentId":435},
	    {"id":4651,"value":"那曲县","parentId":435},
	    {"id":4652,"value":"噶尔县","parentId":436},
	    {"id":4653,"value":"措勤县","parentId":436},
	    {"id":4654,"value":"改则县","parentId":436},
	    {"id":4655,"value":"日土县","parentId":436},
	    {"id":4656,"value":"普兰县","parentId":436},
	    {"id":4657,"value":"札达县","parentId":436},
	    {"id":4658,"value":"革吉县","parentId":436},
	    {"id":4659,"value":"墨脱县","parentId":437},
	    {"id":4660,"value":"察隅县","parentId":437},
	    {"id":4661,"value":"工布江达县","parentId":437},
	    {"id":4662,"value":"朗县","parentId":437},
	    {"id":4663,"value":"林芝县","parentId":437},
	    {"id":4664,"value":"波密县","parentId":437},
	    {"id":4665,"value":"米林县","parentId":437},
	    {"id":4666,"value":"临潼区","parentId":438},
	    {"id":4667,"value":"周至县","parentId":438},
	    {"id":4668,"value":"户县","parentId":438},
	    {"id":4669,"value":"新城区","parentId":438},
	    {"id":4670,"value":"未央区","parentId":438},
	    {"id":4671,"value":"灞桥区","parentId":438},
	    {"id":4672,"value":"碑林区","parentId":438},
	    {"id":4673,"value":"莲湖区","parentId":438},
	    {"id":4674,"value":"蓝田县","parentId":438},
	    {"id":4675,"value":"长安区","parentId":438},
	    {"id":4676,"value":"阎良区","parentId":438},
	    {"id":4677,"value":"雁塔区","parentId":438},
	    {"id":4678,"value":"高陵县","parentId":438},
	    {"id":4679,"value":"印台区","parentId":439},
	    {"id":4680,"value":"宜君县","parentId":439},
	    {"id":4681,"value":"王益区","parentId":439},
	    {"id":4682,"value":"耀州区","parentId":439},
	    {"id":4683,"value":"凤县","parentId":440},
	    {"id":4684,"value":"凤翔县","parentId":440},
	    {"id":4685,"value":"千阳县","parentId":440},
	    {"id":4686,"value":"太白县","parentId":440},
	    {"id":4687,"value":"岐山县","parentId":440},
	    {"id":4688,"value":"扶风县","parentId":440},
	    {"id":4689,"value":"渭滨区","parentId":440},
	    {"id":4690,"value":"眉县","parentId":440},
	    {"id":4691,"value":"金台区","parentId":440},
	    {"id":4692,"value":"陇县","parentId":440},
	    {"id":4693,"value":"陈仓区","parentId":440},
	    {"id":4694,"value":"麟游县","parentId":440},
	    {"id":4695,"value":"三原县","parentId":441},
	    {"id":4696,"value":"干县","parentId":441},
	    {"id":4697,"value":"兴平市","parentId":441},
	    {"id":4698,"value":"彬县","parentId":441},
	    {"id":4699,"value":"旬邑县","parentId":441},
	    {"id":4700,"value":"杨陵区","parentId":441},
	    {"id":4701,"value":"武功县","parentId":441},
	    {"id":4702,"value":"永寿县","parentId":441},
	    {"id":4703,"value":"泾阳县","parentId":441},
	    {"id":4704,"value":"淳化县","parentId":441},
	    {"id":4705,"value":"渭城区","parentId":441},
	    {"id":4706,"value":"礼泉县","parentId":441},
	    {"id":4707,"value":"秦都区","parentId":441},
	    {"id":4708,"value":"长武县","parentId":441},
	    {"id":4709,"value":"临渭区","parentId":442},
	    {"id":4710,"value":"华县","parentId":442},
	    {"id":4711,"value":"华阴市","parentId":442},
	    {"id":4712,"value":"合阳县","parentId":442},
	    {"id":4713,"value":"大荔县","parentId":442},
	    {"id":4714,"value":"富平县","parentId":442},
	    {"id":4715,"value":"潼关县","parentId":442},
	    {"id":4716,"value":"澄城县","parentId":442},
	    {"id":4717,"value":"白水县","parentId":442},
	    {"id":4718,"value":"蒲城县","parentId":442},
	    {"id":4719,"value":"韩城市","parentId":442},
	    {"id":4720,"value":"吴起县","parentId":443},
	    {"id":4721,"value":"子长县","parentId":443},
	    {"id":4722,"value":"安塞县","parentId":443},
	    {"id":4723,"value":"宜川县","parentId":443},
	    {"id":4724,"value":"宝塔区","parentId":443},
	    {"id":4725,"value":"富县","parentId":443},
	    {"id":4726,"value":"延川县","parentId":443},
	    {"id":4727,"value":"延长县","parentId":443},
	    {"id":4728,"value":"志丹县","parentId":443},
	    {"id":4729,"value":"洛川县","parentId":443},
	    {"id":4730,"value":"甘泉县","parentId":443},
	    {"id":4731,"value":"黄陵县","parentId":443},
	    {"id":4732,"value":"黄龙县","parentId":443},
	    {"id":4733,"value":"佛坪县","parentId":444},
	    {"id":4734,"value":"勉县","parentId":444},
	    {"id":4735,"value":"南郑县","parentId":444},
	    {"id":4736,"value":"城固县","parentId":444},
	    {"id":4737,"value":"宁强县","parentId":444},
	    {"id":4738,"value":"汉台区","parentId":444},
	    {"id":4739,"value":"洋县","parentId":444},
	    {"id":4740,"value":"留坝县","parentId":444},
	    {"id":4741,"value":"略阳县","parentId":444},
	    {"id":4742,"value":"西乡县","parentId":444},
	    {"id":4743,"value":"镇巴县","parentId":444},
	    {"id":4744,"value":"佳县","parentId":445},
	    {"id":4745,"value":"吴堡县","parentId":445},
	    {"id":4746,"value":"子洲县","parentId":445},
	    {"id":4747,"value":"定边县","parentId":445},
	    {"id":4748,"value":"府谷县","parentId":445},
	    {"id":4749,"value":"榆林市榆阳区","parentId":445},
	    {"id":4750,"value":"横山县","parentId":445},
	    {"id":4751,"value":"清涧县","parentId":445},
	    {"id":4752,"value":"神木县","parentId":445},
	    {"id":4753,"value":"米脂县","parentId":445},
	    {"id":4754,"value":"绥德县","parentId":445},
	    {"id":4755,"value":"靖边县","parentId":445},
	    {"id":4756,"value":"宁陕县","parentId":446},
	    {"id":4757,"value":"岚皋县","parentId":446},
	    {"id":4758,"value":"平利县","parentId":446},
	    {"id":4759,"value":"旬阳县","parentId":446},
	    {"id":4760,"value":"汉滨区","parentId":446},
	    {"id":4761,"value":"汉阴县","parentId":446},
	    {"id":4762,"value":"白河县","parentId":446},
	    {"id":4763,"value":"石泉县","parentId":446},
	    {"id":4764,"value":"紫阳县","parentId":446},
	    {"id":4765,"value":"镇坪县","parentId":446},
	    {"id":4766,"value":"丹凤县","parentId":447},
	    {"id":4767,"value":"商南县","parentId":447},
	    {"id":4768,"value":"商州区","parentId":447},
	    {"id":4769,"value":"山阳县","parentId":447},
	    {"id":4770,"value":"柞水县","parentId":447},
	    {"id":4771,"value":"洛南县","parentId":447},
	    {"id":4772,"value":"镇安县","parentId":447},
	    {"id":4773,"value":"七里河区","parentId":448},
	    {"id":4774,"value":"城关区","parentId":448},
	    {"id":4775,"value":"安宁区","parentId":448},
	    {"id":4776,"value":"榆中县","parentId":448},
	    {"id":4777,"value":"永登县","parentId":448},
	    {"id":4778,"value":"皋兰县","parentId":448},
	    {"id":4779,"value":"红古区","parentId":448},
	    {"id":4780,"value":"西固区","parentId":448},
	    {"id":4781,"value":"嘉峪关市","parentId":449},
	    {"id":4782,"value":"永昌县","parentId":450},
	    {"id":4783,"value":"金川区","parentId":450},
	    {"id":4784,"value":"会宁县","parentId":451},
	    {"id":4785,"value":"平川区","parentId":451},
	    {"id":4786,"value":"景泰县","parentId":451},
	    {"id":4787,"value":"白银区","parentId":451},
	    {"id":4788,"value":"靖远县","parentId":451},
	    {"id":4789,"value":"张家川回族自治县","parentId":452},
	    {"id":4790,"value":"武山县","parentId":452},
	    {"id":4791,"value":"清水县","parentId":452},
	    {"id":4792,"value":"甘谷县","parentId":452},
	    {"id":4793,"value":"秦安县","parentId":452},
	    {"id":4794,"value":"秦州区","parentId":452},
	    {"id":4795,"value":"麦积区","parentId":452},
	    {"id":4796,"value":"凉州区","parentId":453},
	    {"id":4797,"value":"古浪县","parentId":453},
	    {"id":4798,"value":"天祝藏族自治县","parentId":453},
	    {"id":4799,"value":"民勤县","parentId":453},
	    {"id":4800,"value":"临泽县","parentId":454},
	    {"id":4801,"value":"山丹县","parentId":454},
	    {"id":4802,"value":"民乐县","parentId":454},
	    {"id":4803,"value":"甘州区","parentId":454},
	    {"id":4804,"value":"肃南裕固族自治县","parentId":454},
	    {"id":4805,"value":"高台县","parentId":454},
	    {"id":4806,"value":"华亭县","parentId":455},
	    {"id":4807,"value":"崆峒区","parentId":455},
	    {"id":4808,"value":"崇信县","parentId":455},
	    {"id":4809,"value":"庄浪县","parentId":455},
	    {"id":4810,"value":"泾川县","parentId":455},
	    {"id":4811,"value":"灵台县","parentId":455},
	    {"id":4812,"value":"静宁县","parentId":455},
	    {"id":4813,"value":"敦煌市","parentId":456},
	    {"id":4814,"value":"玉门市","parentId":456},
	    {"id":4815,"value":"瓜州县（原安西县）","parentId":456},
	    {"id":4816,"value":"肃北蒙古族自治县","parentId":456},
	    {"id":4817,"value":"肃州区","parentId":456},
	    {"id":4818,"value":"金塔县","parentId":456},
	    {"id":4819,"value":"阿克塞哈萨克族自治县","parentId":456},
	    {"id":4820,"value":"华池县","parentId":457},
	    {"id":4821,"value":"合水县","parentId":457},
	    {"id":4822,"value":"宁县","parentId":457},
	    {"id":4823,"value":"庆城县","parentId":457},
	    {"id":4824,"value":"正宁县","parentId":457},
	    {"id":4825,"value":"环县","parentId":457},
	    {"id":4826,"value":"西峰区","parentId":457},
	    {"id":4827,"value":"镇原县","parentId":457},
	    {"id":4828,"value":"临洮县","parentId":458},
	    {"id":4829,"value":"安定区","parentId":458},
	    {"id":4830,"value":"岷县","parentId":458},
	    {"id":4831,"value":"渭源县","parentId":458},
	    {"id":4832,"value":"漳县","parentId":458},
	    {"id":4833,"value":"通渭县","parentId":458},
	    {"id":4834,"value":"陇西县","parentId":458},
	    {"id":4835,"value":"两当县","parentId":459},
	    {"id":4836,"value":"宕昌县","parentId":459},
	    {"id":4837,"value":"康县","parentId":459},
	    {"id":4838,"value":"徽县","parentId":459},
	    {"id":4839,"value":"成县","parentId":459},
	    {"id":4840,"value":"文县","parentId":459},
	    {"id":4841,"value":"武都区","parentId":459},
	    {"id":4842,"value":"礼县","parentId":459},
	    {"id":4843,"value":"西和县","parentId":459},
	    {"id":4844,"value":"东乡族自治县","parentId":460},
	    {"id":4845,"value":"临夏县","parentId":460},
	    {"id":4846,"value":"临夏市","parentId":460},
	    {"id":4847,"value":"和政县","parentId":460},
	    {"id":4848,"value":"广河县","parentId":460},
	    {"id":4849,"value":"康乐县","parentId":460},
	    {"id":4850,"value":"永靖县","parentId":460},
	    {"id":4851,"value":"积石山保安族东乡族撒拉族自治县","parentId":460},
	    {"id":4852,"value":"临潭县","parentId":461},
	    {"id":4853,"value":"卓尼县","parentId":461},
	    {"id":4854,"value":"合作市","parentId":461},
	    {"id":4855,"value":"夏河县","parentId":461},
	    {"id":4856,"value":"玛曲县","parentId":461},
	    {"id":4857,"value":"碌曲县","parentId":461},
	    {"id":4858,"value":"舟曲县","parentId":461},
	    {"id":4859,"value":"迭部县","parentId":461},
	    {"id":4860,"value":"城东区","parentId":462},
	    {"id":4861,"value":"城中区","parentId":462},
	    {"id":4862,"value":"城北区","parentId":462},
	    {"id":4863,"value":"城西区","parentId":462},
	    {"id":4864,"value":"大通回族土族自治县","parentId":462},
	    {"id":4865,"value":"湟中县","parentId":462},
	    {"id":4866,"value":"湟源县","parentId":462},
	    {"id":4867,"value":"乐都县","parentId":463},
	    {"id":4868,"value":"互助土族自治县","parentId":463},
	    {"id":4869,"value":"化隆回族自治县","parentId":463},
	    {"id":4870,"value":"平安县","parentId":463},
	    {"id":4871,"value":"循化撒拉族自治县","parentId":463},
	    {"id":4872,"value":"民和回族土族自治县","parentId":463},
	    {"id":4873,"value":"刚察县","parentId":464},
	    {"id":4874,"value":"海晏县","parentId":464},
	    {"id":4875,"value":"祁连县","parentId":464},
	    {"id":4876,"value":"门源回族自治县","parentId":464},
	    {"id":4877,"value":"同仁县","parentId":465},
	    {"id":4878,"value":"尖扎县","parentId":465},
	    {"id":4879,"value":"河南蒙古族自治县","parentId":465},
	    {"id":4880,"value":"泽库县","parentId":465},
	    {"id":4881,"value":"共和县","parentId":466},
	    {"id":4882,"value":"兴海县","parentId":466},
	    {"id":4883,"value":"同德县","parentId":466},
	    {"id":4884,"value":"贵南县","parentId":466},
	    {"id":4885,"value":"贵德县","parentId":466},
	    {"id":4886,"value":"久治县","parentId":467},
	    {"id":4887,"value":"玛多县","parentId":467},
	    {"id":4888,"value":"玛沁县","parentId":467},
	    {"id":4889,"value":"班玛县","parentId":467},
	    {"id":4890,"value":"甘德县","parentId":467},
	    {"id":4891,"value":"达日县","parentId":467},
	    {"id":4892,"value":"囊谦县","parentId":468},
	    {"id":4893,"value":"曲麻莱县","parentId":468},
	    {"id":4894,"value":"杂多县","parentId":468},
	    {"id":4895,"value":"治多县","parentId":468},
	    {"id":4896,"value":"玉树县","parentId":468},
	    {"id":4897,"value":"称多县","parentId":468},
	    {"id":4898,"value":"乌兰县","parentId":469},
	    {"id":4899,"value":"冷湖行委","parentId":469},
	    {"id":4900,"value":"大柴旦行委","parentId":469},
	    {"id":4901,"value":"天峻县","parentId":469},
	    {"id":4902,"value":"德令哈市","parentId":469},
	    {"id":4903,"value":"格尔木市","parentId":469},
	    {"id":4904,"value":"茫崖行委","parentId":469},
	    {"id":4905,"value":"都兰县","parentId":469},
	    {"id":4906,"value":"兴庆区","parentId":470},
	    {"id":4907,"value":"永宁县","parentId":470},
	    {"id":4908,"value":"灵武市","parentId":470},
	    {"id":4909,"value":"西夏区","parentId":470},
	    {"id":4910,"value":"贺兰县","parentId":470},
	    {"id":4911,"value":"金凤区","parentId":470},
	    {"id":4912,"value":"大武口区","parentId":471},
	    {"id":4913,"value":"平罗县","parentId":471},
	    {"id":4914,"value":"惠农区","parentId":471},
	    {"id":4915,"value":"利通区","parentId":472},
	    {"id":4916,"value":"同心县","parentId":472},
	    {"id":4917,"value":"盐池县","parentId":472},
	    {"id":4918,"value":"青铜峡市","parentId":472},
	    {"id":4919,"value":"原州区","parentId":473},
	    {"id":4920,"value":"彭阳县","parentId":473},
	    {"id":4921,"value":"泾源县","parentId":473},
	    {"id":4922,"value":"西吉县","parentId":473},
	    {"id":4923,"value":"隆德县","parentId":473},
	    {"id":4924,"value":"中宁县","parentId":474},
	    {"id":4925,"value":"沙坡头区","parentId":474},
	    {"id":4926,"value":"海原县","parentId":474},
	    {"id":4927,"value":"东山区","parentId":475},
	    {"id":4928,"value":"乌鲁木齐县","parentId":475},
	    {"id":4929,"value":"天山区","parentId":475},
	    {"id":4930,"value":"头屯河区","parentId":475},
	    {"id":4931,"value":"新市区","parentId":475},
	    {"id":4932,"value":"水磨沟区","parentId":475},
	    {"id":4933,"value":"沙依巴克区","parentId":475},
	    {"id":4934,"value":"达坂城区","parentId":475},
	    {"id":4935,"value":"乌尔禾区","parentId":476},
	    {"id":4936,"value":"克拉玛依区","parentId":476},
	    {"id":4937,"value":"独山子区","parentId":476},
	    {"id":4938,"value":"白碱滩区","parentId":476},
	    {"id":4939,"value":"吐鲁番市","parentId":477},
	    {"id":4940,"value":"托克逊县","parentId":477},
	    {"id":4941,"value":"鄯善县","parentId":477},
	    {"id":4942,"value":"伊吾县","parentId":478},
	    {"id":4943,"value":"哈密市","parentId":478},
	    {"id":4944,"value":"巴里坤哈萨克自治县","parentId":478},
	    {"id":4945,"value":"吉木萨尔县","parentId":479},
	    {"id":4946,"value":"呼图壁县","parentId":479},
	    {"id":4947,"value":"奇台县","parentId":479},
	    {"id":4948,"value":"昌吉市","parentId":479},
	    {"id":4949,"value":"木垒哈萨克自治县","parentId":479},
	    {"id":4950,"value":"玛纳斯县","parentId":479},
	    {"id":4951,"value":"米泉市","parentId":479},
	    {"id":4952,"value":"阜康市","parentId":479},
	    {"id":4953,"value":"博乐市","parentId":480},
	    {"id":4954,"value":"温泉县","parentId":480},
	    {"id":4955,"value":"精河县","parentId":480},
	    {"id":4956,"value":"博湖县","parentId":481},
	    {"id":4957,"value":"和硕县","parentId":481},
	    {"id":4958,"value":"和静县","parentId":481},
	    {"id":4959,"value":"尉犁县","parentId":481},
	    {"id":4960,"value":"库尔勒市","parentId":481},
	    {"id":4961,"value":"焉耆回族自治县","parentId":481},
	    {"id":4962,"value":"若羌县","parentId":481},
	    {"id":4963,"value":"轮台县","parentId":481},
	    {"id":4964,"value":"乌什县","parentId":482},
	    {"id":4965,"value":"库车县","parentId":482},
	    {"id":4966,"value":"拜城县","parentId":482},
	    {"id":4967,"value":"新和县","parentId":482},
	    {"id":4968,"value":"柯坪县","parentId":482},
	    {"id":4969,"value":"沙雅县","parentId":482},
	    {"id":4970,"value":"温宿县","parentId":482},
	    {"id":4971,"value":"阿克苏市","parentId":482},
	    {"id":4972,"value":"阿瓦提县","parentId":482},
	    {"id":4973,"value":"乌恰县","parentId":483},
	    {"id":4974,"value":"阿克陶县","parentId":483},
	    {"id":4975,"value":"阿合奇县","parentId":483},
	    {"id":4976,"value":"阿图什市","parentId":483},
	    {"id":4977,"value":"伽师县","parentId":484},
	    {"id":4978,"value":"叶城县","parentId":484},
	    {"id":4979,"value":"喀什市","parentId":484},
	    {"id":4980,"value":"塔什库尔干塔吉克自治县","parentId":484},
	    {"id":4981,"value":"岳普湖县","parentId":484},
	    {"id":4982,"value":"巴楚县","parentId":484},
	    {"id":4983,"value":"泽普县","parentId":484},
	    {"id":4984,"value":"疏勒县","parentId":484},
	    {"id":4985,"value":"疏附县","parentId":484},
	    {"id":4986,"value":"英吉沙县","parentId":484},
	    {"id":4987,"value":"莎车县","parentId":484},
	    {"id":4988,"value":"麦盖提县","parentId":484},
	    {"id":4989,"value":"于田县","parentId":485},
	    {"id":4990,"value":"和田县","parentId":485},
	    {"id":4991,"value":"和田市","parentId":485},
	    {"id":4992,"value":"墨玉县","parentId":485},
	    {"id":4993,"value":"民丰县","parentId":485},
	    {"id":4994,"value":"洛浦县","parentId":485},
	    {"id":4995,"value":"皮山县","parentId":485},
	    {"id":4996,"value":"策勒县","parentId":485},
	    {"id":4997,"value":"伊宁县","parentId":486},
	    {"id":4998,"value":"伊宁市","parentId":486},
	    {"id":4999,"value":"奎屯市","parentId":486},
	    {"id":5000,"value":"察布查尔锡伯自治县","parentId":486},
	    {"id":5001,"value":"尼勒克县","parentId":486},
	    {"id":5002,"value":"巩留县","parentId":486},
	    {"id":5003,"value":"新源县","parentId":486},
	    {"id":5004,"value":"昭苏县","parentId":486},
	    {"id":5005,"value":"特克斯县","parentId":486},
	    {"id":5006,"value":"霍城县","parentId":486},
	    {"id":5007,"value":"乌苏市","parentId":487},
	    {"id":5008,"value":"和布克赛尔蒙古自治县","parentId":487},
	    {"id":5009,"value":"塔城市","parentId":487},
	    {"id":5010,"value":"托里县","parentId":487},
	    {"id":5011,"value":"沙湾县","parentId":487},
	    {"id":5012,"value":"裕民县","parentId":487},
	    {"id":5013,"value":"额敏县","parentId":487},
	    {"id":5014,"value":"吉木乃县","parentId":488},
	    {"id":5015,"value":"哈巴河县","parentId":488},
	    {"id":5016,"value":"富蕴县","parentId":488},
	    {"id":5017,"value":"布尔津县","parentId":488},
	    {"id":5018,"value":"福海县","parentId":488},
	    {"id":5019,"value":"阿勒泰市","parentId":488},
	    {"id":5020,"value":"青河县","parentId":488},
	    {"id":5021,"value":"石河子市","parentId":489},
	    {"id":5022,"value":"阿拉尔市","parentId":490},
	    {"id":5023,"value":"图木舒克市","parentId":491},
	    {"id":5024,"value":"五家渠市","parentId":492}
	]
	var areaObject = {
	    "p":iosProvinces,
	    "c":iosCitys,
	    "d":iosCountys
	}
	module.exports = areaObject;

/***/ },

/***/ 23:
/***/ function(module, exports, __webpack_require__) {

	var __WEBPACK_AMD_DEFINE_RESULT__;(function() {
		var IScroll = (function() {
			var rAF = window.requestAnimationFrame ||
				window.webkitRequestAnimationFrame ||
				window.mozRequestAnimationFrame ||
				window.oRequestAnimationFrame ||
				window.msRequestAnimationFrame ||
				function(callback) {
					window.setTimeout(callback, 1000 / 60);
				};

			var utils = (function() {
				var me = {};

				var _elementStyle = document.createElement('div').style;
				var _vendor = (function() {
					var vendors = ['t', 'webkitT', 'MozT', 'msT', 'OT'],
						transform,
						i = 0,
						l = vendors.length;

					for (; i < l; i++) {
						transform = vendors[i] + 'ransform';
						if (transform in _elementStyle) return vendors[i].substr(0, vendors[i].length - 1);
					}

					return false;
				})();

				function _prefixStyle(style) {
					if (_vendor === false) return false;
					if (_vendor === '') return style;
					return _vendor + style.charAt(0).toUpperCase() + style.substr(1);
				}

				me.getTime = Date.now || function getTime() {
					return new Date().getTime();
				};

				me.extend = function(target, obj) {
					for (var i in obj) {
						target[i] = obj[i];
					}
				};

				me.addEvent = function(el, type, fn, capture) {
					el.addEventListener(type, fn, !!capture);
				};

				me.removeEvent = function(el, type, fn, capture) {
					el.removeEventListener(type, fn, !!capture);
				};

				me.prefixPointerEvent = function(pointerEvent) {
					return window.MSPointerEvent ?
						'MSPointer' + pointerEvent.charAt(9).toUpperCase() + pointerEvent.substr(10) :
						pointerEvent;
				};

				me.momentum = function(current, start, time, lowerMargin, wrapperSize, deceleration) {
					var distance = current - start,
						speed = Math.abs(distance) / time,
						destination,
						duration;

					deceleration = deceleration === undefined ? 0.0006 : deceleration;

					destination = current + (speed * speed) / (2 * deceleration) * (distance < 0 ? -1 : 1);
					duration = speed / deceleration;

					if (destination < lowerMargin) {
						destination = wrapperSize ? lowerMargin - (wrapperSize / 2.5 * (speed / 8)) : lowerMargin;
						distance = Math.abs(destination - current);
						duration = distance / speed;
					} else if (destination > 0) {
						destination = wrapperSize ? wrapperSize / 2.5 * (speed / 8) : 0;
						distance = Math.abs(current) + destination;
						duration = distance / speed;
					}

					return {
						destination: Math.round(destination),
						duration: duration
					};
				};

				var _transform = _prefixStyle('transform');

				me.extend(me, {
					hasTransform: _transform !== false,
					hasPerspective: _prefixStyle('perspective') in _elementStyle,
					hasTouch: 'ontouchstart' in window,
					hasPointer: window.PointerEvent || window.MSPointerEvent, // IE10 is prefixed
					hasTransition: _prefixStyle('transition') in _elementStyle
				});

				// This should find all Android browsers lower than build 535.19 (both stock browser and webview)
				me.isBadAndroid = /Android /.test(window.navigator.appVersion) && !(/Chrome\/\d/.test(window.navigator.appVersion));

				me.extend(me.style = {}, {
					transform: _transform,
					transitionTimingFunction: _prefixStyle('transitionTimingFunction'),
					transitionDuration: _prefixStyle('transitionDuration'),
					transitionDelay: _prefixStyle('transitionDelay'),
					transformOrigin: _prefixStyle('transformOrigin')
				});

				me.hasClass = function(e, c) {
					var re = new RegExp("(^|\\s)" + c + "(\\s|$)");
					return re.test(e.className);
				};

				me.addClass = function(e, c) {
					if (me.hasClass(e, c)) {
						return;
					}

					var newclass = e.className.split(' ');
					newclass.push(c);
					e.className = newclass.join(' ');
				};

				me.removeClass = function(e, c) {
					if (!me.hasClass(e, c)) {
						return;
					}

					var re = new RegExp("(^|\\s)" + c + "(\\s|$)", 'g');
					e.className = e.className.replace(re, ' ');
				};

				me.offset = function(el) {
					var left = -el.offsetLeft,
						top = -el.offsetTop;

					// jshint -W084
					while (el = el.offsetParent) {
						left -= el.offsetLeft;
						top -= el.offsetTop;
					}
					// jshint +W084

					return {
						left: left,
						top: top
					};
				};

				me.preventDefaultException = function(el, exceptions) {
					for (var i in exceptions) {
						if (exceptions[i].test(el[i])) {
							return true;
						}
					}

					return false;
				};

				me.extend(me.eventType = {}, {
					touchstart: 1,
					touchmove: 1,
					touchend: 1,

					mousedown: 2,
					mousemove: 2,
					mouseup: 2,

					pointerdown: 3,
					pointermove: 3,
					pointerup: 3,

					MSPointerDown: 3,
					MSPointerMove: 3,
					MSPointerUp: 3
				});

				me.extend(me.ease = {}, {
					quadratic: {
						style: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
						fn: function(k) {
							return k * (2 - k);
						}
					},
					circular: {
						style: 'cubic-bezier(0.1, 0.57, 0.1, 1)', // Not properly "circular" but this looks better, it should be (0.075, 0.82, 0.165, 1)
						fn: function(k) {
							return Math.sqrt(1 - (--k * k));
						}
					},
					back: {
						style: 'cubic-bezier(0.175, 0.885, 0.32, 1.275)',
						fn: function(k) {
							var b = 4;
							return (k = k - 1) * k * ((b + 1) * k + b) + 1;
						}
					},
					bounce: {
						style: '',
						fn: function(k) {
							if ((k /= 1) < (1 / 2.75)) {
								return 7.5625 * k * k;
							} else if (k < (2 / 2.75)) {
								return 7.5625 * (k -= (1.5 / 2.75)) * k + 0.75;
							} else if (k < (2.5 / 2.75)) {
								return 7.5625 * (k -= (2.25 / 2.75)) * k + 0.9375;
							} else {
								return 7.5625 * (k -= (2.625 / 2.75)) * k + 0.984375;
							}
						}
					},
					elastic: {
						style: '',
						fn: function(k) {
							var f = 0.22,
								e = 0.4;

							if (k === 0) {
								return 0;
							}
							if (k == 1) {
								return 1;
							}

							return (e * Math.pow(2, -10 * k) * Math.sin((k - f / 4) * (2 * Math.PI) / f) + 1);
						}
					}
				});

				me.tap = function(e, eventName) {
					var ev = document.createEvent('Event');
					ev.initEvent(eventName, true, true);
					ev.pageX = e.pageX;
					ev.pageY = e.pageY;
					e.target.dispatchEvent(ev);
				};

				me.click = function(e) {
					var target = e.target,
						ev;

					if (!(/(SELECT|INPUT|TEXTAREA)/i).test(target.tagName)) {
						ev = document.createEvent('MouseEvents');
						ev.initMouseEvent('click', true, true, e.view, 1,
							target.screenX, target.screenY, target.clientX, target.clientY,
							e.ctrlKey, e.altKey, e.shiftKey, e.metaKey,
							0, null);

						ev._constructed = true;
						target.dispatchEvent(ev);
					}
				};

				return me;
			})();

			function IScroll(el, options) {
				this.wrapper = typeof el == 'string' ? document.querySelector(el) : el;
				this.scroller = this.wrapper.children[0];
				this.scrollerStyle = this.scroller.style; // cache style for better performance

				this.options = {

					resizeScrollbars: true,

					mouseWheelSpeed: 20,

					snapThreshold: 0.334,

					// INSERT POINT: OPTIONS 

					startX: 0,
					startY: 0,
					scrollY: true,
					directionLockThreshold: 5,
					momentum: true,

					bounce: true,
					bounceTime: 600,
					bounceEasing: '',

					preventDefault: true,
					preventDefaultException: {
						tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT)$/
					},

					HWCompositing: true,
					useTransition: true,
					useTransform: true
				};

				for (var i in options) {
					this.options[i] = options[i];
				}

				// Normalize options
				this.translateZ = this.options.HWCompositing && utils.hasPerspective ? ' translateZ(0)' : '';

				this.options.useTransition = utils.hasTransition && this.options.useTransition;
				this.options.useTransform = utils.hasTransform && this.options.useTransform;

				this.options.eventPassthrough = this.options.eventPassthrough === true ? 'vertical' : this.options.eventPassthrough;
				this.options.preventDefault = !this.options.eventPassthrough && this.options.preventDefault;

				// If you want eventPassthrough I have to lock one of the axes
				this.options.scrollY = this.options.eventPassthrough == 'vertical' ? false : this.options.scrollY;
				this.options.scrollX = this.options.eventPassthrough == 'horizontal' ? false : this.options.scrollX;

				// With eventPassthrough we also need lockDirection mechanism
				this.options.freeScroll = this.options.freeScroll && !this.options.eventPassthrough;
				this.options.directionLockThreshold = this.options.eventPassthrough ? 0 : this.options.directionLockThreshold;

				this.options.bounceEasing = typeof this.options.bounceEasing == 'string' ? utils.ease[this.options.bounceEasing] || utils.ease.circular : this.options.bounceEasing;

				this.options.resizePolling = this.options.resizePolling === undefined ? 60 : this.options.resizePolling;

				if (this.options.tap === true) {
					this.options.tap = 'tap';
				}

				if (this.options.shrinkScrollbars == 'scale') {
					this.options.useTransition = false;
				}

				this.options.invertWheelDirection = this.options.invertWheelDirection ? -1 : 1;

				if (this.options.probeType == 3) {
					this.options.useTransition = false;
				}

				// INSERT POINT: NORMALIZATION

				// Some defaults	
				this.x = 0;
				this.y = 0;
				this.directionX = 0;
				this.directionY = 0;
				this._events = {};

				// INSERT POINT: DEFAULTS

				this._init();
				this.refresh();

				this.scrollTo(this.options.startX, this.options.startY);
				this.enable();
			}

			IScroll.prototype = {
				version: '5.1.3',

				_init: function() {
					this._initEvents();

					if (this.options.scrollbars || this.options.indicators) {
						this._initIndicators();
					}

					if (this.options.mouseWheel) {
						this._initWheel();
					}

					if (this.options.snap) {
						this._initSnap();
					}

					if (this.options.keyBindings) {
						this._initKeys();
					}

					// INSERT POINT: _init

				},

				destroy: function() {
					this._initEvents(true);

					this._execEvent('destroy');
				},

				_transitionEnd: function(e) {
					if (e.target != this.scroller || !this.isInTransition) {
						return;
					}

					this._transitionTime();
					if (!this.resetPosition(this.options.bounceTime)) {
						this.isInTransition = false;
						this._execEvent('scrollEnd');
					}
				},

				_start: function(e) {
					// React to left mouse button only
					if (utils.eventType[e.type] != 1) {
						if (e.button !== 0) {
							return;
						}
					}

					if (!this.enabled || (this.initiated && utils.eventType[e.type] !== this.initiated)) {
						return;
					}

					if (this.options.preventDefault && !utils.isBadAndroid && !utils.preventDefaultException(e.target, this.options.preventDefaultException)) {
						e.preventDefault();
					}

					var point = e.touches ? e.touches[0] : e,
						pos;

					this.initiated = utils.eventType[e.type];
					this.moved = false;
					this.distX = 0;
					this.distY = 0;
					this.directionX = 0;
					this.directionY = 0;
					this.directionLocked = 0;

					this._transitionTime();

					this.startTime = utils.getTime();

					if (this.options.useTransition && this.isInTransition) {
						this.isInTransition = false;
						pos = this.getComputedPosition();
						this._translate(Math.round(pos.x), Math.round(pos.y));
						this._execEvent('scrollEnd');
					} else if (!this.options.useTransition && this.isAnimating) {
						this.isAnimating = false;
						this._execEvent('scrollEnd');
					}

					this.startX = this.x;
					this.startY = this.y;
					this.absStartX = this.x;
					this.absStartY = this.y;
					this.pointX = point.pageX;
					this.pointY = point.pageY;

					this._execEvent('beforeScrollStart');
				},

				_move: function(e) {
					if (!this.enabled || utils.eventType[e.type] !== this.initiated) {
						return;
					}

					if (this.options.preventDefault) { // increases performance on Android? TODO: check!
						e.preventDefault();
					}

					var point = e.touches ? e.touches[0] : e,
						deltaX = point.pageX - this.pointX,
						deltaY = point.pageY - this.pointY,
						timestamp = utils.getTime(),
						newX, newY,
						absDistX, absDistY;

					this.pointX = point.pageX;
					this.pointY = point.pageY;

					this.distX += deltaX;
					this.distY += deltaY;
					absDistX = Math.abs(this.distX);
					absDistY = Math.abs(this.distY);

					// We need to move at least 10 pixels for the scrolling to initiate
					if (timestamp - this.endTime > 300 && (absDistX < 10 && absDistY < 10)) {
						return;
					}

					// If you are scrolling in one direction lock the other
					if (!this.directionLocked && !this.options.freeScroll) {
						if (absDistX > absDistY + this.options.directionLockThreshold) {
							this.directionLocked = 'h'; // lock horizontally
						} else if (absDistY >= absDistX + this.options.directionLockThreshold) {
							this.directionLocked = 'v'; // lock vertically
						} else {
							this.directionLocked = 'n'; // no lock
						}
					}

					if (this.directionLocked == 'h') {
						if (this.options.eventPassthrough == 'vertical') {
							e.preventDefault();
						} else if (this.options.eventPassthrough == 'horizontal') {
							this.initiated = false;
							return;
						}

						deltaY = 0;
					} else if (this.directionLocked == 'v') {
						if (this.options.eventPassthrough == 'horizontal') {
							e.preventDefault();
						} else if (this.options.eventPassthrough == 'vertical') {
							this.initiated = false;
							return;
						}

						deltaX = 0;
					}

					deltaX = this.hasHorizontalScroll ? deltaX : 0;
					deltaY = this.hasVerticalScroll ? deltaY : 0;

					newX = this.x + deltaX;
					newY = this.y + deltaY;

					// Slow down if outside of the boundaries
					if (newX > 0 || newX < this.maxScrollX) {
						newX = this.options.bounce ? this.x + deltaX / 3 : newX > 0 ? 0 : this.maxScrollX;
					}
					if (newY > 0 || newY < this.maxScrollY) {
						newY = this.options.bounce ? this.y + deltaY / 3 : newY > 0 ? 0 : this.maxScrollY;
					}

					this.directionX = deltaX > 0 ? -1 : deltaX < 0 ? 1 : 0;
					this.directionY = deltaY > 0 ? -1 : deltaY < 0 ? 1 : 0;

					if (!this.moved) {
						this._execEvent('scrollStart');
					}

					this.moved = true;

					this._translate(newX, newY);

					/* REPLACE START: _move */
					if (timestamp - this.startTime > 300) {
						this.startTime = timestamp;
						this.startX = this.x;
						this.startY = this.y;

						if (this.options.probeType == 1) {
							this._execEvent('scroll');
						}
					}

					if (this.options.probeType > 1) {
						this._execEvent('scroll');
					}
					/* REPLACE END: _move */

				},

				_end: function(e) {
					if (!this.enabled || utils.eventType[e.type] !== this.initiated) {
						return;
					}

					if (this.options.preventDefault && !utils.preventDefaultException(e.target, this.options.preventDefaultException)) {
						e.preventDefault();
					}

					var point = e.changedTouches ? e.changedTouches[0] : e,
						momentumX,
						momentumY,
						duration = utils.getTime() - this.startTime,
						newX = Math.round(this.x),
						newY = Math.round(this.y),
						distanceX = Math.abs(newX - this.startX),
						distanceY = Math.abs(newY - this.startY),
						time = 0,
						easing = '';

					this.isInTransition = 0;
					this.initiated = 0;
					this.endTime = utils.getTime();

					// reset if we are outside of the boundaries
					if (this.resetPosition(this.options.bounceTime)) {
						return;
					}

					this.scrollTo(newX, newY); // ensures that the last position is rounded

					// we scrolled less than 10 pixels
					if (!this.moved) {
						if (this.options.tap) {
							utils.tap(e, this.options.tap);
						}

						if (this.options.click) {
							utils.click(e);
						}

						this._execEvent('scrollCancel');
						return;
					}

					if (this._events.flick && duration < 200 && distanceX < 100 && distanceY < 100) {
						this._execEvent('flick');
						return;
					}

					// start momentum animation if needed
					if (this.options.momentum && duration < 300) {
						momentumX = this.hasHorizontalScroll ? utils.momentum(this.x, this.startX, duration, this.maxScrollX, this.options.bounce ? this.wrapperWidth : 0, this.options.deceleration) : {
							destination: newX,
							duration: 0
						};
						momentumY = this.hasVerticalScroll ? utils.momentum(this.y, this.startY, duration, this.maxScrollY, this.options.bounce ? this.wrapperHeight : 0, this.options.deceleration) : {
							destination: newY,
							duration: 0
						};
						newX = momentumX.destination;
						newY = momentumY.destination;
						time = Math.max(momentumX.duration, momentumY.duration);
						this.isInTransition = 1;
					}


					if (this.options.snap) {
						var snap = this._nearestSnap(newX, newY);
						this.currentPage = snap;
						time = this.options.snapSpeed || Math.max(
							Math.max(
								Math.min(Math.abs(newX - snap.x), 1000),
								Math.min(Math.abs(newY - snap.y), 1000)
							), 300);
						newX = snap.x;
						newY = snap.y;

						this.directionX = 0;
						this.directionY = 0;
						easing = this.options.bounceEasing;
					}

					// INSERT POINT: _end

					if (newX != this.x || newY != this.y) {
						// change easing function when scroller goes out of the boundaries
						if (newX > 0 || newX < this.maxScrollX || newY > 0 || newY < this.maxScrollY) {
							easing = utils.ease.quadratic;
						}

						this.scrollTo(newX, newY, time, easing);
						return;
					}

					this._execEvent('scrollEnd');
				},

				_resize: function() {
					var that = this;

					clearTimeout(this.resizeTimeout);

					this.resizeTimeout = setTimeout(function() {
						that.refresh();
					}, this.options.resizePolling);
				},

				resetPosition: function(time) {
					var x = this.x,
						y = this.y;

					time = time || 0;

					if (!this.hasHorizontalScroll || this.x > 0) {
						x = 0;
					} else if (this.x < this.maxScrollX) {
						x = this.maxScrollX;
					}

					if (!this.hasVerticalScroll || this.y > 0) {
						y = 0;
					} else if (this.y < this.maxScrollY) {
						y = this.maxScrollY;
					}

					if (x == this.x && y == this.y) {
						return false;
					}

					this.scrollTo(x, y, time, this.options.bounceEasing);

					return true;
				},

				disable: function() {
					this.enabled = false;
				},

				enable: function() {
					this.enabled = true;
				},

				refresh: function() {
					var rf = this.wrapper.offsetHeight; // Force reflow

					this.wrapperWidth = this.wrapper.clientWidth;
					this.wrapperHeight = this.wrapper.clientHeight;

					/* REPLACE START: refresh */

					this.scrollerWidth = this.scroller.offsetWidth;
					this.scrollerHeight = this.scroller.offsetHeight;

					this.maxScrollX = this.wrapperWidth - this.scrollerWidth;
					this.maxScrollY = this.wrapperHeight - this.scrollerHeight;

					/* REPLACE END: refresh */

					this.hasHorizontalScroll = this.options.scrollX && this.maxScrollX < 0;
					this.hasVerticalScroll = this.options.scrollY && this.maxScrollY < 0;

					if (!this.hasHorizontalScroll) {
						this.maxScrollX = 0;
						this.scrollerWidth = this.wrapperWidth;
					}

					if (!this.hasVerticalScroll) {
						this.maxScrollY = 0;
						this.scrollerHeight = this.wrapperHeight;
					}

					this.endTime = 0;
					this.directionX = 0;
					this.directionY = 0;

					this.wrapperOffset = utils.offset(this.wrapper);

					this._execEvent('refresh');

					this.resetPosition();

					// INSERT POINT: _refresh

				},

				on: function(type, fn) {
					if (!this._events[type]) {
						this._events[type] = [];
					}

					this._events[type].push(fn);
				},

				off: function(type, fn) {
					if (!this._events[type]) {
						return;
					}

					var index = this._events[type].indexOf(fn);

					if (index > -1) {
						this._events[type].splice(index, 1);
					}
				},

				_execEvent: function(type) {
					if (!this._events[type]) {
						return;
					}

					var i = 0,
						l = this._events[type].length;

					if (!l) {
						return;
					}

					for (; i < l; i++) {
						this._events[type][i].apply(this, [].slice.call(arguments, 1));
					}
				},

				scrollBy: function(x, y, time, easing) {
					x = this.x + x;
					y = this.y + y;
					time = time || 0;

					this.scrollTo(x, y, time, easing);
				},

				scrollTo: function(x, y, time, easing) {
					easing = easing || utils.ease.circular;

					this.isInTransition = this.options.useTransition && time > 0;

					if (!time || (this.options.useTransition && easing.style)) {
						this._transitionTimingFunction(easing.style);
						this._transitionTime(time);
						this._translate(x, y);
					} else {
						this._animate(x, y, time, easing.fn);
					}
				},

				scrollToElement: function(el, time, offsetX, offsetY, easing) {
					el = el.nodeType ? el : this.scroller.querySelector(el);

					if (!el) {
						return;
					}

					var pos = utils.offset(el);

					pos.left -= this.wrapperOffset.left;
					pos.top -= this.wrapperOffset.top;

					// if offsetX/Y are true we center the element to the screen
					if (offsetX === true) {
						offsetX = Math.round(el.offsetWidth / 2 - this.wrapper.offsetWidth / 2);
					}
					if (offsetY === true) {
						offsetY = Math.round(el.offsetHeight / 2 - this.wrapper.offsetHeight / 2);
					}

					pos.left -= offsetX || 0;
					pos.top -= offsetY || 0;

					pos.left = pos.left > 0 ? 0 : pos.left < this.maxScrollX ? this.maxScrollX : pos.left;
					pos.top = pos.top > 0 ? 0 : pos.top < this.maxScrollY ? this.maxScrollY : pos.top;

					time = time === undefined || time === null || time === 'auto' ? Math.max(Math.abs(this.x - pos.left), Math.abs(this.y - pos.top)) : time;

					this.scrollTo(pos.left, pos.top, time, easing);
				},

				_transitionTime: function(time) {
					time = time || 0;

					this.scrollerStyle[utils.style.transitionDuration] = time + 'ms';

					if (!time && utils.isBadAndroid) {
						this.scrollerStyle[utils.style.transitionDuration] = '0.001s';
					}


					if (this.indicators) {
						for (var i = this.indicators.length; i--;) {
							this.indicators[i].transitionTime(time);
						}
					}


					// INSERT POINT: _transitionTime

				},

				_transitionTimingFunction: function(easing) {
					this.scrollerStyle[utils.style.transitionTimingFunction] = easing;


					if (this.indicators) {
						for (var i = this.indicators.length; i--;) {
							this.indicators[i].transitionTimingFunction(easing);
						}
					}


					// INSERT POINT: _transitionTimingFunction

				},

				_translate: function(x, y) {
					if (this.options.useTransform) {

						/* REPLACE START: _translate */

						this.scrollerStyle[utils.style.transform] = 'translate(' + x + 'px,' + y + 'px)' + this.translateZ;

						/* REPLACE END: _translate */

					} else {
						x = Math.round(x);
						y = Math.round(y);
						this.scrollerStyle.left = x + 'px';
						this.scrollerStyle.top = y + 'px';
					}

					this.x = x;
					this.y = y;


					if (this.indicators) {
						for (var i = this.indicators.length; i--;) {
							this.indicators[i].updatePosition();
						}
					}


					// INSERT POINT: _translate

				},

				_initEvents: function(remove) {
					var eventType = remove ? utils.removeEvent : utils.addEvent,
						target = this.options.bindToWrapper ? this.wrapper : window;

					eventType(window, 'orientationchange', this);
					eventType(window, 'resize', this);

					if (this.options.click) {
						eventType(this.wrapper, 'click', this, true);
					}

					if (!this.options.disableMouse) {
						eventType(this.wrapper, 'mousedown', this);
						eventType(target, 'mousemove', this);
						eventType(target, 'mousecancel', this);
						eventType(target, 'mouseup', this);
					}

					if (utils.hasPointer && !this.options.disablePointer) {
						eventType(this.wrapper, utils.prefixPointerEvent('pointerdown'), this);
						eventType(target, utils.prefixPointerEvent('pointermove'), this);
						eventType(target, utils.prefixPointerEvent('pointercancel'), this);
						eventType(target, utils.prefixPointerEvent('pointerup'), this);
					}

					if (utils.hasTouch && !this.options.disableTouch) {
						eventType(this.wrapper, 'touchstart', this);
						eventType(target, 'touchmove', this);
						eventType(target, 'touchcancel', this);
						eventType(target, 'touchend', this);
					}

					eventType(this.scroller, 'transitionend', this);
					eventType(this.scroller, 'webkitTransitionEnd', this);
					eventType(this.scroller, 'oTransitionEnd', this);
					eventType(this.scroller, 'MSTransitionEnd', this);
				},

				getComputedPosition: function() {
					var matrix = window.getComputedStyle(this.scroller, null),
						x, y;

					if (this.options.useTransform) {
						matrix = matrix[utils.style.transform].split(')')[0].split(', ');
						x = +(matrix[12] || matrix[4]);
						y = +(matrix[13] || matrix[5]);
					} else {
						x = +matrix.left.replace(/[^-\d.]/g, '');
						y = +matrix.top.replace(/[^-\d.]/g, '');
					}

					return {
						x: x,
						y: y
					};
				},

				_initIndicators: function() {
					var interactive = this.options.interactiveScrollbars,
						customStyle = typeof this.options.scrollbars != 'string',
						indicators = [],
						indicator;

					var that = this;

					this.indicators = [];

					if (this.options.scrollbars) {
						// Vertical scrollbar
						if (this.options.scrollY) {
							indicator = {
								el: createDefaultScrollbar('v', interactive, this.options.scrollbars),
								interactive: interactive,
								defaultScrollbars: true,
								customStyle: customStyle,
								resize: this.options.resizeScrollbars,
								shrink: this.options.shrinkScrollbars,
								fade: this.options.fadeScrollbars,
								listenX: false
							};

							this.wrapper.appendChild(indicator.el);
							indicators.push(indicator);
						}

						// Horizontal scrollbar
						if (this.options.scrollX) {
							indicator = {
								el: createDefaultScrollbar('h', interactive, this.options.scrollbars),
								interactive: interactive,
								defaultScrollbars: true,
								customStyle: customStyle,
								resize: this.options.resizeScrollbars,
								shrink: this.options.shrinkScrollbars,
								fade: this.options.fadeScrollbars,
								listenY: false
							};

							this.wrapper.appendChild(indicator.el);
							indicators.push(indicator);
						}
					}

					if (this.options.indicators) {
						// TODO: check concat compatibility
						indicators = indicators.concat(this.options.indicators);
					}

					for (var i = indicators.length; i--;) {
						this.indicators.push(new Indicator(this, indicators[i]));
					}

					// TODO: check if we can use array.map (wide compatibility and performance issues)
					function _indicatorsMap(fn) {
						for (var i = that.indicators.length; i--;) {
							fn.call(that.indicators[i]);
						}
					}

					if (this.options.fadeScrollbars) {
						this.on('scrollEnd', function() {
							_indicatorsMap(function() {
								this.fade();
							});
						});

						this.on('scrollCancel', function() {
							_indicatorsMap(function() {
								this.fade();
							});
						});

						this.on('scrollStart', function() {
							_indicatorsMap(function() {
								this.fade(1);
							});
						});

						this.on('beforeScrollStart', function() {
							_indicatorsMap(function() {
								this.fade(1, true);
							});
						});
					}


					this.on('refresh', function() {
						_indicatorsMap(function() {
							this.refresh();
						});
					});

					this.on('destroy', function() {
						_indicatorsMap(function() {
							this.destroy();
						});

						delete this.indicators;
					});
				},

				_initWheel: function() {
					utils.addEvent(this.wrapper, 'wheel', this);
					utils.addEvent(this.wrapper, 'mousewheel', this);
					utils.addEvent(this.wrapper, 'DOMMouseScroll', this);

					this.on('destroy', function() {
						utils.removeEvent(this.wrapper, 'wheel', this);
						utils.removeEvent(this.wrapper, 'mousewheel', this);
						utils.removeEvent(this.wrapper, 'DOMMouseScroll', this);
					});
				},

				_wheel: function(e) {
					if (!this.enabled) {
						return;
					}

					e.preventDefault();
					e.stopPropagation();

					var wheelDeltaX, wheelDeltaY,
						newX, newY,
						that = this;

					if (this.wheelTimeout === undefined) {
						that._execEvent('scrollStart');
					}

					// Execute the scrollEnd event after 400ms the wheel stopped scrolling
					clearTimeout(this.wheelTimeout);
					this.wheelTimeout = setTimeout(function() {
						that._execEvent('scrollEnd');
						that.wheelTimeout = undefined;
					}, 400);

					if ('deltaX' in e) {
						if (e.deltaMode === 1) {
							wheelDeltaX = -e.deltaX * this.options.mouseWheelSpeed;
							wheelDeltaY = -e.deltaY * this.options.mouseWheelSpeed;
						} else {
							wheelDeltaX = -e.deltaX;
							wheelDeltaY = -e.deltaY;
						}
					} else if ('wheelDeltaX' in e) {
						wheelDeltaX = e.wheelDeltaX / 120 * this.options.mouseWheelSpeed;
						wheelDeltaY = e.wheelDeltaY / 120 * this.options.mouseWheelSpeed;
					} else if ('wheelDelta' in e) {
						wheelDeltaX = wheelDeltaY = e.wheelDelta / 120 * this.options.mouseWheelSpeed;
					} else if ('detail' in e) {
						wheelDeltaX = wheelDeltaY = -e.detail / 3 * this.options.mouseWheelSpeed;
					} else {
						return;
					}

					wheelDeltaX *= this.options.invertWheelDirection;
					wheelDeltaY *= this.options.invertWheelDirection;

					if (!this.hasVerticalScroll) {
						wheelDeltaX = wheelDeltaY;
						wheelDeltaY = 0;
					}

					if (this.options.snap) {
						newX = this.currentPage.pageX;
						newY = this.currentPage.pageY;

						if (wheelDeltaX > 0) {
							newX--;
						} else if (wheelDeltaX < 0) {
							newX++;
						}

						if (wheelDeltaY > 0) {
							newY--;
						} else if (wheelDeltaY < 0) {
							newY++;
						}

						this.goToPage(newX, newY);

						return;
					}

					newX = this.x + Math.round(this.hasHorizontalScroll ? wheelDeltaX : 0);
					newY = this.y + Math.round(this.hasVerticalScroll ? wheelDeltaY : 0);

					if (newX > 0) {
						newX = 0;
					} else if (newX < this.maxScrollX) {
						newX = this.maxScrollX;
					}

					if (newY > 0) {
						newY = 0;
					} else if (newY < this.maxScrollY) {
						newY = this.maxScrollY;
					}

					this.scrollTo(newX, newY, 0);

					if (this.options.probeType > 1) {
						this._execEvent('scroll');
					}

					// INSERT POINT: _wheel
				},

				_initSnap: function() {
					this.currentPage = {};

					if (typeof this.options.snap == 'string') {
						this.options.snap = this.scroller.querySelectorAll(this.options.snap);
					}

					this.on('refresh', function() {
						var i = 0,
							l,
							m = 0,
							n,
							cx, cy,
							x = 0,
							y,
							stepX = this.options.snapStepX || this.wrapperWidth,
							stepY = this.options.snapStepY || this.wrapperHeight,
							el;

						this.pages = [];

						if (!this.wrapperWidth || !this.wrapperHeight || !this.scrollerWidth || !this.scrollerHeight) {
							return;
						}

						if (this.options.snap === true) {
							cx = Math.round(stepX / 2);
							cy = Math.round(stepY / 2);

							while (x > -this.scrollerWidth) {
								this.pages[i] = [];
								l = 0;
								y = 0;

								while (y > -this.scrollerHeight) {
									this.pages[i][l] = {
										x: Math.max(x, this.maxScrollX),
										y: Math.max(y, this.maxScrollY),
										width: stepX,
										height: stepY,
										cx: x - cx,
										cy: y - cy
									};

									y -= stepY;
									l++;
								}

								x -= stepX;
								i++;
							}
						} else {
							el = this.options.snap;
							l = el.length;
							n = -1;

							for (; i < l; i++) {
								if (i === 0 || el[i].offsetLeft <= el[i - 1].offsetLeft) {
									m = 0;
									n++;
								}

								if (!this.pages[m]) {
									this.pages[m] = [];
								}

								x = Math.max(-el[i].offsetLeft, this.maxScrollX);
								y = Math.max(-el[i].offsetTop, this.maxScrollY);
								cx = x - Math.round(el[i].offsetWidth / 2);
								cy = y - Math.round(el[i].offsetHeight / 2);

								this.pages[m][n] = {
									x: x,
									y: y,
									width: el[i].offsetWidth,
									height: el[i].offsetHeight,
									cx: cx,
									cy: cy
								};

								if (x > this.maxScrollX) {
									m++;
								}
							}
						}

						this.goToPage(this.currentPage.pageX || 0, this.currentPage.pageY || 0, 0);

						// Update snap threshold if needed
						if (this.options.snapThreshold % 1 === 0) {
							this.snapThresholdX = this.options.snapThreshold;
							this.snapThresholdY = this.options.snapThreshold;
						} else {
							this.snapThresholdX = Math.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].width * this.options.snapThreshold);
							this.snapThresholdY = Math.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].height * this.options.snapThreshold);
						}
					});

					this.on('flick', function() {
						var time = this.options.snapSpeed || Math.max(
							Math.max(
								Math.min(Math.abs(this.x - this.startX), 1000),
								Math.min(Math.abs(this.y - this.startY), 1000)
							), 300);

						this.goToPage(
							this.currentPage.pageX + this.directionX,
							this.currentPage.pageY + this.directionY,
							time
						);
					});
				},

				_nearestSnap: function(x, y) {
					if (!this.pages.length) {
						return {
							x: 0,
							y: 0,
							pageX: 0,
							pageY: 0
						};
					}

					var i = 0,
						l = this.pages.length,
						m = 0;

					// Check if we exceeded the snap threshold
					if (Math.abs(x - this.absStartX) < this.snapThresholdX &&
						Math.abs(y - this.absStartY) < this.snapThresholdY) {
						return this.currentPage;
					}

					if (x > 0) {
						x = 0;
					} else if (x < this.maxScrollX) {
						x = this.maxScrollX;
					}

					if (y > 0) {
						y = 0;
					} else if (y < this.maxScrollY) {
						y = this.maxScrollY;
					}

					for (; i < l; i++) {
						if (x >= this.pages[i][0].cx) {
							x = this.pages[i][0].x;
							break;
						}
					}

					l = this.pages[i].length;

					for (; m < l; m++) {
						if (y >= this.pages[0][m].cy) {
							y = this.pages[0][m].y;
							break;
						}
					}

					if (i == this.currentPage.pageX) {
						i += this.directionX;

						if (i < 0) {
							i = 0;
						} else if (i >= this.pages.length) {
							i = this.pages.length - 1;
						}

						x = this.pages[i][0].x;
					}

					if (m == this.currentPage.pageY) {
						m += this.directionY;

						if (m < 0) {
							m = 0;
						} else if (m >= this.pages[0].length) {
							m = this.pages[0].length - 1;
						}

						y = this.pages[0][m].y;
					}

					return {
						x: x,
						y: y,
						pageX: i,
						pageY: m
					};
				},

				goToPage: function(x, y, time, easing) {
					easing = easing || this.options.bounceEasing;

					if (x >= this.pages.length) {
						x = this.pages.length - 1;
					} else if (x < 0) {
						x = 0;
					}

					if (y >= this.pages[x].length) {
						y = this.pages[x].length - 1;
					} else if (y < 0) {
						y = 0;
					}

					var posX = this.pages[x][y].x,
						posY = this.pages[x][y].y;

					time = time === undefined ? this.options.snapSpeed || Math.max(
						Math.max(
							Math.min(Math.abs(posX - this.x), 1000),
							Math.min(Math.abs(posY - this.y), 1000)
						), 300) : time;

					this.currentPage = {
						x: posX,
						y: posY,
						pageX: x,
						pageY: y
					};

					this.scrollTo(posX, posY, time, easing);
				},

				next: function(time, easing) {
					var x = this.currentPage.pageX,
						y = this.currentPage.pageY;

					x++;

					if (x >= this.pages.length && this.hasVerticalScroll) {
						x = 0;
						y++;
					}

					this.goToPage(x, y, time, easing);
				},

				prev: function(time, easing) {
					var x = this.currentPage.pageX,
						y = this.currentPage.pageY;

					x--;

					if (x < 0 && this.hasVerticalScroll) {
						x = 0;
						y--;
					}

					this.goToPage(x, y, time, easing);
				},

				_initKeys: function(e) {
					// default key bindings
					var keys = {
						pageUp: 33,
						pageDown: 34,
						end: 35,
						home: 36,
						left: 37,
						up: 38,
						right: 39,
						down: 40
					};
					var i;

					// if you give me characters I give you keycode
					if (typeof this.options.keyBindings == 'object') {
						for (i in this.options.keyBindings) {
							if (typeof this.options.keyBindings[i] == 'string') {
								this.options.keyBindings[i] = this.options.keyBindings[i].toUpperCase().charCodeAt(0);
							}
						}
					} else {
						this.options.keyBindings = {};
					}

					for (i in keys) {
						this.options.keyBindings[i] = this.options.keyBindings[i] || keys[i];
					}

					utils.addEvent(window, 'keydown', this);

					this.on('destroy', function() {
						utils.removeEvent(window, 'keydown', this);
					});
				},

				_key: function(e) {
					if (!this.enabled) {
						return;
					}

					var snap = this.options.snap, // we are using this alot, better to cache it
						newX = snap ? this.currentPage.pageX : this.x,
						newY = snap ? this.currentPage.pageY : this.y,
						now = utils.getTime(),
						prevTime = this.keyTime || 0,
						acceleration = 0.250,
						pos;

					if (this.options.useTransition && this.isInTransition) {
						pos = this.getComputedPosition();

						this._translate(Math.round(pos.x), Math.round(pos.y));
						this.isInTransition = false;
					}

					this.keyAcceleration = now - prevTime < 200 ? Math.min(this.keyAcceleration + acceleration, 50) : 0;

					switch (e.keyCode) {
						case this.options.keyBindings.pageUp:
							if (this.hasHorizontalScroll && !this.hasVerticalScroll) {
								newX += snap ? 1 : this.wrapperWidth;
							} else {
								newY += snap ? 1 : this.wrapperHeight;
							}
							break;
						case this.options.keyBindings.pageDown:
							if (this.hasHorizontalScroll && !this.hasVerticalScroll) {
								newX -= snap ? 1 : this.wrapperWidth;
							} else {
								newY -= snap ? 1 : this.wrapperHeight;
							}
							break;
						case this.options.keyBindings.end:
							newX = snap ? this.pages.length - 1 : this.maxScrollX;
							newY = snap ? this.pages[0].length - 1 : this.maxScrollY;
							break;
						case this.options.keyBindings.home:
							newX = 0;
							newY = 0;
							break;
						case this.options.keyBindings.left:
							newX += snap ? -1 : 5 + this.keyAcceleration >> 0;
							break;
						case this.options.keyBindings.up:
							newY += snap ? 1 : 5 + this.keyAcceleration >> 0;
							break;
						case this.options.keyBindings.right:
							newX -= snap ? -1 : 5 + this.keyAcceleration >> 0;
							break;
						case this.options.keyBindings.down:
							newY -= snap ? 1 : 5 + this.keyAcceleration >> 0;
							break;
						default:
							return;
					}

					if (snap) {
						this.goToPage(newX, newY);
						return;
					}

					if (newX > 0) {
						newX = 0;
						this.keyAcceleration = 0;
					} else if (newX < this.maxScrollX) {
						newX = this.maxScrollX;
						this.keyAcceleration = 0;
					}

					if (newY > 0) {
						newY = 0;
						this.keyAcceleration = 0;
					} else if (newY < this.maxScrollY) {
						newY = this.maxScrollY;
						this.keyAcceleration = 0;
					}

					this.scrollTo(newX, newY, 0);

					this.keyTime = now;
				},

				_animate: function(destX, destY, duration, easingFn) {
					var that = this,
						startX = this.x,
						startY = this.y,
						startTime = utils.getTime(),
						destTime = startTime + duration;

					function step() {
						var now = utils.getTime(),
							newX, newY,
							easing;

						if (now >= destTime) {
							that.isAnimating = false;
							that._translate(destX, destY);

							if (!that.resetPosition(that.options.bounceTime)) {
								that._execEvent('scrollEnd');
							}

							return;
						}

						now = (now - startTime) / duration;
						easing = easingFn(now);
						newX = (destX - startX) * easing + startX;
						newY = (destY - startY) * easing + startY;
						that._translate(newX, newY);

						if (that.isAnimating) {
							rAF(step);
						}

						if (that.options.probeType == 3) {
							that._execEvent('scroll');
						}
					}

					this.isAnimating = true;
					step();
				},

				handleEvent: function(e) {
					switch (e.type) {
						case 'touchstart':
						case 'pointerdown':
						case 'MSPointerDown':
						case 'mousedown':
							this._start(e);
							break;
						case 'touchmove':
						case 'pointermove':
						case 'MSPointerMove':
						case 'mousemove':
							this._move(e);
							break;
						case 'touchend':
						case 'pointerup':
						case 'MSPointerUp':
						case 'mouseup':
						case 'touchcancel':
						case 'pointercancel':
						case 'MSPointerCancel':
						case 'mousecancel':
							this._end(e);
							break;
						case 'orientationchange':
						case 'resize':
							this._resize();
							break;
						case 'transitionend':
						case 'webkitTransitionEnd':
						case 'oTransitionEnd':
						case 'MSTransitionEnd':
							this._transitionEnd(e);
							break;
						case 'wheel':
						case 'DOMMouseScroll':
						case 'mousewheel':
							this._wheel(e);
							break;
						case 'keydown':
							this._key(e);
							break;
						case 'click':
							if (!e._constructed) {
								e.preventDefault();
								e.stopPropagation();
							}
							break;
					}
				}
			};

			function createDefaultScrollbar(direction, interactive, type) {
				var scrollbar = document.createElement('div'),
					indicator = document.createElement('div');

				if (type === true) {
					scrollbar.style.cssText = 'position:absolute;z-index:9999';
					indicator.style.cssText = '-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);border-radius:3px';
				}

				indicator.className = 'iScrollIndicator';

				if (direction == 'h') {
					if (type === true) {
						scrollbar.style.cssText += ';height:7px;left:2px;right:2px;bottom:0';
						indicator.style.height = '100%';
					}
					scrollbar.className = 'iScrollHorizontalScrollbar';
				} else {
					if (type === true) {
						scrollbar.style.cssText += ';width:7px;bottom:2px;top:2px;right:1px';
						indicator.style.width = '100%';
					}
					scrollbar.className = 'iScrollVerticalScrollbar';
				}

				scrollbar.style.cssText += ';overflow:hidden';

				if (!interactive) {
					scrollbar.style.pointerEvents = 'none';
				}

				scrollbar.appendChild(indicator);

				return scrollbar;
			}

			function Indicator(scroller, options) {
				this.wrapper = typeof options.el == 'string' ? document.querySelector(options.el) : options.el;
				this.wrapperStyle = this.wrapper.style;
				this.indicator = this.wrapper.children[0];
				this.indicatorStyle = this.indicator.style;
				this.scroller = scroller;

				this.options = {
					listenX: true,
					listenY: true,
					interactive: false,
					resize: true,
					defaultScrollbars: false,
					shrink: false,
					fade: false,
					speedRatioX: 0,
					speedRatioY: 0
				};

				for (var i in options) {
					this.options[i] = options[i];
				}

				this.sizeRatioX = 1;
				this.sizeRatioY = 1;
				this.maxPosX = 0;
				this.maxPosY = 0;

				if (this.options.interactive) {
					if (!this.options.disableTouch) {
						utils.addEvent(this.indicator, 'touchstart', this);
						utils.addEvent(window, 'touchend', this);
					}
					if (!this.options.disablePointer) {
						utils.addEvent(this.indicator, utils.prefixPointerEvent('pointerdown'), this);
						utils.addEvent(window, utils.prefixPointerEvent('pointerup'), this);
					}
					if (!this.options.disableMouse) {
						utils.addEvent(this.indicator, 'mousedown', this);
						utils.addEvent(window, 'mouseup', this);
					}
				}

				if (this.options.fade) {
					this.wrapperStyle[utils.style.transform] = this.scroller.translateZ;
					this.wrapperStyle[utils.style.transitionDuration] = utils.isBadAndroid ? '0.001s' : '0ms';
					this.wrapperStyle.opacity = '0';
				}
			}

			Indicator.prototype = {
				handleEvent: function(e) {
					switch (e.type) {
						case 'touchstart':
						case 'pointerdown':
						case 'MSPointerDown':
						case 'mousedown':
							this._start(e);
							break;
						case 'touchmove':
						case 'pointermove':
						case 'MSPointerMove':
						case 'mousemove':
							this._move(e);
							break;
						case 'touchend':
						case 'pointerup':
						case 'MSPointerUp':
						case 'mouseup':
						case 'touchcancel':
						case 'pointercancel':
						case 'MSPointerCancel':
						case 'mousecancel':
							this._end(e);
							break;
					}
				},

				destroy: function() {
					if (this.options.interactive) {
						utils.removeEvent(this.indicator, 'touchstart', this);
						utils.removeEvent(this.indicator, utils.prefixPointerEvent('pointerdown'), this);
						utils.removeEvent(this.indicator, 'mousedown', this);

						utils.removeEvent(window, 'touchmove', this);
						utils.removeEvent(window, utils.prefixPointerEvent('pointermove'), this);
						utils.removeEvent(window, 'mousemove', this);

						utils.removeEvent(window, 'touchend', this);
						utils.removeEvent(window, utils.prefixPointerEvent('pointerup'), this);
						utils.removeEvent(window, 'mouseup', this);
					}

					if (this.options.defaultScrollbars) {
						this.wrapper.parentNode.removeChild(this.wrapper);
					}
				},

				_start: function(e) {
					var point = e.touches ? e.touches[0] : e;

					e.preventDefault();
					e.stopPropagation();

					this.transitionTime();

					this.initiated = true;
					this.moved = false;
					this.lastPointX = point.pageX;
					this.lastPointY = point.pageY;

					this.startTime = utils.getTime();

					if (!this.options.disableTouch) {
						utils.addEvent(window, 'touchmove', this);
					}
					if (!this.options.disablePointer) {
						utils.addEvent(window, utils.prefixPointerEvent('pointermove'), this);
					}
					if (!this.options.disableMouse) {
						utils.addEvent(window, 'mousemove', this);
					}

					this.scroller._execEvent('beforeScrollStart');
				},

				_move: function(e) {
					var point = e.touches ? e.touches[0] : e,
						deltaX, deltaY,
						newX, newY,
						timestamp = utils.getTime();

					if (!this.moved) {
						this.scroller._execEvent('scrollStart');
					}

					this.moved = true;

					deltaX = point.pageX - this.lastPointX;
					this.lastPointX = point.pageX;

					deltaY = point.pageY - this.lastPointY;
					this.lastPointY = point.pageY;

					newX = this.x + deltaX;
					newY = this.y + deltaY;

					this._pos(newX, newY);


					if (this.scroller.options.probeType == 1 && timestamp - this.startTime > 300) {
						this.startTime = timestamp;
						this.scroller._execEvent('scroll');
					} else if (this.scroller.options.probeType > 1) {
						this.scroller._execEvent('scroll');
					}


					// INSERT POINT: indicator._move

					e.preventDefault();
					e.stopPropagation();
				},

				_end: function(e) {
					if (!this.initiated) {
						return;
					}

					this.initiated = false;

					e.preventDefault();
					e.stopPropagation();

					utils.removeEvent(window, 'touchmove', this);
					utils.removeEvent(window, utils.prefixPointerEvent('pointermove'), this);
					utils.removeEvent(window, 'mousemove', this);

					if (this.scroller.options.snap) {
						var snap = this.scroller._nearestSnap(this.scroller.x, this.scroller.y);

						var time = this.options.snapSpeed || Math.max(
							Math.max(
								Math.min(Math.abs(this.scroller.x - snap.x), 1000),
								Math.min(Math.abs(this.scroller.y - snap.y), 1000)
							), 300);

						if (this.scroller.x != snap.x || this.scroller.y != snap.y) {
							this.scroller.directionX = 0;
							this.scroller.directionY = 0;
							this.scroller.currentPage = snap;
							this.scroller.scrollTo(snap.x, snap.y, time, this.scroller.options.bounceEasing);
						}
					}

					if (this.moved) {
						this.scroller._execEvent('scrollEnd');
					}
				},

				transitionTime: function(time) {
					time = time || 0;
					this.indicatorStyle[utils.style.transitionDuration] = time + 'ms';

					if (!time && utils.isBadAndroid) {
						this.indicatorStyle[utils.style.transitionDuration] = '0.001s';
					}
				},

				transitionTimingFunction: function(easing) {
					this.indicatorStyle[utils.style.transitionTimingFunction] = easing;
				},

				refresh: function() {
					this.transitionTime();

					if (this.options.listenX && !this.options.listenY) {
						this.indicatorStyle.display = this.scroller.hasHorizontalScroll ? 'block' : 'none';
					} else if (this.options.listenY && !this.options.listenX) {
						this.indicatorStyle.display = this.scroller.hasVerticalScroll ? 'block' : 'none';
					} else {
						this.indicatorStyle.display = this.scroller.hasHorizontalScroll || this.scroller.hasVerticalScroll ? 'block' : 'none';
					}

					if (this.scroller.hasHorizontalScroll && this.scroller.hasVerticalScroll) {
						utils.addClass(this.wrapper, 'iScrollBothScrollbars');
						utils.removeClass(this.wrapper, 'iScrollLoneScrollbar');

						if (this.options.defaultScrollbars && this.options.customStyle) {
							if (this.options.listenX) {
								this.wrapper.style.right = '8px';
							} else {
								this.wrapper.style.bottom = '8px';
							}
						}
					} else {
						utils.removeClass(this.wrapper, 'iScrollBothScrollbars');
						utils.addClass(this.wrapper, 'iScrollLoneScrollbar');

						if (this.options.defaultScrollbars && this.options.customStyle) {
							if (this.options.listenX) {
								this.wrapper.style.right = '2px';
							} else {
								this.wrapper.style.bottom = '2px';
							}
						}
					}

					var r = this.wrapper.offsetHeight; // force refresh

					if (this.options.listenX) {
						this.wrapperWidth = this.wrapper.clientWidth;
						if (this.options.resize) {
							this.indicatorWidth = Math.max(Math.round(this.wrapperWidth * this.wrapperWidth / (this.scroller.scrollerWidth || this.wrapperWidth || 1)), 8);
							this.indicatorStyle.width = this.indicatorWidth + 'px';
						} else {
							this.indicatorWidth = this.indicator.clientWidth;
						}

						this.maxPosX = this.wrapperWidth - this.indicatorWidth;

						if (this.options.shrink == 'clip') {
							this.minBoundaryX = -this.indicatorWidth + 8;
							this.maxBoundaryX = this.wrapperWidth - 8;
						} else {
							this.minBoundaryX = 0;
							this.maxBoundaryX = this.maxPosX;
						}

						this.sizeRatioX = this.options.speedRatioX || (this.scroller.maxScrollX && (this.maxPosX / this.scroller.maxScrollX));
					}

					if (this.options.listenY) {
						this.wrapperHeight = this.wrapper.clientHeight;
						if (this.options.resize) {
							this.indicatorHeight = Math.max(Math.round(this.wrapperHeight * this.wrapperHeight / (this.scroller.scrollerHeight || this.wrapperHeight || 1)), 8);
							this.indicatorStyle.height = this.indicatorHeight + 'px';
						} else {
							this.indicatorHeight = this.indicator.clientHeight;
						}

						this.maxPosY = this.wrapperHeight - this.indicatorHeight;

						if (this.options.shrink == 'clip') {
							this.minBoundaryY = -this.indicatorHeight + 8;
							this.maxBoundaryY = this.wrapperHeight - 8;
						} else {
							this.minBoundaryY = 0;
							this.maxBoundaryY = this.maxPosY;
						}

						this.maxPosY = this.wrapperHeight - this.indicatorHeight;
						this.sizeRatioY = this.options.speedRatioY || (this.scroller.maxScrollY && (this.maxPosY / this.scroller.maxScrollY));
					}

					this.updatePosition();
				},

				updatePosition: function() {
					var x = this.options.listenX && Math.round(this.sizeRatioX * this.scroller.x) || 0,
						y = this.options.listenY && Math.round(this.sizeRatioY * this.scroller.y) || 0;

					if (!this.options.ignoreBoundaries) {
						if (x < this.minBoundaryX) {
							if (this.options.shrink == 'scale') {
								this.width = Math.max(this.indicatorWidth + x, 8);
								this.indicatorStyle.width = this.width + 'px';
							}
							x = this.minBoundaryX;
						} else if (x > this.maxBoundaryX) {
							if (this.options.shrink == 'scale') {
								this.width = Math.max(this.indicatorWidth - (x - this.maxPosX), 8);
								this.indicatorStyle.width = this.width + 'px';
								x = this.maxPosX + this.indicatorWidth - this.width;
							} else {
								x = this.maxBoundaryX;
							}
						} else if (this.options.shrink == 'scale' && this.width != this.indicatorWidth) {
							this.width = this.indicatorWidth;
							this.indicatorStyle.width = this.width + 'px';
						}

						if (y < this.minBoundaryY) {
							if (this.options.shrink == 'scale') {
								this.height = Math.max(this.indicatorHeight + y * 3, 8);
								this.indicatorStyle.height = this.height + 'px';
							}
							y = this.minBoundaryY;
						} else if (y > this.maxBoundaryY) {
							if (this.options.shrink == 'scale') {
								this.height = Math.max(this.indicatorHeight - (y - this.maxPosY) * 3, 8);
								this.indicatorStyle.height = this.height + 'px';
								y = this.maxPosY + this.indicatorHeight - this.height;
							} else {
								y = this.maxBoundaryY;
							}
						} else if (this.options.shrink == 'scale' && this.height != this.indicatorHeight) {
							this.height = this.indicatorHeight;
							this.indicatorStyle.height = this.height + 'px';
						}
					}

					this.x = x;
					this.y = y;

					if (this.scroller.options.useTransform) {
						this.indicatorStyle[utils.style.transform] = 'translate(' + x + 'px,' + y + 'px)' + this.scroller.translateZ;
					} else {
						this.indicatorStyle.left = x + 'px';
						this.indicatorStyle.top = y + 'px';
					}
				},

				_pos: function(x, y) {
					if (x < 0) {
						x = 0;
					} else if (x > this.maxPosX) {
						x = this.maxPosX;
					}

					if (y < 0) {
						y = 0;
					} else if (y > this.maxPosY) {
						y = this.maxPosY;
					}

					x = this.options.listenX ? Math.round(x / this.sizeRatioX) : this.scroller.x;
					y = this.options.listenY ? Math.round(y / this.sizeRatioY) : this.scroller.y;

					this.scroller.scrollTo(x, y);
				},

				fade: function(val, hold) {
					if (hold && !this.visible) {
						return;
					}

					clearTimeout(this.fadeTimeout);
					this.fadeTimeout = null;

					var time = val ? 250 : 500,
						delay = val ? 0 : 300;

					val = val ? '1' : '0';

					this.wrapperStyle[utils.style.transitionDuration] = time + 'ms';

					this.fadeTimeout = setTimeout((function(val) {
						this.wrapperStyle.opacity = val;
						this.visible = +val;
					}).bind(this, val), delay);
				}
			};

			IScroll.utils = utils;
			return IScroll;
		})();
		iosSelectUtil = {
			isArray: function(arg1) {
				return Object.prototype.toString.call(arg1) === '[object Array]';
			},
			isFunction: function(arg1) {
				return typeof arg1 === 'function';
			},
			attrToData: function(dom, index) {
				var obj = {};
				for (var p in dom.dataset) {
					obj[p] = dom.dataset[p];
				}
				obj['dom'] = dom;
				obj['atindex'] = index;
				return obj;
			},
			attrToHtml: function(obj) {
				var html = '';
				for (var p in obj) {
					html += 'data-' + p + '="' + obj[p] + '"';
				}
				return html;
			}
		};
		// Layer
		function Layer(html, opts) {
			if (!(this instanceof Layer)) {
				return new Layer(html, opts);
			}
			this.html = html;
			this.opts = opts;
			var el = document.createElement('div');
			el.className = 'olay';
			// var layer_el = $('<div class="layer"></div>');
			var layer_el = document.createElement('div');
			layer_el.className = 'layer';
			this.el = el;
			this.layer_el = layer_el;
			this.init();
		}
		Layer.prototype = {
			init: function() {
				this.layer_el.innerHTML = this.html;
				if (this.opts.container && document.querySelector(this.opts.container)) {
					document.querySelector(this.opts.container).appendChild(this.el);
				}
				else {
					document.body.appendChild(this.el);
				}
				this.el.appendChild(this.layer_el);
				this.el.style.height = Math.max(document.documentElement.getBoundingClientRect().height, window.innerHeight);
				if (this.opts.className) {
					this.el.className += ' ' + this.opts.className;
				}
				this.bindEvent();
			},
			bindEvent: function() {
				var sureDom = this.el.querySelectorAll('.sure');
				var closeDom = this.el.querySelectorAll('.close');
				var self = this;
				for (var i = 0, len = sureDom.length; i < len; i++) {
					sureDom[i].addEventListener('click', function(e) {
						self.close();
					});
				}
				for (var i = 0, len = closeDom.length; i < len; i++) {
					closeDom[i].addEventListener('click', function(e) {
						self.close();
					});
				}
			},
			close: function() {
				if (this.el) {
					this.el.parentNode.removeChild(this.el);
					this.el = null; 
				}
			}
		}
		function IosSelect(level, data, options) {
			if (!iosSelectUtil.isArray(data) || data.length === 0) {
				return;
			}
			this.data = data;
			this.level = level || 1;
			this.options = options;
			this.typeBox = 'one-level-box';
			if (this.level === 1) {
				this.typeBox = 'one-level-box';
			}
			else if (this.level === 2) {
				this.typeBox = 'two-level-box';
			}
			else if (this.level === 3) {
				this.typeBox = 'three-level-box';
			}
			else if (this.level === 4) {
				this.typeBox = 'four-level-box';
			}
			else if (this.level === 5) {
				this.typeBox = 'five-level-box';
			}
			this.callback = options.callback;
			this.closeCallback = options.closeCallback;
			this.title = options.title || '';
			this.options.itemHeight = options.itemHeight || 35;
			this.options.itemShowCount = [3, 5, 7, 9].indexOf(options.itemShowCount) !== -1? options.itemShowCount: 7; 
			this.options.coverArea1Top = Math.floor(this.options.itemShowCount / 2);
			this.options.coverArea2Top = Math.ceil(this.options.itemShowCount / 2); 
			this.options.headerHeight = options.headerHeight || 44;
			this,options.relation = iosSelectUtil.isArray(this.options.relation)? this.options.relation: [];
			this.options.oneTwoRelation = this.options.relation[0];
			this.options.twoThreeRelation = this.options.relation[1];
			this.options.threeFourRelation = this.options.relation[2];
			this.options.fourFiveRelation = this.options.relation[3];
			if (this.options.cssUnit !== 'px' && this.options.cssUnit !== 'rem') {
				this.options.cssUnit = 'px';
			}
			this.setBase();
			this.init();
		};

		IosSelect.prototype = {
			init: function() {
				this.initLayer();
				// 选中元素的信息
				this.selectOneObj = {};
				this.selectTwoObj = {};
				this.selectThreeObj = {};
				this.selectFourObj = {};
				this.selectFiveObj = {};
				this.setOneLevel(this.options.oneLevelId, this.options.twoLevelId, this.options.threeLevelId, this.options.fourLevelId, this.options.fiveLevelId);
			},
			initLayer: function() {
				var self = this;
				var all_html = [
					'<header style="height: ' + this.options.headerHeight + this.options.cssUnit + '; line-height: ' + this.options.headerHeight + this.options.cssUnit + '" class="iosselect-header">',
						'<h2 id="iosSelectTitle"></h2>',
						'<a style="height: ' + this.options.headerHeight + this.options.cssUnit + '; line-height: ' + this.options.headerHeight + this.options.cssUnit + '" href="javascript:void(0)" class="close">取消</a>',
						'<a style="height: ' + this.options.headerHeight + this.options.cssUnit + '; line-height: ' + this.options.headerHeight + this.options.cssUnit + '" href="javascript:void(0)" class="sure">确定</a>',
					'</header>',
					'<section class="iosselect-box">',
						'<div class="one-level-contain" id="oneLevelContain">',
							'<ul class="select-one-level">',
							'</ul>',
						'</div>',
						'<div class="two-level-contain" id="twoLevelContain">',
							'<ul class="select-two-level">',
							'</ul>',
						'</div>',
						'<div class="three-level-contain" id="threeLevelContain">',
							'<ul class="select-three-level">',
							'</ul>',
						'</div>',
						'<div class="four-level-contain" id="fourLevelContain">',
							'<ul class="select-four-level">',
							'</ul>',
						'</div>',
						'<div class="five-level-contain" id="fiveLevelContain">',
							'<ul class="select-five-level">',
							'</ul>',
						'</div>',
					'</section>',
					'<hr class="cover-area1"/>',
					'<hr class="cover-area2"/>',
					'<div class="ios-select-loading-box" id="iosSelectLoadingBox">',
					    '<div class="ios-select-loading"></div>',
					'</div>'
				].join('\r\n');
				this.iosSelectLayer = new Layer(all_html, {
					className: 'ios-select-widget-box ' + this.typeBox + (this.options.addClassName? ' ' + this.options.addClassName: ''),
					container: this.options.container || ''
				});

				this.iosSelectTitleDom = document.querySelector('#iosSelectTitle');
				this.iosSelectLoadingBoxDom = document.getElementById('iosSelectLoadingBox');
				if (this.options.title) {
					this.iosSelectTitleDom.innerHTML = this.options.title;
				}

				if (this.options.headerHeight && this.options.itemHeight) {
					this.coverArea1Dom = document.querySelector('.cover-area1');
					this.coverArea1Dom.style.top = this.options.headerHeight + this.options.itemHeight * this.options.coverArea1Top + this.options.cssUnit;

					this.coverArea2Dom = document.querySelector('.cover-area2');
					this.coverArea2Dom.style.top = this.options.headerHeight + this.options.itemHeight * this.options.coverArea2Top + this.options.cssUnit;
				}

				this.oneLevelContainDom = document.querySelector('#oneLevelContain');
				this.twoLevelContainDom = document.querySelector('#twoLevelContain');
				this.threeLevelContainDom = document.querySelector('#threeLevelContain');
				this.fourLevelContainDom = document.querySelector('#fourLevelContain');
				this.fiveLevelContainDom = document.querySelector('#fiveLevelContain');

				this.oneLevelUlContainDom = document.querySelector('.select-one-level');
				this.twoLevelUlContainDom = document.querySelector('.select-two-level');
				this.threeLevelUlContainDom = document.querySelector('.select-three-level');
				this.fourLevelUlContainDom = document.querySelector('.select-four-level');
				this.fiveLevelUlContainDom = document.querySelector('.select-five-level');

				this.iosSelectLayer.el.querySelector('.layer').style.height = this.options.itemHeight * this.options.itemShowCount + this.options.headerHeight + this.options.cssUnit;

				this.oneLevelContainDom.style.height = this.options.itemHeight * this.options.itemShowCount + this.options.cssUnit;

				this.offsetTop = document.body.scrollTop;
				document.body.classList.add('ios-select-body-class');
				window.scrollTo(0, 0);

				this.scrollOne = new IScroll('#oneLevelContain', {
					probeType: 3,
					bounce: false
				});
				this.scrollOne.on('scrollStart', function() {
					Array.prototype.slice.call(self.oneLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
						if (v.classList.contains('at')) {
							v.classList.remove('at');
						} else if (v.classList.contains('side1')) {
							v.classList.remove('side1');
						} else if (v.classList.contains('side2')) {
							v.classList.remove('side2');
						}
					});
				});
				this.scrollOne.on('scroll', function() {
					var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
					var plast = 1;

					plast = Math.round(pa) + 1;
					Array.prototype.slice.call(self.oneLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
						if (v.classList.contains('at')) {
							v.classList.remove('at');
						} else if (v.classList.contains('side1')) {
							v.classList.remove('side1');
						} else if (v.classList.contains('side2')) {
							v.classList.remove('side2');
						}
					});

					self.changeClassName(self.oneLevelContainDom, plast);
				});
				this.scrollOne.on('scrollEnd', function() {
					var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
					var plast = 1;
					var to = 0;
					if (Math.ceil(pa) === Math.round(pa)) {
						to = Math.ceil(pa) * self.options.itemHeight * self.baseSize;
						plast = Math.ceil(pa) + 1;
					} else {
						to = Math.floor(pa) * self.options.itemHeight * self.baseSize;
						plast = Math.floor(pa) + 1;
					}
					self.scrollOne.scrollTo(0, -to, 0);

					Array.prototype.slice.call(self.oneLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
						if (v.classList.contains('at')) {
							v.classList.remove('at');
						} else if (v.classList.contains('side1')) {
							v.classList.remove('side1');
						} else if (v.classList.contains('side2')) {
							v.classList.remove('side2');
						}
					});

					var pdom = self.changeClassName(self.oneLevelContainDom, plast);

					self.selectOneObj = iosSelectUtil.attrToData(pdom, plast);

					if (self.level > 1 && self.options.oneTwoRelation === 1) {
						self.setTwoLevel(self.selectOneObj.id, self.selectTwoObj.id, self.selectThreeObj.id, self.selectFourObj.id, self.selectFiveObj.id);
					}
				});
				if (this.level >= 2) {
					this.twoLevelContainDom.style.height = this.options.itemHeight * this.options.itemShowCount + this.options.cssUnit;
					this.scrollTwo = new IScroll('#twoLevelContain', {
						probeType: 3,
						bounce: false
					});
					this.scrollTwo.on('scrollStart', function() {
						Array.prototype.slice.call(self.twoLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});
					});
					this.scrollTwo.on('scroll', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 0;
						plast = Math.round(pa) + 1;

						Array.prototype.slice.call(self.twoLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						self.changeClassName(self.twoLevelContainDom, plast);
					});
					this.scrollTwo.on('scrollEnd', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 1;
						var to = 0;
						if (Math.ceil(pa) === Math.round(pa)) {
							to = Math.ceil(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.ceil(pa) + 1;
						} else {
							to = Math.floor(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.floor(pa) + 1;
						}
						self.scrollTwo.scrollTo(0, -to, 0);

						Array.prototype.slice.call(self.twoLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						var pdom = self.changeClassName(self.twoLevelContainDom, plast);

						self.selectTwoObj = iosSelectUtil.attrToData(pdom, plast);

						if (self.level > 2 && self.options.twoThreeRelation === 1) {
							self.setThreeLevel(self.selectOneObj.id, self.selectTwoObj.id, self.selectThreeObj.id, self.selectFourObj.id, self.selectFiveObj.id);
						}
					});
				}
				if (this.level >= 3) {
					this.threeLevelContainDom.style.height = this.options.itemHeight * this.options.itemShowCount + this.options.cssUnit;
					this.scrollThree = new IScroll('#threeLevelContain', {
						probeType: 3,
						bounce: false
					});
					this.scrollThree.on('scrollStart', function() {
						Array.prototype.slice.call(self.threeLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});
					});
					this.scrollThree.on('scroll', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 0;
						plast = Math.round(pa) + 1;

						Array.prototype.slice.call(self.threeLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						self.changeClassName(self.threeLevelContainDom, plast);
					});
					this.scrollThree.on('scrollEnd', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 1;
						var to = 0;
						if (Math.ceil(pa) === Math.round(pa)) {
							to = Math.ceil(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.ceil(pa) + 1;
						} else {
							to = Math.floor(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.floor(pa) + 1;
						}
						self.scrollThree.scrollTo(0, -to, 0);

						Array.prototype.slice.call(self.threeLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						var pdom = self.changeClassName(self.threeLevelContainDom, plast);

						self.selectThreeObj = iosSelectUtil.attrToData(pdom, plast);
						if (self.level >= 4 && self.options.threeFourRelation === 1) {
							self.setFourLevel(self.selectOneObj.id, self.selectTwoObj.id, self.selectThreeObj.id, self.selectFourObj.id, self.selectFiveObj.id);
						}
					});
				}
				if (this.level >= 4) {
					this.fourLevelContainDom.style.height = this.options.itemHeight * this.options.itemShowCount + this.options.cssUnit;
					this.scrollFour = new IScroll('#fourLevelContain', {
						probeType: 3,
						bounce: false
					});
					this.scrollFour.on('scrollStart', function() {
						Array.prototype.slice.call(self.fourLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});
					});
					this.scrollFour.on('scroll', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 0;
						plast = Math.round(pa) + 1;

						Array.prototype.slice.call(self.fourLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						self.changeClassName(self.fourLevelContainDom, plast);
					});
					this.scrollFour.on('scrollEnd', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 1;
						var to = 0;
						if (Math.ceil(pa) === Math.round(pa)) {
							to = Math.ceil(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.ceil(pa) + 1;
						} else {
							to = Math.floor(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.floor(pa) + 1;
						}
						self.scrollFour.scrollTo(0, -to, 0);

						Array.prototype.slice.call(self.fourLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						var pdom = self.changeClassName(self.fourLevelContainDom, plast);

						self.selectFourObj = iosSelectUtil.attrToData(pdom, plast);

						if (self.level >= 5 && self.options.fourFiveRelation === 1) {
							self.setFiveLevel(self.selectOneObj.id, self.selectTwoObj.id, self.selectThreeObj.id, self.selectFourObj.id, self.selectFiveObj.id);
						}
					});
				}
				if (this.level >= 5) {
					this.fiveLevelContainDom.style.height = this.options.itemHeight * this.options.itemShowCount + this.options.cssUnit;
					this.scrollFive = new IScroll('#fiveLevelContain', {
						probeType: 3,
						bounce: false
					});
					this.scrollFive.on('scrollStart', function() {
						Array.prototype.slice.call(self.fiveLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});
					});
					this.scrollFive.on('scroll', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 0;
						plast = Math.round(pa) + 1;

						Array.prototype.slice.call(self.fiveLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						self.changeClassName(self.fiveLevelContainDom, plast);
					});
					this.scrollFive.on('scrollEnd', function() {
						var pa = Math.abs(this.y / self.baseSize) / self.options.itemHeight;
						var plast = 1;
						var to = 0;
						if (Math.ceil(pa) === Math.round(pa)) {
							to = Math.ceil(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.ceil(pa) + 1;
						} else {
							to = Math.floor(pa) * self.options.itemHeight * self.baseSize;
							plast = Math.floor(pa) + 1;
						}
						self.scrollFive.scrollTo(0, -to, 0);

						Array.prototype.slice.call(self.fiveLevelContainDom.querySelectorAll('li')).forEach(function(v, i, o) {
							if (v.classList.contains('at')) {
								v.classList.remove('at');
							} else if (v.classList.contains('side1')) {
								v.classList.remove('side1');
							} else if (v.classList.contains('side2')) {
								v.classList.remove('side2');
							}
						});

						var pdom = self.changeClassName(self.fiveLevelContainDom, plast);

						self.selectFiveObj = iosSelectUtil.attrToData(pdom, plast);
					});
				}

				// 取消 确认 事件
				this.closeBtnDom = this.iosSelectLayer.el.querySelector('.close');
				this.closeBtnDom.addEventListener('click', function(e) {
					if (document.body.classList.contains('ios-select-body-class')) {
						document.body.classList.remove('ios-select-body-class');
					}
					window.scrollTo(0, self.offsetTop);
					self.closeCallback && self.closeCallback();

				});

				this.selectBtnDom = this.iosSelectLayer.el.querySelector('.sure');
				this.selectBtnDom.addEventListener('click', function(e) {
					if (document.body.classList.contains('ios-select-body-class')) {
						document.body.classList.remove('ios-select-body-class');
					}
					window.scrollTo(0, self.offsetTop);
					self.callback && self.callback(self.selectOneObj, self.selectTwoObj, self.selectThreeObj, self.selectFourObj, self.selectFiveObj);
				});
			},
			loadingShow: function() {
				this.options.showLoading && (this.iosSelectLoadingBoxDom.style.display = 'block');
			},
			loadingHide: function() {
				this.iosSelectLoadingBoxDom.style.display = 'none';
			},
			getOneLevel: function() {
				return this.data[0];
			},
			setOneLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId) {
				if (iosSelectUtil.isArray(this.data[0])){
					var oneLevelData = this.getOneLevel();
					this.renderOneLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, oneLevelData);
				}
				else if (iosSelectUtil.isFunction(this.data[0])) {
					this.loadingShow();
					this.data[0](function(oneLevelData) {
						this.loadingHide();
						this.renderOneLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, oneLevelData);
					}.bind(this));
				}
				else {
					throw new Error('data format error');
				}
			},
			renderOneLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, oneLevelData) {
				var hasAtId = oneLevelData.some(function(v, i, o) {
					return v.id == oneLevelId;
				});
				if (!hasAtId) {
					oneLevelId = oneLevelData[0]['id'];
				}
				var oneHtml = '';
				var self = this;
				var plast = 0;
				oneHtml += this.getWhiteItem();
				oneLevelData.forEach(function(v, i, o) {
					if (v.id == oneLevelId) {
						oneHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';" ' + iosSelectUtil.attrToHtml(v) + ' class="at">' + v.value + '</li>';
						plast = i + 1;
					} else {
						oneHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + '>' + v.value + '</li>';
					}
				}.bind(this));
				oneHtml += this.getWhiteItem();
				this.oneLevelUlContainDom.innerHTML = oneHtml;

				this.scrollOne.refresh();
				this.scrollOne.scrollToElement('li:nth-child(' + plast + ')', 0);
				if (this.level >= 2) {
					this.setTwoLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId);
				}

				var pdom = this.changeClassName(this.oneLevelContainDom, plast);
				this.selectOneObj = iosSelectUtil.attrToData(pdom, this.getAtIndexByPlast(plast));
			},
			getTwoLevel: function(oneLevelId) {
				var twoLevelData = [];
				if (this.options.oneTwoRelation === 1) {
					this.data[1].forEach(function(v, i, o) {
						if (v['parentId'] == oneLevelId) {
							twoLevelData.push(v);
						}
					});
				} else {
					twoLevelData = this.data[1];
				}
				return twoLevelData;
			},
			setTwoLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId) {
				if (iosSelectUtil.isArray(this.data[1])) {
					var twoLevelData = this.getTwoLevel(oneLevelId);
					this.renderTwoLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, twoLevelData);
				}
				else if (iosSelectUtil.isFunction(this.data[1])) {
					this.loadingShow();
					this.data[1](oneLevelId, function(twoLevelData) {
						this.loadingHide();
						this.renderTwoLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, twoLevelData);
					}.bind(this));
				}
				else {
					throw new Error('data format error');
				}
			},
			renderTwoLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, twoLevelData) {
				var plast = 0;
				var hasAtId = twoLevelData.some(function(v, i, o) {
					return v.id == twoLevelId;
				});
				if (!hasAtId) {
					twoLevelId = twoLevelData[0]['id'];
				}
				var twoHtml = '';
				var self = this;
				twoHtml += this.getWhiteItem();
				twoLevelData.forEach(function(v, i, o) {
					if (v.id == twoLevelId) {
						twoHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + ' class="at">' + v.value + '</li>';
						plast = i + 1;
					} else {
						twoHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + '>' + v.value + '</li>';
					}
				}.bind(this));
				twoHtml += this.getWhiteItem();
				this.twoLevelUlContainDom.innerHTML = twoHtml;
				this.scrollTwo.refresh();
				this.scrollTwo.scrollToElement(':nth-child(' + plast + ')', 0);
				if (this.level >= 3) {
					this.setThreeLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId);
				}

				var pdom = this.changeClassName(this.twoLevelContainDom, plast);
				this.selectTwoObj = iosSelectUtil.attrToData(pdom, this.getAtIndexByPlast(plast));
			},
			getThreeLevel: function(oneLevelId, twoLevelId) {
				var threeLevelData = [];
				if (this.options.twoThreeRelation === 1) {
					this.data[2].forEach(function(v, i, o) {
						if (v['parentId'] == twoLevelId) {
							threeLevelData.push(v);
						}
					});
				} else {
					threeLevelData = this.data[2];
				}
				return threeLevelData;
			},
			setThreeLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId) {
				if (iosSelectUtil.isArray(this.data[2])) {
					var threeLevelData = this.getThreeLevel(oneLevelId, twoLevelId);
					this.renderThreeLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, threeLevelData);
				}
				else if (iosSelectUtil.isFunction(this.data[2])) {
					this.loadingShow();
					this.data[2](oneLevelId, twoLevelId, function(threeLevelData) {
						this.loadingHide();
						this.renderThreeLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, threeLevelData);
					}.bind(this));
				}
				else {
					throw new Error('data format error');
				}
			},
		    renderThreeLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, threeLevelData) {
		    	var plast = 0;
				var hasAtId = threeLevelData.some(function(v, i, o) {
					return v.id == threeLevelId;
				});
				if (!hasAtId) {
					threeLevelId = threeLevelData[0]['id'];
				}
				var threeHtml = '';
				var self = this;
				threeHtml += this.getWhiteItem();
				threeLevelData.forEach(function(v, i, o) {
					if (v.id == threeLevelId) {
						threeHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + ' class="at">' + v.value + '</li>';
						plast = i + 1;
					} else {
						threeHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + '>' + v.value + '</li>';
					}
				}.bind(this));
				threeHtml += this.getWhiteItem();
				this.threeLevelUlContainDom.innerHTML = threeHtml;
				this.scrollThree.refresh();
				this.scrollThree.scrollToElement(':nth-child(' + plast + ')', 0);

				if (this.level >= 4) {
					this.setFourLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId);
				}

				var pdom = this.changeClassName(this.threeLevelContainDom, plast);
				this.selectThreeObj = iosSelectUtil.attrToData(pdom, this.getAtIndexByPlast(plast));
		    },
		    getFourLevel: function(oneLevelId, twoLevelId, threeLevelId) {
				var fourLevelData = [];
				if (this.options.threeFourRelation === 1) {
					this.data[3].forEach(function(v, i, o) {
						if (v['parentId'] === threeLevelId) {
							fourLevelData.push(v);
						}
					});
				} else {
					fourLevelData = this.data[3];
				}
				return fourLevelData;
			},
			setFourLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId) {
				if (iosSelectUtil.isArray(this.data[3])) {
					var fourLevelData = this.getFourLevel(oneLevelId, twoLevelId, threeLevelId);
					this.renderFourLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, fourLevelData);
				}
				else if (iosSelectUtil.isFunction(this.data[3])) {
					this.loadingShow();
					this.data[3](oneLevelId, twoLevelId, threeLevelId, function(fourLevelData) {
						this.loadingHide();
						this.renderFourLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, fourLevelData);
					}.bind(this));
				}
				else {
					throw new Error('data format error');
				}
			},
		    renderFourLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, fourLevelData) {
		    	var plast = 0;
				var hasAtId = fourLevelData.some(function(v, i, o) {
					return v.id == fourLevelId;
				});
				if (!hasAtId) {
					fourLevelId = fourLevelData[0]['id'];
				}
				var fourHtml = '';
				var self = this;
				fourHtml += this.getWhiteItem();
				fourLevelData.forEach(function(v, i, o) {
					if (v.id == fourLevelId) {
						fourHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + ' class="at">' + v.value + '</li>';
						plast = i + 1;
					} else {
						fourHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + '>' + v.value + '</li>';
					}
				}.bind(this));
				fourHtml += this.getWhiteItem();
				this.fourLevelUlContainDom.innerHTML = fourHtml;
				this.scrollFour.refresh();
				this.scrollFour.scrollToElement(':nth-child(' + plast + ')', 0);

				if (this.level >= 5) {
					this.setFiveLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId);
				}

				var pdom = this.changeClassName(this.fourLevelContainDom, plast);
				this.selectFourObj = iosSelectUtil.attrToData(pdom, this.getAtIndexByPlast(plast));
		    },
		    getFiveLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId) {
				var fiveLevelData = [];
				if (this.options.fourFiveRelation === 1) {
					this.data[4].forEach(function(v, i, o) {
						if (v['parentId'] === fourLevelId) {
							fiveLevelData.push(v);
						}
					});
				} else {
					fiveLevelData = this.data[4];
				}
				return fiveLevelData;
			},
			setFiveLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId) {
				if (iosSelectUtil.isArray(this.data[4])) {
					var fiveLevelData = this.getFiveLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId);
					this.renderFiveLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, fiveLevelData);
				}
				else if (iosSelectUtil.isFunction(this.data[4])) {
					this.loadingShow();
					this.data[4](oneLevelId, twoLevelId, threeLevelId, fourLevelId, function(fiveLevelData) {
						this.loadingHide();
						this.renderFiveLevel(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, fiveLevelData);
					}.bind(this));
				}
				else {
					throw new Error('data format error');
				}
			},
		    renderFiveLevel: function(oneLevelId, twoLevelId, threeLevelId, fourLevelId, fiveLevelId, fiveLevelData) {
		    	var plast = 0;
				var hasAtId = fiveLevelData.some(function(v, i, o) {
					return v.id == fiveLevelId;
				});
				if (!hasAtId) {
					fiveLevelId = fiveLevelData[0]['id'];
				}
				var fiveHtml = '';
				var self = this;
				fiveHtml += this.getWhiteItem();
				fiveLevelData.forEach(function(v, i, o) {
					if (v.id == fiveLevelId) {
						fiveHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + ' class="at">' + v.value + '</li>';
						plast = i + 1;
					} else {
						fiveHtml += '<li style="height: ' + this.options.itemHeight + this.options.cssUnit + '; line-height: ' + this.options.itemHeight + this.options.cssUnit +';"' + iosSelectUtil.attrToHtml(v) + '>' + v.value + '</li>';
					}
				}.bind(this));
				fiveHtml += this.getWhiteItem();
				this.fiveLevelUlContainDom.innerHTML = fiveHtml;
				this.scrollFive.refresh();
				this.scrollFive.scrollToElement(':nth-child(' + plast + ')', 0);

				var pdom = this.changeClassName(this.fiveLevelContainDom, plast);
				this.selectFiveObj = iosSelectUtil.attrToData(pdom, this.getAtIndexByPlast(plast));
		    },
		    getWhiteItem: function() {
		    	var whiteItemHtml = '';
		    	whiteItemHtml += '<li style="height: ' + this.options.itemHeight +this.options.cssUnit +  '; line-height: ' + this.options.itemHeight +this.options.cssUnit + '"></li>';
		    	if (this.options.itemShowCount > 3) {
		    		whiteItemHtml += '<li style="height: ' + this.options.itemHeight +this.options.cssUnit +  '; line-height: ' + this.options.itemHeight +this.options.cssUnit + '"></li>';
		    	}
		    	if (this.options.itemShowCount > 5) {
		    		whiteItemHtml += '<li style="height: ' + this.options.itemHeight +this.options.cssUnit +  '; line-height: ' + this.options.itemHeight +this.options.cssUnit + '"></li>';
		    	}
		    	if (this.options.itemShowCount > 7) {
		    		whiteItemHtml += '<li style="height: ' + this.options.itemHeight +this.options.cssUnit +  '; line-height: ' + this.options.itemHeight +this.options.cssUnit + '"></li>';
		    	}
		    	return whiteItemHtml;
		    }, 
		    changeClassName: function(levelContainDom, plast) {
		    	var pdom;
		    	if (this.options.itemShowCount === 3) {
		    		pdom = levelContainDom.querySelector('li:nth-child(' + (plast + 1) + ')');
					pdom.classList.add('at');
		    	}
		    	else if (this.options.itemShowCount === 5) {
		    		pdom = levelContainDom.querySelector('li:nth-child(' + (plast + 2) + ')');
					pdom.classList.add('at');

					levelContainDom.querySelector('li:nth-child(' + (plast + 1) + ')').classList.add('side1');
					levelContainDom.querySelector('li:nth-child(' + (plast + 3) + ')').classList.add('side1');
		    	}
		    	else if (this.options.itemShowCount === 7) {
		    		pdom = levelContainDom.querySelector('li:nth-child(' + (plast + 3) + ')');
					pdom.classList.add('at');

					levelContainDom.querySelector('li:nth-child(' + (plast + 2) + ')').classList.add('side1');
					levelContainDom.querySelector('li:nth-child(' + (plast + 1) + ')').classList.add('side2');
					levelContainDom.querySelector('li:nth-child(' + (plast + 4) + ')').classList.add('side1');
					levelContainDom.querySelector('li:nth-child(' + (plast + 5) + ')').classList.add('side2');
		    	}
		    	else if (this.options.itemShowCount === 9) {
		    		pdom = levelContainDom.querySelector('li:nth-child(' + (plast + 4) + ')');
					pdom.classList.add('at');

					levelContainDom.querySelector('li:nth-child(' + (plast + 3) + ')').classList.add('side1');
					levelContainDom.querySelector('li:nth-child(' + (plast + 2) + ')').classList.add('side2');
					levelContainDom.querySelector('li:nth-child(' + (plast + 5) + ')').classList.add('side1');
					levelContainDom.querySelector('li:nth-child(' + (plast + 6) + ')').classList.add('side2');
		    	}
		    	return pdom;
		    },
		    getAtIndexByPlast: function(plast) {
		    	return plast + Math.ceil(this.itemShowCount / 2);
		    },
		    setBase: function() {
				if (this.options.cssUnit === 'rem') {
					var dltDom = document.documentElement;
					var dltStyle = window.getComputedStyle(dltDom, null);
					var dltFontSize = dltStyle.fontSize;
					try {
						this.baseSize = /\d+/.exec(dltFontSize)[0];
					}
					catch(e) {
						this.baseSize = 1;
					}
				}
				else {
					this.baseSize = 1;
				}
			}
		}
		if (typeof module != 'undefined' && module.exports) {
			module.exports = IosSelect;
		} else if (true) {
			!(__WEBPACK_AMD_DEFINE_RESULT__ = function() {
				return IosSelect;
			}.call(exports, __webpack_require__, exports, module), __WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
		} else {
			window.IosSelect = IosSelect;
		}
	})();

/***/ }

});